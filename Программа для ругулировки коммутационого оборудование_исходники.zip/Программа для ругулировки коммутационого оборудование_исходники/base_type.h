#ifndef BASE_TYPE_H
#define BASE_TYPE_H
#pragma pack(1)

typedef struct
{
  unsigned char NumerAction;
  unsigned char Mode;
  unsigned char Flag;
  unsigned char NumerTrueSendPack;
  unsigned char NumerLevelConnectCommutator;
  unsigned TimeWait;
  /****************************************/
  unsigned char uchWork;
  unsigned char muchSwitchComm[16];
  unsigned char muchGainManger[8];
  unsigned short usnTemperatureN1;
  unsigned short usnTemperatureN2;
  unsigned char uchStatusFlags;
  unsigned char muchRezervByte[11];
  unsigned char uchTypeComm;
  unsigned char muchFactoryNumer[12];
  unsigned char uchResetSetting;
  unsigned char muchGainCorrectMinus[8];
  unsigned char muchGainCorrectNormal[8];
  unsigned char muchGainCorrectPlus[8];
  unsigned char muchGainCorrectNool[8];
  unsigned short musnMacPay[3];
  unsigned short musnMacComm[3];
  unsigned nIpPAY;
  unsigned nIpComm;
  unsigned nIpMaskPAY;
  unsigned nIpMaskComm;
  unsigned short  usnNumberPortPAY;
  unsigned short  usnNumberPortComm;
  unsigned nIpPAYnew;
  unsigned nIpCommnew;
  unsigned char uchTypeCommnew;
  unsigned short  usnNumberPortCommnew;
}OperationData;


typedef union
{
    struct
    {
        struct
        {
            unsigned short IDP_FIELD;
            unsigned short IDO_FIELD;
            unsigned short DLC_FIELD;
            unsigned char   WS_FIELD;
            unsigned char   KOP_FIELD;
            unsigned char   NP_FIELD;
        }PayHeader;
        union
        {
            union
            {
                unsigned Ipcom;
                unsigned char ByteIpcom[4];
            }IPaddresCommutator;
            union
            {
                unsigned short UdpPort;
                unsigned char ByteUdpPort[4];
            }UDPPortCommutator;
            union
            {
               unsigned short MACcom[3];
               unsigned char ByteMACcom[6];
            }MACCommutator;
            struct
            {
                unsigned char  ModeWorkCommutator;
                unsigned char  OUT_OR_IN_Numer[16];
                unsigned char	 TransferFactor[8];
                unsigned short TemperaruraPlataN1;
                unsigned short TemperaruraPlataN2;
                unsigned char  FlagState;
                unsigned char  RezervByte[11];
            }SettingCommutator;
            struct
            {
                unsigned char TypeCommutator;
                unsigned char FactoryNummer[12];
                unsigned char ResetCommutator;
                unsigned char GainCorrectMinus[8];
                unsigned char GainCorrectNool[8];
                unsigned char GainCorrectPlus[8];
                unsigned char GainCorrectChennel[8];
                union
                {
                    unsigned IpPAY;
                    unsigned char ByteIpcom[4];
                }IPaddresPAY;
            }SettingSystemCommutator;
        };
    }Data_Pack;
unsigned char chDataPack[59];
}unPack;

#define NUMER_UDP_PORT_PAY 30020
#define NUMER_UDP_PORT_COMMUTATOR 30020
#define IDP_IDO_CM16_4  0x0064
#define IDP_IDO_DM4_16  0x0065
#define IDP_IDO_CMDM8_4  0x0066
#define IDP_IDO_PAY  0x8000
#define IDP_IDO_BRODCAST 0x0000
#define VC_SYSTEM_INFO  0x30
#define VC_APLICATE_DATA  0x31
#define KOP_READ_DATA  0x44
#define KOP_WRITE_DATA  0x48
#define KOP_REQEST_PAY_OPERATE  0x00
#define KOP_error_OPERATE_PAY  0x02
#define KOP_error_format_PAY  0x03
#define NP_IP_pack  0x01
#define NP_IPMASK_pack  0x02
#define NP_NUMBER_PORT_pack  0x03
#define NP_MAC_pack  0x04
#define NP_CONFIGURE_COMMUTATOR_pack  0x05
#define NP_READ_TEMPERATURE_pack  0x06
#define NP_CONFIGURE_SYSTEM_COMMUTATOR_pack  0x07
const unsigned short TypeCommutator[3]={IDP_IDO_CM16_4,IDP_IDO_DM4_16,IDP_IDO_CMDM8_4};
#endif // BASE_TYPE_H
