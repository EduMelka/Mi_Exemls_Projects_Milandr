#include "mainwindow.h"
#include "ui_mainwindow.h"



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    bool xt;
    ui->setupUi(this);
    pOperationData= new OperationData;
    pQUdpSocket = new QUdpSocket;
    punPack = new unPack;
    pTimer = new QTimer(this);
    InitSettingCommutator(0);
    xt=pQUdpSocket->bind(QHostAddress(pOperationData->nIpPAY),pOperationData->usnNumberPortPAY);
    /****/
    QObject::connect(ui->pushButton,SIGNAL(clicked()),SLOT(PushConnectCommutatorSlot()));
    QObject::connect(ui->pushButton_17,SIGNAL(clicked()),SLOT(PushDiesConnectCommutatorSlot()));
    QObject::connect(ui->pushButton_8,SIGNAL(clicked()),SLOT(PushResetCommutatorSlot()));
    QObject::connect(ui->pushButton_6,SIGNAL(clicked()),SLOT(PushSetFactoryNumerSlot()));
    QObject::connect(ui->pushButton_16,SIGNAL(clicked()),SLOT(PushSetIPSlot()));
    QObject::connect(ui->pushButton_4,SIGNAL(clicked()),SLOT(PushSetUDPPortSlot()));
    QObject::connect(ui->pushButton_12,SIGNAL(clicked()), SLOT(PushSetMACCommutatorSlot()));
    QObject::connect(ui->pushButton_13,SIGNAL(clicked()), SLOT(PushSetIPPauSlot()));
    QObject::connect(ui->pushButton_3,SIGNAL(clicked()), SLOT(PushSetSystemChennelCommutatorSlot()));
    QObject::connect(ui->pushButton_14,SIGNAL(clicked()), SLOT(PushSetSMDMChennelSlot()));
    QObject::connect(ui->pushButton_2,SIGNAL(clicked()), SLOT(PushSetSMChennelSlot()));
    QObject::connect(ui->pushButton_5,SIGNAL(clicked()), SLOT(PushSetDMChennelSlot()));
    QObject::connect(ui->pushButton_15,SIGNAL(clicked()), SLOT(PushGetSMDMChennelSlot()));
    QObject::connect(ui->pushButton_9,SIGNAL(clicked()), SLOT(PushGetSMChennelSlot()));
    QObject::connect(ui->pushButton_7,SIGNAL(clicked()), SLOT(PushGetDMChennelSlot()));
    QObject::connect(ui->pushButton_10,SIGNAL(clicked()), SLOT(PushSetGainSettingSlot()));
    QObject::connect(ui->pushButton_11,SIGNAL(clicked()), SLOT(PushGetGainSettingSlot()));
    QObject::connect(ui->pushButton_27,SIGNAL(clicked()), SLOT(PushSetGainCorrectSlot()));
    QObject::connect(ui->pushButton_28,SIGNAL(clicked()), SLOT(PushGetGainCorrectSlot()));
    /****/
    connect(this,&MainWindow::SendPackSignal,this,&MainWindow::SendPackSlot);
    /***/
    connect(pTimer,SIGNAL(timeout()),this,SLOT(TimeHasComeSlot()));
     /***/
    connect(pQUdpSocket,SIGNAL(readyRead()),this,SLOT(ReadPackSlot()));
     /***/
    connect(this, &MainWindow::NumerActionGuiSignal,this, &MainWindow::SwitchActionSlot);
    /***/
    connect(this,&MainWindow::CommutatorReqestSignal, this, &MainWindow::HeaderActionSwitchSlot);
    connect(this,&MainWindow::CommutatorNotReqestSignal,this, &MainWindow::HeaderActionSwitchSlot);
    //***
    connect(this,&MainWindow::StartConnectCommutatorSignal,this, &MainWindow::ConnectCommutatorSlot);
    connect(this,&MainWindow::NextLevelCoonnectCommutatorSignal,this,&MainWindow::ConnectCommutatorSlot);
    //***
    connect(this,&MainWindow::StartSetGainSettingSignal,this,&MainWindow::SetGainSettingSlot);
    connect(this,&MainWindow::NextLevelSetGainSettingSignal,this,&MainWindow::SetGainSettingSlot);
    //***
    connect(this,&MainWindow::StartGetGainSettingSignal,this,&MainWindow::GetGainSettingSlot);
    connect(this,&MainWindow::NextLevelGetGainSettingSignal,this,&MainWindow::GetGainSettingSlot);
    //***
    connect(pQUdpSocket,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(SocetErrorSlot()));

}

void MainWindow::InitSettingCommutator(unsigned char mode)
{
        int i;
        DisBlockGui();

        pOperationData->usnNumberPortPAY=30020;
        pOperationData->usnNumberPortComm=30020;
        pOperationData->uchTypeComm=1;
        pOperationData->uchWork=0;
        pOperationData->nIpComm=QHostAddress("192.168.1.100").toIPv4Address();
        pOperationData->nIpPAY=QHostAddress("192.168.1.128").toIPv4Address();
        pOperationData->uchResetSetting=0;
        if(mode==0)
        {
            pOperationData->NumerAction=0;
            pOperationData->Flag=0;
            pOperationData->NumerTrueSendPack=0;
            pOperationData->NumerLevelConnectCommutator=0;
            pOperationData->musnMacComm[0]=0;
            pOperationData->musnMacComm[1]=0;
            pOperationData->musnMacComm[2]=0;
            pOperationData->usnTemperatureN2=0;
            pOperationData->usnTemperatureN1=0;
            pOperationData->uchStatusFlags=0;
        }
        for(i=0;i<16;i++)
        {
            pOperationData->muchSwitchComm[i]=0;
            if(i<8)
            {
               pOperationData->muchGainCorrectMinus[i]=0;
               pOperationData->muchGainCorrectNool[i]=0;
               pOperationData->muchGainCorrectNormal[i]=0;
               pOperationData->muchGainCorrectPlus[i]=0;
               pOperationData->muchGainManger[i]=0;
            }
            if(i<12)
            {
               pOperationData->muchFactoryNumer[i]=0;
            }
            if(i<11)
            {
               pOperationData->muchRezervByte[i]=0;
            }

        }
        ui->MAC_address->setInputMask("HH:HH:HH:HH:HH:HH;_");
        QString ipRange = "(?:[0-1]?[0-9]?[0-9]|2[0-4][0-9]|25[0-5])";
        QRegExp ipRegex("^" + ipRange
                           + "\\." + ipRange
                           + "\\." + ipRange
                           + "\\." + ipRange + "$");
        QRegExpValidator *ipValidator = new QRegExpValidator(ipRegex, this);
        QString coffRange_1="([0-9]|[1][0-1])";
        QString coffRange_2="(0|5)";
        QRegExp coffRegex("^"+coffRange_1+"\\."+coffRange_2+"$");
        QRegExpValidator *coffValidator = new QRegExpValidator(coffRegex, this);
        ui->Ipaddres->setValidator(ipValidator);
        ui->Ipaddres_PAY->setValidator(ipValidator);
        ui->Ipaddres_PAY->setText(QHostAddress(pOperationData->nIpPAY).toString());
        ui->cof1_1->setValidator(coffValidator);
        ui->cof2_1->setValidator(coffValidator);
        ui->cof3_1->setValidator(coffValidator);
        ui->cof4_1->setValidator(coffValidator);
        ui->cof5_1->setValidator(coffValidator);
        ui->cof6_1->setValidator(coffValidator);
        ui->cof7_1->setValidator(coffValidator);
        ui->cof8_1->setValidator(coffValidator);
        ui->cof1_2->setValidator(coffValidator);
        ui->cof2_2->setValidator(coffValidator);
        ui->cof3_2->setValidator(coffValidator);
        ui->cof4_2->setValidator(coffValidator);
        ui->cof5_2->setValidator(coffValidator);
        ui->cof6_2->setValidator(coffValidator);
        ui->cof7_2->setValidator(coffValidator);
        ui->cof8_2->setValidator(coffValidator);
        ui->cof1_3->setValidator(coffValidator);
        ui->cof2_3->setValidator(coffValidator);
        ui->cof3_3->setValidator(coffValidator);
        ui->cof4_3->setValidator(coffValidator);
        ui->cof5_3->setValidator(coffValidator);
        ui->cof6_3->setValidator(coffValidator);
        ui->cof7_3->setValidator(coffValidator);
        ui->cof8_3->setValidator(coffValidator);
}

void MainWindow::SetSystemInfoCommutator()
{
     unsigned i;
     punPack->Data_Pack.PayHeader.IDO_FIELD=IDP_IDO_PAY;
     punPack->Data_Pack.PayHeader.DLC_FIELD=59;
     punPack->Data_Pack.PayHeader.WS_FIELD=VC_APLICATE_DATA;
     punPack->Data_Pack.PayHeader.KOP_FIELD=KOP_READ_DATA;
     punPack->Data_Pack.PayHeader.NP_FIELD=NP_CONFIGURE_SYSTEM_COMMUTATOR_pack;
     for(i=0;i<12;i++)
     {
       punPack->Data_Pack.SettingSystemCommutator.FactoryNummer[i]=pOperationData->muchFactoryNumer[i];
       if(i<8)
       {
          punPack->Data_Pack.SettingSystemCommutator.GainCorrectChennel[i]=pOperationData->muchGainCorrectNool[i];
          punPack->Data_Pack.SettingSystemCommutator.GainCorrectMinus[i]=pOperationData->muchGainCorrectMinus[i];
          punPack->Data_Pack.SettingSystemCommutator.GainCorrectNool[i]=pOperationData->muchGainCorrectNormal[i];
          punPack->Data_Pack.SettingSystemCommutator.GainCorrectPlus[i]=pOperationData->muchGainCorrectPlus[i];
       }
     }
     punPack->Data_Pack.SettingSystemCommutator.IPaddresPAY.IpPAY=pOperationData->nIpPAYnew;
     punPack->Data_Pack.SettingSystemCommutator.ResetCommutator=pOperationData->uchResetSetting;
     punPack->Data_Pack.SettingSystemCommutator.TypeCommutator=pOperationData->uchTypeComm;
}

void MainWindow::SetSettingCommutator()
{
    unsigned i;
    punPack->Data_Pack.PayHeader.IDO_FIELD=IDP_IDO_PAY;
    punPack->Data_Pack.PayHeader.DLC_FIELD=50;
    punPack->Data_Pack.PayHeader.WS_FIELD=VC_APLICATE_DATA;
    punPack->Data_Pack.PayHeader.KOP_FIELD=KOP_READ_DATA;
    punPack->Data_Pack.PayHeader.NP_FIELD=NP_CONFIGURE_COMMUTATOR_pack;
    punPack->Data_Pack.SettingCommutator.FlagState=0;
    punPack->Data_Pack.SettingCommutator.ModeWorkCommutator=pOperationData->uchWork;
    punPack->Data_Pack.SettingCommutator.TemperaruraPlataN1=0;
    punPack->Data_Pack.SettingCommutator.TemperaruraPlataN2=0;
    for(i=0;i<16;i++)
    {
        punPack->Data_Pack.SettingCommutator.OUT_OR_IN_Numer[i]=pOperationData->muchSwitchComm[i];
        if(i<11)
        {
             punPack->Data_Pack.SettingCommutator.RezervByte[i]=0;
        }
        if(i<8)
        {
            punPack->Data_Pack.SettingCommutator.TransferFactor[i]=pOperationData->muchGainManger[i];
        }

    }
}

void MainWindow::SetReqestPack(unsigned char TypeMessage, unsigned char NumerPack)
{
    punPack->Data_Pack.PayHeader.IDO_FIELD=IDP_IDO_PAY;
    punPack->Data_Pack.PayHeader.DLC_FIELD=9;
    punPack->Data_Pack.PayHeader.WS_FIELD=TypeMessage;
    punPack->Data_Pack.PayHeader.KOP_FIELD=KOP_WRITE_DATA;
    punPack->Data_Pack.PayHeader.NP_FIELD=NumerPack;
}



MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::PushConnectCommutatorSlot()
{
    pOperationData->NumerAction=0;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
}

void MainWindow::PushDiesConnectCommutatorSlot()
{
     DisBlockGui();
}

void MainWindow::PushResetCommutatorSlot()
{
    QString str;
    pOperationData->NumerAction=100;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Сброс коммутатора";
    ui->textEdit->append(str);
    InitSettingCommutator(1);
}

void MainWindow::PushSetFactoryNumerSlot()
{
    QString str;
    pOperationData->NumerAction=101;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Установка заводского номера";
    ui->textEdit->append(str);
}
void MainWindow::PushSetIPSlot()
{
    QString str;
    pOperationData->NumerAction=102;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Установка IP адреса коммутатора";
    ui->textEdit->append(str);
}

void MainWindow::PushSetUDPPortSlot()
{
    QString str;
    pOperationData->NumerAction=103;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Установка UDP порта коммутатора";
    ui->textEdit->append(str);
}


void MainWindow::PushSetMACCommutatorSlot()
{
    QString str;
    pOperationData->NumerAction=104;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Установка MAC коммутатора";
    ui->textEdit->append(str);
}

void MainWindow::PushSetIPPauSlot()
{
    QString str;
    pOperationData->NumerAction=105;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Установка IP адреса ПАУ";
    ui->textEdit->append(str);
}

void MainWindow::PushSetSystemChennelCommutatorSlot()
{
    QString str;
    pOperationData->NumerAction=106;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Подключение 10МГц";
    ui->textEdit->append(str);
}

void MainWindow::PushSetSMDMChennelSlot()
{
    QString str;
    pOperationData->NumerAction=107;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Настройка каналов СМДМ8-4";
    ui->textEdit->append(str);
}

void MainWindow::PushSetSMChennelSlot()
{
    QString str;
    pOperationData->NumerAction=108;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Настройка каналов СМ16-4";
    ui->textEdit->append(str);
}

void MainWindow::PushSetDMChennelSlot()
{
    QString str;
    pOperationData->NumerAction=109;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Настройка каналов ДМ4-16";
    ui->textEdit->append(str);
}

void MainWindow::PushGetSMDMChennelSlot()
{
    QString str;
    pOperationData->NumerAction=200;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Запрос настроек каналов СМДМ8-4";
    ui->textEdit->append(str);
}

void MainWindow::PushGetSMChennelSlot()
{
    QString str;
    pOperationData->NumerAction=201;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Запрос настроек каналов СМ16-4";
    ui->textEdit->append(str);
}

void MainWindow::PushGetDMChennelSlot()
{
    QString str;
    pOperationData->NumerAction=202;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Запрос настроек каналов ДМ4-16";
    ui->textEdit->append(str);
}

void MainWindow::PushSetGainSettingSlot()
{
    QString str;
    pOperationData->NumerAction=110;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Установка усиления коммутатора";
    ui->textEdit->append(str);
}

void MainWindow::PushGetGainSettingSlot()
{
    QString str;
    pOperationData->NumerAction=203;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Запрос усиления коммутатора";
    ui->textEdit->append(str);
}

void MainWindow::PushSetGainCorrectSlot()
{
    QString str;
    pOperationData->NumerAction=111;
    emit NumerActionGuiSignal(pOperationData->NumerAction);
    ptime=ptime.currentTime();
    str="> "+ptime.toString("hh.mm.ss")+"  ";
    str=str+"Установка температурной коррекции усиления коммутатора";
    ui->textEdit->append(str);
}

void MainWindow::PushGetGainCorrectSlot()
{
     QString str;
     pOperationData->NumerAction=204;
     emit NumerActionGuiSignal(pOperationData->NumerAction);
     ptime=ptime.currentTime();
     str="> "+ptime.toString("hh.mm.ss")+"  ";
     str=str+"Запрос температурной коррекции усиления коммутатора";
     ui->textEdit->append(str);
}

void MainWindow::SwitchActionSlot(uchar numer)
{
    if(((pOperationData->Flag)&0x01)==0)
    {
        pOperationData->Flag=1;
        if((numer!=0)&&(numer!=110)&&(numer!=203))
        {
            emit  SendPackSignal(numer);
            pOperationData->Mode=0;
        }
        if(numer==0)
        {
            emit StartConnectCommutatorSignal(0); //начать подключение коммутатора
            pOperationData->Mode=1;
        }
        if(numer==110)
        {
            emit StartSetGainSettingSignal(0);
            pOperationData->Mode=2;
        }
        if(numer==203)
        {
            pOperationData->Mode=3;
            emit StartGetGainSettingSignal(0);
        }
    }

}

void MainWindow::SendPackSlot(uchar numer)
{
   QString str;
   unsigned Ip;
   unsigned short UdpPort;
    switch(numer)
    {
       case 100:
             punPack->Data_Pack.PayHeader.IDP_FIELD=IDP_IDO_BRODCAST;
             pOperationData->uchResetSetting=1;
             SetSystemInfoCommutator();
             pOperationData->uchResetSetting=0;
             pOperationData->TimeWait=10000;
             Ip=0xFFFFFFFF;
             UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 101:
             punPack->Data_Pack.PayHeader.IDP_FIELD=IDP_IDO_BRODCAST;
             SetSystemInfoCommutator();
             pOperationData->TimeWait=2000;
             Ip=0xFFFFFFFF;
             UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 102:
             punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
             punPack->Data_Pack.PayHeader.IDO_FIELD=IDP_IDO_PAY;
             punPack->Data_Pack.PayHeader.DLC_FIELD=13;
             punPack->Data_Pack.PayHeader.WS_FIELD=VC_SYSTEM_INFO;
             punPack->Data_Pack.PayHeader.KOP_FIELD=KOP_READ_DATA;
             punPack->Data_Pack.PayHeader.NP_FIELD=NP_IP_pack;
             punPack->Data_Pack.IPaddresCommutator.Ipcom=pOperationData->nIpCommnew;
             pOperationData->TimeWait=2000;
             Ip=pOperationData->nIpComm;
             UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 103:
             punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
             punPack->Data_Pack.PayHeader.IDO_FIELD=IDP_IDO_PAY;
             punPack->Data_Pack.PayHeader.DLC_FIELD=11;
             punPack->Data_Pack.PayHeader.WS_FIELD=VC_SYSTEM_INFO;
             punPack->Data_Pack.PayHeader.KOP_FIELD=KOP_READ_DATA;
             punPack->Data_Pack.PayHeader.NP_FIELD=NP_NUMBER_PORT_pack;
             punPack->Data_Pack.UDPPortCommutator.UdpPort=pOperationData->usnNumberPortCommnew;
             Ip=pOperationData->nIpComm;
             pOperationData->TimeWait=2000;
             UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 104:
             punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
             punPack->Data_Pack.PayHeader.IDO_FIELD=IDP_IDO_PAY;
             punPack->Data_Pack.PayHeader.DLC_FIELD=15;
             punPack->Data_Pack.PayHeader.WS_FIELD=VC_SYSTEM_INFO;
             punPack->Data_Pack.PayHeader.KOP_FIELD=KOP_READ_DATA;
             punPack->Data_Pack.PayHeader.NP_FIELD=NP_MAC_pack;
             punPack->Data_Pack.MACCommutator.MACcom[0]=pOperationData->musnMacComm[0];
             punPack->Data_Pack.MACCommutator.MACcom[1]=pOperationData->musnMacComm[1];
             punPack->Data_Pack.MACCommutator.MACcom[2]=pOperationData->musnMacComm[2];
             Ip=pOperationData->nIpComm;
             pOperationData->TimeWait=2000;
             UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 105:
             punPack->Data_Pack.PayHeader.IDP_FIELD=IDP_IDO_BRODCAST;
             SetSystemInfoCommutator();
             Ip=0xFFFFFFFF;
              pOperationData->TimeWait=2000;
             UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 106:
            punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
            SetSettingCommutator();
            Ip=pOperationData->nIpComm;
             pOperationData->TimeWait=1000;
            UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 107:
            punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
            pOperationData->uchWork=0;
            UpadateGui();
            SetSettingCommutator();
            pOperationData->TimeWait=1000;
            Ip=pOperationData->nIpComm;
            UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 108:
            punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
            pOperationData->uchWork=0;
            UpadateGui();
            SetSettingCommutator();
             pOperationData->TimeWait=1000;
            Ip=pOperationData->nIpComm;
            UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 109:
            punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
            pOperationData->uchWork=0;
            UpadateGui();
             pOperationData->TimeWait=1000;
            SetSettingCommutator(); 
            Ip=pOperationData->nIpComm;
            UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 111:
            punPack->Data_Pack.PayHeader.IDP_FIELD=IDP_IDO_BRODCAST;
            SetSystemInfoCommutator();
            Ip=0xFFFFFFFF;
             pOperationData->TimeWait=1000;
            UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 200:
            punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
            SetReqestPack(VC_APLICATE_DATA,NP_CONFIGURE_COMMUTATOR_pack);
            Ip=pOperationData->nIpComm;
             pOperationData->TimeWait=1000;
             pOperationData->TimeWait=1000;
            UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 201:
            punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
            SetReqestPack(VC_APLICATE_DATA,NP_CONFIGURE_COMMUTATOR_pack);
            Ip=pOperationData->nIpComm;
            UdpPort=pOperationData->usnNumberPortComm;
            Ip=pOperationData->nIpComm;
             pOperationData->TimeWait=1000;
            UdpPort=pOperationData->usnNumberPortComm;
            break;
       case 202:
            punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
            SetReqestPack(VC_APLICATE_DATA,NP_CONFIGURE_COMMUTATOR_pack);
            Ip=pOperationData->nIpComm;
             pOperationData->TimeWait=1000;
            UdpPort=pOperationData->usnNumberPortComm;
        break;
        case 204:
            punPack->Data_Pack.PayHeader.IDP_FIELD=IDP_IDO_BRODCAST;
            SetReqestPack(VC_APLICATE_DATA,NP_CONFIGURE_SYSTEM_COMMUTATOR_pack);
            Ip=pOperationData->nIpComm;
             pOperationData->TimeWait=2000;
            UdpPort=pOperationData->usnNumberPortComm;          
            break;
        case 205:
             punPack->Data_Pack.PayHeader.IDP_FIELD=IDP_IDO_BRODCAST;
             SetReqestPack(VC_SYSTEM_INFO,NP_IP_pack);
             Ip=0xFFFFFFFF;
              pOperationData->TimeWait=1000;
             UdpPort=pOperationData->usnNumberPortComm;
             ptime=ptime.currentTime();
             str="> "+ptime.toString("hh.mm.ss")+"  ";
             str=str+"Запрос Ip адреса коммутатора";
             ui->textEdit->append(str);
             break;
        case 206:
             punPack->Data_Pack.PayHeader.IDP_FIELD=IDP_IDO_BRODCAST;
             SetReqestPack(VC_SYSTEM_INFO,NP_NUMBER_PORT_pack);
             ptime=ptime.currentTime();
              pOperationData->TimeWait=1000;
             str="> "+ptime.toString("hh.mm.ss")+"  ";
             str=str+"Запрос номера UDP порта коммутатора";
             ui->textEdit->append(str);
             Ip=0xFFFFFFFF;
             UdpPort=pOperationData->usnNumberPortComm;
        break;
        case 207:
             punPack->Data_Pack.PayHeader.IDP_FIELD=IDP_IDO_BRODCAST;
             SetReqestPack(VC_SYSTEM_INFO,NP_MAC_pack);
             ptime=ptime.currentTime();
              pOperationData->TimeWait=1000;
             str="> "+ptime.toString("hh.mm.ss")+"  ";
             str=str+"Запрос MAC коммутатора";
             ui->textEdit->append(str);
             Ip=0xFFFFFFFF;
             UdpPort=pOperationData->usnNumberPortComm;
        break;
        case 208:
             punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
             SetReqestPack(VC_APLICATE_DATA, NP_READ_TEMPERATURE_pack);
             ptime=ptime.currentTime();
              pOperationData->TimeWait=1000;
             str="> "+ptime.toString("hh.mm.ss")+"  ";
             str=str+"Запрос температуры коммутатора";
             ui->textEdit->append(str);
             Ip=pOperationData->nIpComm;
             UdpPort=pOperationData->usnNumberPortComm;
        break;
        case 209:
           punPack->Data_Pack.PayHeader.IDP_FIELD=IDP_IDO_BRODCAST;
           SetReqestPack(VC_APLICATE_DATA,NP_CONFIGURE_SYSTEM_COMMUTATOR_pack);
           ptime=ptime.currentTime();
            pOperationData->TimeWait=1000;
           str="> "+ptime.toString("hh.mm.ss")+"  ";
           str=str+"Запрос системной информации коммутатора";
           ui->textEdit->append(str);
           Ip=pOperationData->nIpComm;
           UdpPort=pOperationData->usnNumberPortComm;
        break;
        case 210:
             punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
             SetReqestPack(VC_APLICATE_DATA, NP_CONFIGURE_COMMUTATOR_pack);
             ptime=ptime.currentTime();
              pOperationData->TimeWait=1000;
             str="> "+ptime.toString("hh.mm.ss")+"  ";
             str=str+"Запрос конфигурации коммутатора";
             ui->textEdit->append(str);
             Ip=pOperationData->nIpComm;
             UdpPort=pOperationData->usnNumberPortComm;
        break;
        case 112:
             punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
             SetSettingCommutator();
             Ip=pOperationData->nIpComm;
             UdpPort=pOperationData->usnNumberPortComm;
        break;
        case 113:
            punPack->Data_Pack.PayHeader.IDP_FIELD=IDP_IDO_BRODCAST;
             SetSystemInfoCommutator();
            pOperationData->TimeWait=1000;
            Ip=pOperationData->nIpComm;
            UdpPort=pOperationData->usnNumberPortComm;
        break;
        case 211:
             punPack->Data_Pack.PayHeader.IDP_FIELD=TypeCommutator[pOperationData->uchTypeComm-1];
             SetReqestPack(VC_APLICATE_DATA,NP_CONFIGURE_COMMUTATOR_pack);
             pOperationData->TimeWait=1000;
             Ip=pOperationData->nIpComm;
             UdpPort=pOperationData->usnNumberPortComm;
        break;
        case 212:
             punPack->Data_Pack.PayHeader.IDP_FIELD=IDP_IDO_BRODCAST;
             SetReqestPack(VC_APLICATE_DATA,NP_CONFIGURE_SYSTEM_COMMUTATOR_pack);
             pOperationData->TimeWait=1000;
             Ip=pOperationData->nIpComm;
             UdpPort=pOperationData->usnNumberPortComm;
        break;
    }
   pQUdpSocket->writeDatagram((const char*)(punPack->chDataPack),punPack->Data_Pack.PayHeader.DLC_FIELD,QHostAddress(Ip),UdpPort);
   pTimer->start(pOperationData->TimeWait);
}

void MainWindow::TimeHasComeSlot()
{
    emit CommutatorNotReqestSignal(2);
}

void MainWindow::HeaderActionSwitchSlot(uchar numer)
{
  QString str;
  ptime=ptime.currentTime();
  pTimer->stop();
  if((numer==1)&(pOperationData->Flag==1))// пакет принят испешно
  {
      pOperationData->NumerTrueSendPack=0;
      str="> "+ptime.toString("hh.mm.ss")+"  ";
      str=str+"Ответ от коммутатора получен";
      ui->textEdit->append(str);
      switch(pOperationData->Mode)
      {
            case 0: 
                if(pOperationData->NumerAction==105)
                {
                    pOperationData->nIpPAY=pOperationData->nIpPAYnew;
                }
                if(pOperationData->NumerAction==102)
                {
                    pOperationData->nIpComm=pOperationData->nIpCommnew;
                }
                if(pOperationData->NumerAction==103)
                {
                    pOperationData->usnNumberPortComm=pOperationData->usnNumberPortCommnew;
                }
                if(pOperationData->NumerAction==104)
                {
                    str="arp -d "+QHostAddress(pOperationData->nIpComm).toString();
                    system(str.toLocal8Bit());
                }
                pOperationData->Flag=0;
                if(pOperationData->NumerAction==100)
                {
                    DisBlockGui();
                }
                else
                {
                    ui->listWidget_2->setCurrentIndex(pOperationData->uchTypeComm-1);
                    UpadateGui();
                }


                break;
            case 1:
                if(pOperationData->NumerLevelConnectCommutator!=5)
                {
                    pOperationData->NumerLevelConnectCommutator=pOperationData->NumerLevelConnectCommutator+1;
                    emit NextLevelCoonnectCommutatorSignal(1);
                }
                else
                {
                    pOperationData->Flag=0;
                    UpadateGui();
                    ui->listWidget_2->setCurrentIndex(pOperationData->uchTypeComm-1);
                    pOperationData->NumerLevelConnectCommutator=0;
                }
                break;
            case 2:
                if(pOperationData->NumerLevelConnectCommutator!=1)
                {
                    pOperationData->NumerLevelConnectCommutator=pOperationData->NumerLevelConnectCommutator+1;
                    emit NextLevelSetGainSettingSignal(1);
                }
                else
                {
                    pOperationData->Flag=0;
                    UpadateGui();
                    ui->listWidget_2->setCurrentIndex(pOperationData->uchTypeComm-1);
                    pOperationData->NumerLevelConnectCommutator=0;
                }
                break;
            case 3:
                if(pOperationData->NumerLevelConnectCommutator!=1)
                {
                    pOperationData->NumerLevelConnectCommutator=pOperationData->NumerLevelConnectCommutator+1;
                    emit NextLevelGetGainSettingSignal(1);
                }
                else
                {
                    pOperationData->Flag=0;
                    UpadateGui();
                    ui->listWidget_2->setCurrentIndex(pOperationData->uchTypeComm-1);
                    pOperationData->NumerLevelConnectCommutator=0;
                }
                break;
      }
  }
  if(numer==2)// ответ от коммутатора не получен
  {
      if(pOperationData->NumerTrueSendPack!=2)
      {
          emit SendPackSignal(pOperationData->NumerAction);
          pOperationData->NumerTrueSendPack=pOperationData->NumerTrueSendPack+1;
      }
      else
      {
            pOperationData->Flag=0;
            pOperationData->NumerLevelConnectCommutator=0;
            pOperationData->NumerTrueSendPack=0;
            str="> "+ptime.toString("hh.mm.ss")+"  ";
            str=str+"Ответ от коммутатора не получен";
            ui->textEdit->append(str);
            //DisBlockGui();
            //только для демонстрации программы
            EnBlockGui();
      }
  }
}

void MainWindow::ConnectCommutatorSlot(uchar numer)
{
    switch (pOperationData->NumerLevelConnectCommutator)
    {
        case 0:
            pOperationData->NumerAction=205;
            emit SendPackSignal(pOperationData->NumerAction);
        break;
        case 1:
            pOperationData->NumerAction=206;
            emit SendPackSignal(pOperationData->NumerAction);
        break;     
        case 2:
             pOperationData->NumerAction=207;
             emit SendPackSignal(pOperationData->NumerAction);
        break;
        case 3:
             pOperationData->NumerAction=209;
             emit SendPackSignal(pOperationData->NumerAction);
        break;
        case 4:
             pOperationData->NumerAction=210;
             emit SendPackSignal(pOperationData->NumerAction);
        break;   
        case 5:
            pOperationData->NumerAction=208;
            emit SendPackSignal(pOperationData->NumerAction);
        break;
    default:
        break;
    }
}
void MainWindow::ReadPackSlot()
{
    int i,xt;
    QByteArray Datagram;
    do {
        Datagram.resize(pQUdpSocket->pendingDatagramSize());
        pQUdpSocket->readDatagram(Datagram.data(), Datagram.size());
       }while(pQUdpSocket->hasPendingDatagrams());

    if((Datagram.size()>=9u)&(Datagram.size()<60))
    {
           for(i=0;i<59;i++)
           {
              punPack->chDataPack[i]=Datagram[i];
           }
           if(punPack->Data_Pack.PayHeader.IDP_FIELD==IDP_IDO_PAY)
           {
               if(punPack->Data_Pack.PayHeader.IDO_FIELD==TypeCommutator[pOperationData->uchTypeComm-1])
               {
                   if(punPack->Data_Pack.PayHeader.KOP_FIELD==0x00)
                   {
                     if(punPack->Data_Pack.PayHeader.DLC_FIELD>9u)
                     {
                         switch(punPack->Data_Pack.PayHeader.NP_FIELD)
                         {
                              case 1:
                                   pOperationData->nIpComm=punPack->Data_Pack.IPaddresCommutator.Ipcom;
                                   emit CommutatorReqestSignal(1);
                                   break;
                              case 2:
                                   emit CommutatorReqestSignal(1);
                                   break;
                              case 3:
                                   pOperationData->usnNumberPortComm=punPack->Data_Pack.UDPPortCommutator.UdpPort;
                                   emit CommutatorReqestSignal(1);
                                   break;
                              case 4:
                                   pOperationData->musnMacComm[0]=punPack->Data_Pack.MACCommutator.MACcom[0];
                                   pOperationData->musnMacComm[1]=punPack->Data_Pack.MACCommutator.MACcom[1];
                                   pOperationData->musnMacComm[2]=punPack->Data_Pack.MACCommutator.MACcom[2];
                                   emit CommutatorReqestSignal(1);
                                   break;
                              case 5:
                                   for(i=0;i<16;i++)
                                   {
                                       pOperationData->muchSwitchComm[i]=punPack->Data_Pack.SettingCommutator.OUT_OR_IN_Numer[i];
                                       if(i<8)
                                       {
                                            pOperationData->muchGainManger[i]=punPack->Data_Pack.SettingCommutator.TransferFactor[i];
                                       }
                                   }
                                   pOperationData->uchStatusFlags=punPack->Data_Pack.SettingCommutator.FlagState;
                                   emit CommutatorReqestSignal(1);
                                   break;
                              case 6:
                                   pOperationData->usnTemperatureN1=punPack->Data_Pack.SettingCommutator.TemperaruraPlataN1;
                                   pOperationData->usnTemperatureN2=punPack->Data_Pack.SettingCommutator.TemperaruraPlataN2;
                                   emit CommutatorReqestSignal(1);
                                   break;
                              case 7:
                                    for(i=0;i<12;i++)
                                    {
                                        pOperationData->muchFactoryNumer[i]=punPack->Data_Pack.SettingSystemCommutator.FactoryNummer[i];
                                        if(i<8)
                                        {
                                            pOperationData->muchGainCorrectNool[i]=punPack->Data_Pack.SettingSystemCommutator.GainCorrectChennel[i];
                                            pOperationData->muchGainCorrectMinus[i]=punPack->Data_Pack.SettingSystemCommutator.GainCorrectMinus[i];
                                            pOperationData->muchGainCorrectNool[i]=punPack->Data_Pack.SettingSystemCommutator.GainCorrectNool[i];
                                            pOperationData->muchGainCorrectPlus[i]=punPack->Data_Pack.SettingSystemCommutator.GainCorrectPlus[i];
                                        }
                                    }
                                   pOperationData->uchTypeComm=punPack->Data_Pack.SettingSystemCommutator.TypeCommutator;
                                   emit CommutatorReqestSignal(1);
                                   break;
                          }
                     }
                     else
                     {
                          emit CommutatorReqestSignal(1);
                     }
                   }
               }
           }
    }
}

void MainWindow::SetGainSettingSlot(uchar numer)
{
   QString str;
   switch(pOperationData->NumerLevelConnectCommutator)
   {
        case 0:
             pOperationData->NumerAction=112;
             str="> "+ptime.toString("hh.mm.ss")+"  ";
             str=str+"Установка  коэффициентов передачи каналов коммутатора";
             ui->textEdit->append(str);
             emit SendPackSignal(pOperationData->NumerAction);
             break;
        case 1:
             pOperationData->NumerAction=113;
             str="> "+ptime.toString("hh.mm.ss")+"  ";
             str=str+"Установка  коррекций уровня сигнала при единичном коэффициенте передачи каналов коммутатора";
             ui->textEdit->append(str);
             emit SendPackSignal(pOperationData->NumerAction);
             break;
   }
}

void MainWindow::GetGainSettingSlot(uchar numer)
{
    QString str;
    switch(pOperationData->NumerLevelConnectCommutator)
    {
         case 0:
              pOperationData->NumerAction=211;
              str="> "+ptime.toString("hh.mm.ss")+"  ";
              str=str+"Запрос коэффициентов передачи каналов коммутатора";
              ui->textEdit->append(str);
              emit SendPackSignal(pOperationData->NumerAction);         
              break;
         case 1:
              pOperationData->NumerAction=212;
              str="> "+ptime.toString("hh.mm.ss")+"  ";
              str=str+"Запрос  коррекций уровня сигнала при единичном коэффициенте передачи каналов коммутатора";
              ui->textEdit->append(str);
              emit SendPackSignal(pOperationData->NumerAction);
              break;
    }
}

void MainWindow::SocetErrorSlot()
{
    int i;
    QString str;
    str=pQUdpSocket->errorString();
    i=1;
}



