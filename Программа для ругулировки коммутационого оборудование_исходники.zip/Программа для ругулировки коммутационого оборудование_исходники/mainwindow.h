#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QtNetwork>
#include <QAbstractSocket>
#include <QTime>
#include <base_type.h>

namespace Ui {
class MainWindow;
}





class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    void InitSettingCommutator(unsigned char mode);
    void SetSystemInfoCommutator(void);
    void SetSettingCommutator(void);
    void SetReqestPack(unsigned char TypeMessage, unsigned char NumerPack);
    void UpadateGui(void);
    void EnBlockGui(void);
    void DisBlockGui(void);
    void ResetGui(void);
    ~MainWindow();

public slots:
    //**********************************
    void PushConnectCommutatorSlot();
    void PushDiesConnectCommutatorSlot();
    void PushResetCommutatorSlot();
    void PushSetFactoryNumerSlot();
    void PushSetIPSlot();
    void PushSetUDPPortSlot();
    void PushSetMACCommutatorSlot();
    void PushSetIPPauSlot();
    void PushSetSystemChennelCommutatorSlot();
    void PushSetSMDMChennelSlot();
    void PushSetSMChennelSlot();
    void PushSetDMChennelSlot();
    void PushGetSMDMChennelSlot();
    void PushGetSMChennelSlot();
    void PushGetDMChennelSlot();
    void PushSetGainSettingSlot();
    void PushGetGainSettingSlot();
    void PushSetGainCorrectSlot();
    void PushGetGainCorrectSlot();
   //**********************************
    void SwitchActionSlot(uchar numer);
    void SendPackSlot(uchar numer);
    void TimeHasComeSlot(void);
    void HeaderActionSwitchSlot(uchar numer);
    void ConnectCommutatorSlot(uchar numer);
    void ReadPackSlot(void);
    void SetGainSettingSlot(uchar numer);
    void GetGainSettingSlot(uchar numer);
    void SocetErrorSlot(void);

signals:
    void NumerActionGuiSignal(uchar numer);
    void StartConnectCommutatorSignal(uchar numer);
    void SendPackSignal(uchar numer);
    void CommutatorNotReqestSignal(uchar numer);
    void CommutatorReqestSignal(uchar numer);
    void NextLevelCoonnectCommutatorSignal(uchar numer);
    void StartSetGainSettingSignal(uchar numer);
    void StartGetGainSettingSignal(uchar numer);
    void NextLevelSetGainSettingSignal(uchar numer);
    void NextLevelGetGainSettingSignal(uchar numer);

private slots:
    void on_listWidget_2_currentIndexChanged(int index);

    void on_listWidget_currentIndexChanged(int index);

    void on_FactoryName_textChanged(const QString &arg1);

    void on_Ipaddres_textChanged(const QString &arg1);

    void on_NumberPort_textChanged(const QString &arg1);

    void on_MAC_address_textChanged(const QString &arg1);

    void on_Ipaddres_PAY_textChanged(const QString &arg1);

    void on_radioButton_vih2_clicked();

    void on_radioButton_vih1_clicked();

    void on_radioButton_vih3_clicked();

    void on_radioButton_vih4_clicked();

    void on_radioButton_vh1_clicked();

    void on_radioButton_vh2_clicked();

    void on_radioButton_vh3_clicked();

    void on_radioButton_vh4_clicked();

    void on_sw1vhvih_currentIndexChanged(int index);

    void on_sw2vhvih_currentIndexChanged(int index);

    void on_sw3vhvih_currentIndexChanged(int index);

    void on_sw4vhvih_currentIndexChanged(int index);

    void on_sw5vhvih_currentIndexChanged(int index);

    void on_sw6vhvih_currentIndexChanged(int index);

    void on_sw7vhvih_currentIndexChanged(int index);

    void on_sw8vhvih_currentIndexChanged(int index);

    void on_sw9vhvih_currentIndexChanged(int index);

    void on_sw10vhvih_currentIndexChanged(int index);

    void on_sw12vhvih_currentIndexChanged(int index);

    void on_sw13vhvih_currentIndexChanged(int index);

    void on_sw14vhvih_currentIndexChanged(int index);

    void on_sw15vhvih_currentIndexChanged(int index);

    void on_sw11vhvih_currentIndexChanged(int index);

    void on_sw1vih_currentIndexChanged(int index);

    void on_sw16vih_currentIndexChanged(int index);

    void on_sw16vhvih_currentIndexChanged(int index);

    void on_sw2vih_currentIndexChanged(int index);

    void on_sw3vih_currentIndexChanged(int index);

    void on_sw4vih_currentIndexChanged(int index);

    void on_sw5vih_currentIndexChanged(int index);

    void on_sw6vih_currentIndexChanged(int index);

    void on_sw7vih_currentIndexChanged(int index);

    void on_sw8vih_currentIndexChanged(int index);

    void on_sw9vih_currentIndexChanged(int index);

    void on_sw10vih_currentIndexChanged(int index);

    void on_sw11vih_currentIndexChanged(int index);

    void on_sw12vih_currentIndexChanged(int index);

    void on_sw13vih_currentIndexChanged(int index);

    void on_sw14vih_currentIndexChanged(int index);

    void on_sw15vih_currentIndexChanged(int index);

    void on_sw1vh1_currentIndexChanged(int index);

    void on_sw1vh2_currentIndexChanged(int index);

    void on_sw1vh3_currentIndexChanged(int index);

    void on_sw1vh4_currentIndexChanged(int index);

    void on_sw1vh5_currentIndexChanged(int index);

    void on_sw1vh6_currentIndexChanged(int index);

    void on_sw1vh7_currentIndexChanged(int index);

    void on_sw1vh8_currentIndexChanged(int index);

    void on_sw1vh9_currentIndexChanged(int index);

    void on_sw1vh10_currentIndexChanged(int index);

    void on_sw1vh11_currentIndexChanged(int index);

    void on_sw1vh12_currentIndexChanged(int index);

    void on_sw1vh13_currentIndexChanged(int index);

    void on_sw1vh14_currentIndexChanged(int index);

    void on_sw1vh15_currentIndexChanged(int index);

    void on_sw1vh16_currentIndexChanged(int index);

    void on_horizontalSlider1a_sliderMoved(int position);

    void on_horizontalSlider2a_sliderMoved(int position);

    void on_horizontalSlider3a_sliderMoved(int position);

    void on_horizontalSlider4a_sliderMoved(int position);

    void on_horizontalSlider5a_sliderMoved(int position);

    void on_horizontalSlider6a_sliderMoved(int position);

    void on_horizontalSlider7a_sliderMoved(int position);

    void on_horizontalSlider8a_sliderMoved(int position);

    void on_horizontalSlider1b_sliderMoved(int position);

    void on_horizontalSlider2b_sliderMoved(int position);

    void on_horizontalSlider3b_sliderMoved(int position);

    void on_horizontalSlider4b_sliderMoved(int position);

    void on_horizontalSlider5b_sliderMoved(int position);

    void on_horizontalSlider6b_sliderMoved(int position);

    void on_horizontalSlider7b_sliderMoved(int position);

    void on_horizontalSlider8b_sliderMoved(int position);

    void on_cof1_1_textChanged(const QString &arg1);

    void on_cof2_1_textChanged(const QString &arg1);

    void on_cof3_1_textChanged(const QString &arg1);

    void on_cof4_1_textChanged(const QString &arg1);

    void on_cof5_1_textChanged(const QString &arg1);

    void on_cof6_1_textChanged(const QString &arg1);

    void on_cof7_1_textChanged(const QString &arg1);

    void on_cof8_1_textChanged(const QString &arg1);

    void on_cof1_2_textChanged(const QString &arg1);

    void on_cof2_2_textChanged(const QString &arg1);

    void on_cof3_2_textChanged(const QString &arg1);

    void on_cof4_2_textChanged(const QString &arg1);

    void on_cof5_2_textChanged(const QString &arg1);

    void on_cof6_2_textChanged(const QString &arg1);

    void on_cof7_2_textChanged(const QString &arg1);

    void on_cof8_2_textChanged(const QString &arg1);

    void on_cof1_3_textChanged(const QString &arg1);

    void on_cof2_3_textChanged(const QString &arg1);

    void on_cof3_3_textChanged(const QString &arg1);

    void on_cof4_3_textChanged(const QString &arg1);

    void on_cof5_3_textChanged(const QString &arg1);

    void on_cof6_3_textChanged(const QString &arg1);

    void on_cof7_3_textChanged(const QString &arg1);

    void on_cof8_3_textChanged(const QString &arg1);


private:
    Ui::MainWindow *ui;
    QTimer *pTimer;
    QTime ptime;
    OperationData *pOperationData;
    QUdpSocket *pQUdpSocket;
    unPack *punPack;
};




#endif // MAINWINDOW_H
