#include "mainwindow.h"
#include "ui_mainwindow.h"

//GUI

void MainWindow::UpadateGui()
{
    int i;
    QString str;
    QString str1[12];
    float temp;
    EnBlockGui();
    ui->lineEdit_IP->setText(QHostAddress(QString::number(pOperationData->nIpComm)).toString());
    ui->lineEdit_NumPort->setText(QString::number(pOperationData->usnNumberPortComm));
    switch (pOperationData->uchTypeComm)
    {
        case 1:
            ui->lineEdit_3->setText("СМ16-4");
            break;
        case 2:
            ui->lineEdit_3->setText("ДМ4-16");
            break;
        case 3:
            ui->lineEdit_3->setText("СМДМ8-4");
            break;
        default:
            ui->lineEdit_3->setText("СМ16-4");
            break;
    }
    union
    {
      uchar data[12];
      ushort wdata[6];
    };
    for(i=0;i<12;i++)
    {
        data[i]=pOperationData->muchFactoryNumer[i];
    }
    str.setUtf16((const ushort*)wdata,6);
    ui->lineEdit_4->setText(str);
    temp=(((float)pOperationData->usnTemperatureN1)*0.0625)-55.0;
    ui->temp1->setText(QString::number(temp,'f',2));
    temp=(((float)pOperationData->usnTemperatureN2)*0.0625)-55.0;
    ui->temp1_2->setText(QString::number(temp,'f',2));
    wdata[0]=pOperationData->musnMacComm[0];
    wdata[1]=pOperationData->musnMacComm[1];
    wdata[2]=pOperationData->musnMacComm[2];
    str="";
    for(i=0;i<6;i++)
    {
         str1[i].setNum(data[i],16);
         str=str+str1[i];
         if(i<5)
         {
            str=str+":";
         }
    }
    ui->MAC_address_2->setText(str);
    data[0]=pOperationData->uchStatusFlags;
    data[1]=0;
    ui->status_ln->setText(QString::number(wdata[0]));
    switch (pOperationData->uchWork)
    {
    case 0:
        ui->radioButton_vih1->setCheckable(false);
        ui->radioButton_vih2->setCheckable(false);
        ui->radioButton_vih3->setCheckable(false);
        ui->radioButton_vih4->setCheckable(false);
        ui->radioButton_vh1->setCheckable(false);
        ui->radioButton_vh2->setCheckable(false);
        ui->radioButton_vh3->setCheckable(false);
        ui->radioButton_vh4->setCheckable(false);
        ui->radioButton_vih1->setCheckable(true);
        ui->radioButton_vih2->setCheckable(true);
        ui->radioButton_vih3->setCheckable(true);
        ui->radioButton_vih4->setCheckable(true);
        ui->radioButton_vh1->setCheckable(true);
        ui->radioButton_vh2->setCheckable(true);
        ui->radioButton_vh3->setCheckable(true);
        ui->radioButton_vh4->setCheckable(true);
        break;

    case 1:
        switch (pOperationData->uchTypeComm)
        {
            case 1:
                ui->radioButton_vih1->setChecked(true);
                break;
            case 2:
                ui->radioButton_vh1->setChecked(true);
                break;
            case 3:
                ui->radioButton_vih1->setChecked(true);
            default:
                break;
        }
        break;
    case 2:
        switch (pOperationData->uchTypeComm)
        {
            case 1:
                ui->radioButton_vih2->setChecked(true);
                break;
            case 2:
                ui->radioButton_vh2->setChecked(true);
                break;
            case 3:
                ui->radioButton_vih2->setChecked(true);
            default:
                break;
        }
        break;
    case 3:
        switch (pOperationData->uchTypeComm)
        {
            case 1:
                ui->radioButton_vih3->setChecked(true);
                break;
            case 2:
                ui->radioButton_vh3->setChecked(true);
                break;
            case 3:
                ui->radioButton_vih3->setChecked(true);
            default:
                break;
        }
        break;
    case 4:
        switch (pOperationData->uchTypeComm)
        {
            case 1:
                ui->radioButton_vih4->setChecked(true);
                break;
            case 2:
                ui->radioButton_vh4->setChecked(true);
                break;
            case 3:
                ui->radioButton_vih4->setChecked(true);
            default:
                break;
        }
        break;
    case 5:
        ui->radioButton_vh1->setChecked(true);
        break;
    case 6:
        ui->radioButton_vh2->setChecked(true);
        break;
    case 7:
        ui->radioButton_vh3->setChecked(true);
        break;
    case 8:
        ui->radioButton_vh4->setChecked(true);
        break;
    default:
        break;
    }
     ui->CMDM8->setText(QString::number(pOperationData->muchSwitchComm[0]));
     ui->CMDM8_2->setText(QString::number(pOperationData->muchSwitchComm[1]));
     ui->CMDM8_3->setText(QString::number(pOperationData->muchSwitchComm[2]));
     ui->CMDM8_4->setText(QString::number(pOperationData->muchSwitchComm[3]));
     ui->CMDM8_5->setText(QString::number(pOperationData->muchSwitchComm[4]));
     ui->CMDM8_6->setText(QString::number(pOperationData->muchSwitchComm[5]));
     ui->CMDM8_7->setText(QString::number(pOperationData->muchSwitchComm[6]));
     ui->CMDM8_8->setText(QString::number(pOperationData->muchSwitchComm[7]));
     ui->CMDM8_9->setText(QString::number(pOperationData->muchSwitchComm[8]));
     ui->CMDM8_10->setText(QString::number(pOperationData->muchSwitchComm[9]));
     ui->CMDM8_11->setText(QString::number(pOperationData->muchSwitchComm[10]));
     ui->CMDM8_12->setText(QString::number(pOperationData->muchSwitchComm[11]));
     ui->CMDM8_13->setText(QString::number(pOperationData->muchSwitchComm[12]));
     ui->CMDM8_14->setText(QString::number(pOperationData->muchSwitchComm[13]));
     ui->CMDM8_15->setText(QString::number(pOperationData->muchSwitchComm[14]));
     ui->CMDM8_16->setText(QString::number(pOperationData->muchSwitchComm[15]));
     ui->sw1vhvih->setCurrentIndex(pOperationData->muchSwitchComm[0]);
     ui->sw2vhvih->setCurrentIndex(pOperationData->muchSwitchComm[1]);
     ui->sw3vhvih->setCurrentIndex(pOperationData->muchSwitchComm[2]);
     ui->sw4vhvih->setCurrentIndex(pOperationData->muchSwitchComm[3]);
     ui->sw5vhvih->setCurrentIndex(pOperationData->muchSwitchComm[4]);
     ui->sw6vhvih->setCurrentIndex(pOperationData->muchSwitchComm[5]);
     ui->sw7vhvih->setCurrentIndex(pOperationData->muchSwitchComm[6]);
     ui->sw8vhvih->setCurrentIndex(pOperationData->muchSwitchComm[7]);
     ui->sw9vhvih->setCurrentIndex(pOperationData->muchSwitchComm[8]);
     ui->sw10vhvih->setCurrentIndex(pOperationData->muchSwitchComm[9]);
     ui->sw11vhvih->setCurrentIndex(pOperationData->muchSwitchComm[10]);
     ui->sw12vhvih->setCurrentIndex(pOperationData->muchSwitchComm[11]);
     ui->sw13vhvih->setCurrentIndex(pOperationData->muchSwitchComm[12]);
     ui->sw14vhvih->setCurrentIndex(pOperationData->muchSwitchComm[13]);
     ui->sw15vhvih->setCurrentIndex(pOperationData->muchSwitchComm[14]);
     ui->sw16vhvih->setCurrentIndex(pOperationData->muchSwitchComm[15]);
     ui->CM16->setText(QString::number(pOperationData->muchSwitchComm[0]));
     ui->CM16_2->setText(QString::number(pOperationData->muchSwitchComm[1]));
     ui->CM16_3->setText(QString::number(pOperationData->muchSwitchComm[2]));
     ui->CM16_4->setText(QString::number(pOperationData->muchSwitchComm[3]));
     ui->CM16_5->setText(QString::number(pOperationData->muchSwitchComm[4]));
     ui->CM16_6->setText(QString::number(pOperationData->muchSwitchComm[5]));
     ui->CM16_7->setText(QString::number(pOperationData->muchSwitchComm[6]));
     ui->CM16_8->setText(QString::number(pOperationData->muchSwitchComm[7]));
     ui->CM16_9->setText(QString::number(pOperationData->muchSwitchComm[8]));
     ui->CM16_10->setText(QString::number(pOperationData->muchSwitchComm[9]));
     ui->CM16_11->setText(QString::number(pOperationData->muchSwitchComm[10]));
     ui->CM16_12->setText(QString::number(pOperationData->muchSwitchComm[11]));
     ui->CM16_13->setText(QString::number(pOperationData->muchSwitchComm[12]));
     ui->CM16_14->setText(QString::number(pOperationData->muchSwitchComm[13]));
     ui->CM16_15->setText(QString::number(pOperationData->muchSwitchComm[14]));
     ui->CM16_16->setText(QString::number(pOperationData->muchSwitchComm[15]));
     ui->sw1vih->setCurrentIndex(pOperationData->muchSwitchComm[0]);
     ui->sw2vih->setCurrentIndex(pOperationData->muchSwitchComm[1]);
     ui->sw3vih->setCurrentIndex(pOperationData->muchSwitchComm[2]);
     ui->sw4vih->setCurrentIndex(pOperationData->muchSwitchComm[3]);
     ui->sw5vih->setCurrentIndex(pOperationData->muchSwitchComm[4]);
     ui->sw6vih->setCurrentIndex(pOperationData->muchSwitchComm[5]);
     ui->sw7vih->setCurrentIndex(pOperationData->muchSwitchComm[6]);
     ui->sw8vih->setCurrentIndex(pOperationData->muchSwitchComm[7]);
     ui->sw9vih->setCurrentIndex(pOperationData->muchSwitchComm[8]);
     ui->sw10vih->setCurrentIndex(pOperationData->muchSwitchComm[9]);
     ui->sw11vih->setCurrentIndex(pOperationData->muchSwitchComm[10]);
     ui->sw12vih->setCurrentIndex(pOperationData->muchSwitchComm[11]);
     ui->sw13vih->setCurrentIndex(pOperationData->muchSwitchComm[12]);
     ui->sw14vih->setCurrentIndex(pOperationData->muchSwitchComm[13]);
     ui->sw15vih->setCurrentIndex(pOperationData->muchSwitchComm[14]);
     ui->sw16vih->setCurrentIndex(pOperationData->muchSwitchComm[15]);
     ui->DM4->setText(QString::number(pOperationData->muchSwitchComm[0]));
     ui->DM4_2->setText(QString::number(pOperationData->muchSwitchComm[1]));
     ui->DM4_3->setText(QString::number(pOperationData->muchSwitchComm[2]));
     ui->DM4_4->setText(QString::number(pOperationData->muchSwitchComm[3]));
     ui->DM4_5->setText(QString::number(pOperationData->muchSwitchComm[4]));
     ui->DM4_6->setText(QString::number(pOperationData->muchSwitchComm[5]));
     ui->DM4_7->setText(QString::number(pOperationData->muchSwitchComm[6]));
     ui->DM4_8->setText(QString::number(pOperationData->muchSwitchComm[7]));
     ui->DM4_9->setText(QString::number(pOperationData->muchSwitchComm[8]));
     ui->DM4_10->setText(QString::number(pOperationData->muchSwitchComm[9]));
     ui->DM4_11->setText(QString::number(pOperationData->muchSwitchComm[10]));
     ui->DM4_12->setText(QString::number(pOperationData->muchSwitchComm[11]));
     ui->DM4_13->setText(QString::number(pOperationData->muchSwitchComm[12]));
     ui->DM4_14->setText(QString::number(pOperationData->muchSwitchComm[13]));
     ui->DM4_15->setText(QString::number(pOperationData->muchSwitchComm[14]));
     ui->DM4_16->setText(QString::number(pOperationData->muchSwitchComm[15]));
     ui->sw1vh1->setCurrentIndex(pOperationData->muchSwitchComm[0]);
     ui->sw1vh2->setCurrentIndex(pOperationData->muchSwitchComm[1]);
     ui->sw1vh3->setCurrentIndex(pOperationData->muchSwitchComm[2]);
     ui->sw1vh4->setCurrentIndex(pOperationData->muchSwitchComm[3]);
     ui->sw1vh5->setCurrentIndex(pOperationData->muchSwitchComm[4]);
     ui->sw1vh6->setCurrentIndex(pOperationData->muchSwitchComm[5]);
     ui->sw1vh7->setCurrentIndex(pOperationData->muchSwitchComm[6]);
     ui->sw1vh8->setCurrentIndex(pOperationData->muchSwitchComm[7]);
     ui->sw1vh9->setCurrentIndex(pOperationData->muchSwitchComm[8]);
     ui->sw1vh10->setCurrentIndex(pOperationData->muchSwitchComm[9]);
     ui->sw1vh11->setCurrentIndex(pOperationData->muchSwitchComm[10]);
     ui->sw1vh12->setCurrentIndex(pOperationData->muchSwitchComm[11]);
     ui->sw1vh13->setCurrentIndex(pOperationData->muchSwitchComm[12]);
     ui->sw1vh14->setCurrentIndex(pOperationData->muchSwitchComm[13]);
     ui->sw1vh15->setCurrentIndex(pOperationData->muchSwitchComm[14]);
     ui->sw1vh16->setCurrentIndex(pOperationData->muchSwitchComm[15]);
     ui->lineEdit1d->setText(QString::number((((float)(pOperationData->muchGainManger[0])-20.0)/2.0)));
     ui->lineEdit2d->setText(QString::number((((float)(pOperationData->muchGainManger[1])-20.0)/2.0)));
     ui->lineEdit3d->setText(QString::number((((float)(pOperationData->muchGainManger[2])-20.0)/2.0)));
     ui->lineEdit4d->setText(QString::number((((float)(pOperationData->muchGainManger[3])-20.0)/2.0)));
     ui->lineEdit5d->setText(QString::number((((float)(pOperationData->muchGainManger[4])-20.0)/2.0)));
     ui->lineEdit6d->setText(QString::number((((float)(pOperationData->muchGainManger[5])-20.0)/2.0)));
     ui->lineEdit7d->setText(QString::number((((float)(pOperationData->muchGainManger[6])-20.0)/2.0)));
     ui->lineEdit8d->setText(QString::number((((float)(pOperationData->muchGainManger[7])-20.0)/2.0)));

     ui->lineEdit1b->setText(QString::number((((float)(pOperationData->muchGainManger[0])-20.0)/2.0)));
     ui->lineEdit2b->setText(QString::number((((float)(pOperationData->muchGainManger[1])-20.0)/2.0)));
     ui->lineEdit3b->setText(QString::number((((float)(pOperationData->muchGainManger[2])-20.0)/2.0)));
     ui->lineEdit4b->setText(QString::number((((float)(pOperationData->muchGainManger[3])-20.0)/2.0)));
     ui->lineEdit5b->setText(QString::number((((float)(pOperationData->muchGainManger[4])-20.0)/2.0)));
     ui->lineEdit6b->setText(QString::number((((float)(pOperationData->muchGainManger[5])-20.0)/2.0)));
     ui->lineEdit7b->setText(QString::number((((float)(pOperationData->muchGainManger[6])-20.0)/2.0)));
     ui->lineEdit8b->setText(QString::number((((float)(pOperationData->muchGainManger[7])-20.0)/2.0)));


     ui->horizontalSlider1b->setValue(((((float)(pOperationData->muchGainManger[0])))));
     ui->horizontalSlider2b->setValue(((((float)(pOperationData->muchGainManger[1])))));
     ui->horizontalSlider3b->setValue(((((float)(pOperationData->muchGainManger[2])))));
     ui->horizontalSlider4b->setValue(((((float)(pOperationData->muchGainManger[3])))));
     ui->horizontalSlider5b->setValue(((((float)(pOperationData->muchGainManger[4])))));
     ui->horizontalSlider6b->setValue(((((float)(pOperationData->muchGainManger[5])))));
     ui->horizontalSlider7b->setValue(((((float)(pOperationData->muchGainManger[6])))));
     ui->horizontalSlider8b->setValue(((((float)(pOperationData->muchGainManger[7])))));
     ui->lineEdit1c->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[0]))/2.0)));
     ui->lineEdit2c->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[1]))/2.0)));
     ui->lineEdit3c->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[2]))/2.0)));
     ui->lineEdit4c->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[3]))/2.0)));
     ui->lineEdit5c->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[4]))/2.0)));
     ui->lineEdit6c->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[5]))/2.0)));
     ui->lineEdit7c->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[6]))/2.0)));
     ui->lineEdit8c->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[7]))/2.0)));

     ui->lineEdit1a->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[0]))/2.0)));
     ui->lineEdit2a->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[1]))/2.0)));
     ui->lineEdit3a->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[2]))/2.0)));
     ui->lineEdit4a->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[3]))/2.0)));
     ui->lineEdit5a->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[4]))/2.0)));
     ui->lineEdit6a->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[5]))/2.0)));
     ui->lineEdit7a->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[6]))/2.0)));
     ui->lineEdit8a->setText(QString::number((((float)(pOperationData->muchGainCorrectNool[7]))/2.0)));
     ui->horizontalSlider1a->setValue(((((float)(pOperationData->muchGainCorrectNool[0])))));
     ui->horizontalSlider2a->setValue(((((float)(pOperationData->muchGainCorrectNool[1])))));
     ui->horizontalSlider3a->setValue(((((float)(pOperationData->muchGainCorrectNool[2])))));
     ui->horizontalSlider4a->setValue(((((float)(pOperationData->muchGainCorrectNool[3])))));
     ui->horizontalSlider5a->setValue(((((float)(pOperationData->muchGainCorrectNool[4])))));
     ui->horizontalSlider6a->setValue(((((float)(pOperationData->muchGainCorrectNool[5])))));
     ui->horizontalSlider7a->setValue(((((float)(pOperationData->muchGainCorrectNool[6])))));
     ui->horizontalSlider8a->setValue(((((float)(pOperationData->muchGainCorrectNool[7])))));
     ui->cof1_4->setText(QString::number((((float)(pOperationData->muchGainCorrectMinus[0]))/2.0)));
     ui->cof2_4->setText(QString::number((((float)(pOperationData->muchGainCorrectMinus[1]))/2.0)));
     ui->cof3_4->setText(QString::number((((float)(pOperationData->muchGainCorrectMinus[2]))/2.0)));
     ui->cof4_4->setText(QString::number((((float)(pOperationData->muchGainCorrectMinus[3]))/2.0)));
     ui->cof5_4->setText(QString::number((((float)(pOperationData->muchGainCorrectMinus[4]))/2.0)));
     ui->cof6_4->setText(QString::number((((float)(pOperationData->muchGainCorrectMinus[5]))/2.0)));
     ui->cof7_4->setText(QString::number((((float)(pOperationData->muchGainCorrectMinus[6]))/2.0)));
     ui->cof8_4->setText(QString::number((((float)(pOperationData->muchGainCorrectMinus[7]))/2.0)));
     ui->cof1_5->setText(QString::number((((float)(pOperationData->muchGainCorrectNormal[0]))/2.0)));
     ui->cof2_5->setText(QString::number((((float)(pOperationData->muchGainCorrectNormal[1]))/2.0)));
     ui->cof3_5->setText(QString::number((((float)(pOperationData->muchGainCorrectNormal[2]))/2.0)));
     ui->cof4_5->setText(QString::number((((float)(pOperationData->muchGainCorrectNormal[3]))/2.0)));
     ui->cof5_5->setText(QString::number((((float)(pOperationData->muchGainCorrectNormal[4]))/2.0)));
     ui->cof6_5->setText(QString::number((((float)(pOperationData->muchGainCorrectNormal[5]))/2.0)));
     ui->cof7_5->setText(QString::number((((float)(pOperationData->muchGainCorrectNormal[6]))/2.0)));
     ui->cof8_5->setText(QString::number((((float)(pOperationData->muchGainCorrectNormal[7]))/2.0)));
     ui->cof1_6->setText(QString::number((((float)(pOperationData->muchGainCorrectPlus[0]))/2.0)));
     ui->cof2_6->setText(QString::number((((float)(pOperationData->muchGainCorrectPlus[1]))/2.0)));
     ui->cof3_6->setText(QString::number((((float)(pOperationData->muchGainCorrectPlus[2]))/2.0)));
     ui->cof4_6->setText(QString::number((((float)(pOperationData->muchGainCorrectPlus[3]))/2.0)));
     ui->cof5_6->setText(QString::number((((float)(pOperationData->muchGainCorrectPlus[4]))/2.0)));
     ui->cof6_6->setText(QString::number((((float)(pOperationData->muchGainCorrectPlus[5]))/2.0)));
     ui->cof7_6->setText(QString::number((((float)(pOperationData->muchGainCorrectPlus[6]))/2.0)));
     ui->cof8_6->setText(QString::number((((float)(pOperationData->muchGainCorrectPlus[7]))/2.0)));
}

void MainWindow::EnBlockGui()
{
    ui->groupBox_2->setEnabled(true);
    ui->groupBoxSM->setEnabled(true);
    ui->tab_2->setEnabled(true);
    ui->tab_3->setEnabled(true);
    ui->tab_4->setEnabled(true);
    ui->pushButton->setEnabled(false);
    ui->listWidget_2->setEnabled(false);
    ui->pushButton_8->setEnabled(true);
    switch (pOperationData->uchTypeComm) {
    case 1:
            ui->CM16_4_C->setEnabled(true);
            ui->CMDM8_4_C->setEnabled(false);
            ui->DM4_16_C->setEnabled(false);
            ui->groupBoxys1->setEnabled(true);
            ui->groupBox_ys2->setEnabled(true);
            ui->groupBox_ys3->setEnabled(true);
            ui->groupBox_ys4->setEnabled(true);
            ui->groupBoxys5->setEnabled(false);
            ui->groupBoxys6->setEnabled(false);
            ui->groupBoxys7->setEnabled(false);
            ui->groupBoxys8->setEnabled(false);
            ui->cof5_1->setEnabled(false);
            ui->cof5_2->setEnabled(false);
            ui->cof5_3->setEnabled(false);
            ui->cof5_4->setEnabled(false);
            ui->cof5_5->setEnabled(false);
            ui->cof5_6->setEnabled(false);
            ui->cof6_1->setEnabled(false);
            ui->cof6_2->setEnabled(false);
            ui->cof6_3->setEnabled(false);
            ui->cof6_4->setEnabled(false);
            ui->cof6_5->setEnabled(false);
            ui->cof6_6->setEnabled(false);
            ui->cof7_1->setEnabled(false);
            ui->cof7_2->setEnabled(false);
            ui->cof7_3->setEnabled(false);
            ui->cof7_4->setEnabled(false);
            ui->cof7_5->setEnabled(false);
            ui->cof7_6->setEnabled(false);
            ui->cof8_1->setEnabled(false);
            ui->cof8_2->setEnabled(false);
            ui->cof8_3->setEnabled(false);
            ui->cof8_4->setEnabled(false);
            ui->cof8_5->setEnabled(false);
            ui->cof8_6->setEnabled(false);
            ui->cof1_1->setEnabled(true);
            ui->cof1_2->setEnabled(true);
            ui->cof1_3->setEnabled(true);
            ui->cof1_4->setEnabled(true);
            ui->cof1_5->setEnabled(true);
            ui->cof1_6->setEnabled(true);
            ui->cof2_1->setEnabled(true);
            ui->cof2_2->setEnabled(true);
            ui->cof2_3->setEnabled(true);
            ui->cof2_4->setEnabled(true);
            ui->cof2_5->setEnabled(true);
            ui->cof2_6->setEnabled(true);
            ui->cof3_1->setEnabled(true);
            ui->cof3_2->setEnabled(true);
            ui->cof3_3->setEnabled(true);
            ui->cof3_4->setEnabled(true);
            ui->cof3_5->setEnabled(true);
            ui->cof3_6->setEnabled(true);
            ui->cof4_1->setEnabled(true);
            ui->cof4_2->setEnabled(true);
            ui->cof4_3->setEnabled(true);
            ui->cof4_4->setEnabled(true);
            ui->cof4_5->setEnabled(true);
            ui->cof4_6->setEnabled(true);
            ui->radioButton_vih1->setEnabled(true);
            ui->radioButton_vih2->setEnabled(true);
            ui->radioButton_vih3->setEnabled(true);
            ui->radioButton_vih4->setEnabled(true);
            ui->radioButton_vh1->setEnabled(false);
            ui->radioButton_vh2->setEnabled(false);
            ui->radioButton_vh3->setEnabled(false);
            ui->radioButton_vh4->setEnabled(false);
            break;
    case 2:
            ui->CM16_4_C->setEnabled(false);
            ui->CMDM8_4_C->setEnabled(false);
            ui->DM4_16_C->setEnabled(true);
            ui->groupBoxys1->setEnabled(true);
            ui->groupBox_ys2->setEnabled(true);
            ui->groupBox_ys3->setEnabled(true);
            ui->groupBox_ys4->setEnabled(true);
            ui->groupBoxys5->setEnabled(false);
            ui->groupBoxys6->setEnabled(false);
            ui->groupBoxys7->setEnabled(false);
            ui->groupBoxys8->setEnabled(false);
            ui->cof5_1->setEnabled(false);
            ui->cof5_2->setEnabled(false);
            ui->cof5_3->setEnabled(false);
            ui->cof5_4->setEnabled(false);
            ui->cof5_5->setEnabled(false);
            ui->cof5_6->setEnabled(false);
            ui->cof6_1->setEnabled(false);
            ui->cof6_2->setEnabled(false);
            ui->cof6_3->setEnabled(false);
            ui->cof6_4->setEnabled(false);
            ui->cof6_5->setEnabled(false);
            ui->cof6_6->setEnabled(false);
            ui->cof7_1->setEnabled(false);
            ui->cof7_2->setEnabled(false);
            ui->cof7_3->setEnabled(false);
            ui->cof7_4->setEnabled(false);
            ui->cof7_5->setEnabled(false);
            ui->cof7_6->setEnabled(false);
            ui->cof8_1->setEnabled(false);
            ui->cof8_2->setEnabled(false);
            ui->cof8_3->setEnabled(false);
            ui->cof8_4->setEnabled(false);
            ui->cof8_5->setEnabled(false);
            ui->cof8_6->setEnabled(false);
            ui->cof1_1->setEnabled(true);
            ui->cof1_2->setEnabled(true);
            ui->cof1_3->setEnabled(true);
            ui->cof1_4->setEnabled(true);
            ui->cof1_5->setEnabled(true);
            ui->cof1_6->setEnabled(true);
            ui->cof2_1->setEnabled(true);
            ui->cof2_2->setEnabled(true);
            ui->cof2_3->setEnabled(true);
            ui->cof2_4->setEnabled(true);
            ui->cof2_5->setEnabled(true);
            ui->cof2_6->setEnabled(true);
            ui->cof3_1->setEnabled(true);
            ui->cof3_2->setEnabled(true);
            ui->cof3_3->setEnabled(true);
            ui->cof3_4->setEnabled(true);
            ui->cof3_5->setEnabled(true);
            ui->cof3_6->setEnabled(true);
            ui->cof4_1->setEnabled(true);
            ui->cof4_2->setEnabled(true);
            ui->cof4_3->setEnabled(true);
            ui->cof4_4->setEnabled(true);
            ui->cof4_5->setEnabled(true);
            ui->cof4_6->setEnabled(true);
            ui->radioButton_vih1->setEnabled(false);
            ui->radioButton_vih2->setEnabled(false);
            ui->radioButton_vih3->setEnabled(false);
            ui->radioButton_vih4->setEnabled(false);
            ui->radioButton_vh1->setEnabled(true);
            ui->radioButton_vh2->setEnabled(true);
            ui->radioButton_vh3->setEnabled(true);
            ui->radioButton_vh4->setEnabled(true);
            break;
    case 3:
            ui->CM16_4_C->setEnabled(false);
            ui->CMDM8_4_C->setEnabled(true);
            ui->DM4_16_C->setEnabled(false);
            ui->groupBoxys1->setEnabled(true);
            ui->groupBox_ys2->setEnabled(true);
            ui->groupBox_ys3->setEnabled(true);
            ui->groupBox_ys4->setEnabled(true);
            ui->groupBoxys5->setEnabled(true);
            ui->groupBoxys6->setEnabled(true);
            ui->groupBoxys7->setEnabled(true);
            ui->groupBoxys8->setEnabled(true);
            ui->cof5_1->setEnabled(true);
            ui->cof5_2->setEnabled(true);
            ui->cof5_3->setEnabled(true);
            ui->cof5_4->setEnabled(true);
            ui->cof5_5->setEnabled(true);
            ui->cof5_6->setEnabled(true);
            ui->cof6_1->setEnabled(true);
            ui->cof6_2->setEnabled(true);
            ui->cof6_3->setEnabled(true);
            ui->cof6_4->setEnabled(true);
            ui->cof6_5->setEnabled(true);
            ui->cof6_6->setEnabled(true);
            ui->cof7_1->setEnabled(true);
            ui->cof7_2->setEnabled(true);
            ui->cof7_3->setEnabled(true);
            ui->cof7_4->setEnabled(true);
            ui->cof7_5->setEnabled(true);
            ui->cof7_6->setEnabled(true);
            ui->cof8_1->setEnabled(true);
            ui->cof8_2->setEnabled(true);
            ui->cof8_3->setEnabled(true);
            ui->cof8_4->setEnabled(true);
            ui->cof8_5->setEnabled(true);
            ui->cof8_6->setEnabled(true);
            ui->cof1_1->setEnabled(true);
            ui->cof1_2->setEnabled(true);
            ui->cof1_3->setEnabled(true);
            ui->cof1_4->setEnabled(true);
            ui->cof1_5->setEnabled(true);
            ui->cof1_6->setEnabled(true);
            ui->cof2_1->setEnabled(true);
            ui->cof2_2->setEnabled(true);
            ui->cof2_3->setEnabled(true);
            ui->cof2_4->setEnabled(true);
            ui->cof2_5->setEnabled(true);
            ui->cof2_6->setEnabled(true);
            ui->cof3_1->setEnabled(true);
            ui->cof3_2->setEnabled(true);
            ui->cof3_3->setEnabled(true);
            ui->cof3_4->setEnabled(true);
            ui->cof3_5->setEnabled(true);
            ui->cof3_6->setEnabled(true);
            ui->cof4_1->setEnabled(true);
            ui->cof4_2->setEnabled(true);
            ui->cof4_3->setEnabled(true);
            ui->cof4_4->setEnabled(true);
            ui->cof4_5->setEnabled(true);
            ui->cof4_6->setEnabled(true);
            ui->radioButton_vih1->setEnabled(true);
            ui->radioButton_vih2->setEnabled(true);
            ui->radioButton_vih3->setEnabled(true);
            ui->radioButton_vih4->setEnabled(true);
            ui->radioButton_vh1->setEnabled(true);
            ui->radioButton_vh2->setEnabled(true);
            ui->radioButton_vh3->setEnabled(true);
            ui->radioButton_vh4->setEnabled(true);
        break;
    default:
        break;
    }
}

void MainWindow::DisBlockGui()
{
    ui->groupBox_2->setEnabled(false);
    ui->groupBoxSM->setEnabled(false);
    ui->tab_2->setEnabled(false);
    ui->tab_3->setEnabled(false);
    ui->tab_4->setEnabled(false);
    ui->pushButton_8->setEnabled(false);
    ui->pushButton->setEnabled(true);
    ui->listWidget_2->setEnabled(true);

}

void MainWindow::ResetGui()
{
    ui->FactoryName->setText("");
    ui->Ipaddres->setText("");
    ui->NumberPort->setText("");
    ui->MAC_address->setText("");
    ui->Ipaddres_PAY->setText("");
    ui->sw1vhvih->setCurrentIndex(0);
    ui->sw2vhvih->setCurrentIndex(0);
    ui->sw3vhvih->setCurrentIndex(0);
    ui->sw4vhvih->setCurrentIndex(0);
    ui->sw5vhvih->setCurrentIndex(0);
    ui->sw6vhvih->setCurrentIndex(0);
    ui->sw7vhvih->setCurrentIndex(0);
    ui->sw8vhvih->setCurrentIndex(0);
    ui->sw9vhvih->setCurrentIndex(0);
    ui->sw10vhvih->setCurrentIndex(0);
    ui->sw11vhvih->setCurrentIndex(0);
    ui->sw12vhvih->setCurrentIndex(0);
    ui->sw13vhvih->setCurrentIndex(0);
    ui->sw14vhvih->setCurrentIndex(0);
    ui->sw15vhvih->setCurrentIndex(0);
    ui->sw16vhvih->setCurrentIndex(0);
    ui->sw1vih->setCurrentIndex(0);
    ui->sw2vih->setCurrentIndex(0);
    ui->sw3vih->setCurrentIndex(0);
    ui->sw4vih->setCurrentIndex(0);
    ui->sw5vih->setCurrentIndex(0);
    ui->sw6vih->setCurrentIndex(0);
    ui->sw7vih->setCurrentIndex(0);
    ui->sw8vih->setCurrentIndex(0);
    ui->sw9vih->setCurrentIndex(0);
    ui->sw10vih->setCurrentIndex(0);
    ui->sw11vih->setCurrentIndex(0);
    ui->sw12vih->setCurrentIndex(0);
    ui->sw13vih->setCurrentIndex(0);
    ui->sw14vih->setCurrentIndex(0);
    ui->sw15vih->setCurrentIndex(0);
    ui->sw16vih->setCurrentIndex(0);
    ui->sw1vh1->setCurrentIndex(0);
    ui->sw1vh2->setCurrentIndex(0);
    ui->sw1vh3->setCurrentIndex(0);
    ui->sw1vh4->setCurrentIndex(0);
    ui->sw1vh5->setCurrentIndex(0);
    ui->sw1vh6->setCurrentIndex(0);
    ui->sw1vh7->setCurrentIndex(0);
    ui->sw1vh8->setCurrentIndex(0);
    ui->sw1vh9->setCurrentIndex(0);
    ui->sw1vh10->setCurrentIndex(0);
    ui->sw1vh11->setCurrentIndex(0);
    ui->sw1vh12->setCurrentIndex(0);
    ui->sw1vh13->setCurrentIndex(0);
    ui->sw1vh14->setCurrentIndex(0);
    ui->sw1vh15->setCurrentIndex(0);
    ui->sw1vh16->setCurrentIndex(0);
    ui->horizontalSlider1a->setValue(0);
    ui->horizontalSlider2a->setValue(0);
    ui->horizontalSlider3a->setValue(0);
    ui->horizontalSlider4a->setValue(0);
    ui->horizontalSlider5a->setValue(0);
    ui->horizontalSlider6a->setValue(0);
    ui->horizontalSlider7a->setValue(0);
    ui->horizontalSlider8a->setValue(0);
    ui->horizontalSlider1b->setValue(0);
    ui->horizontalSlider2b->setValue(0);
    ui->horizontalSlider3b->setValue(0);
    ui->horizontalSlider4b->setValue(0);
    ui->horizontalSlider5b->setValue(0);
    ui->horizontalSlider6b->setValue(0);
    ui->horizontalSlider7b->setValue(0);
    ui->horizontalSlider8b->setValue(0);
}

void MainWindow::on_listWidget_2_currentIndexChanged(int index)
{
    pOperationData->uchTypeComm=index+1;
    ui->listWidget->setCurrentIndex(index);
}


void MainWindow::on_listWidget_currentIndexChanged(int index)
{
    pOperationData->uchTypeComm=index+1;
    ui->listWidget_2->setCurrentIndex(index);
}


void MainWindow::on_FactoryName_textChanged(const QString &arg1)
{
    int i;
    unsigned char *chNumer;
    if(arg1.size()==6)
    {
        chNumer=(unsigned char*)arg1.unicode();
        for(i=0;i<12;i++)
        {
          pOperationData->muchFactoryNumer[i]=(unsigned char)chNumer[i];
        }
    }
}

void MainWindow::on_Ipaddres_textChanged(const QString &arg1)
{
   QHostAddress addr=QHostAddress(arg1);
   pOperationData->nIpCommnew=addr.toIPv4Address();
}

void MainWindow::on_NumberPort_textChanged(const QString &arg1)
{
    pOperationData->usnNumberPortCommnew=arg1.toUShort();
}


void MainWindow::on_MAC_address_textChanged(const QString &arg1)
{
    int i;
    bool *ok;
    QString str,str1;
    QByteArray adr;
    ushort pdata;
    str=arg1;
    union
    {
        unsigned char  adr1[12];
        unsigned short wdaddr[6];
    };
    if(arg1.size()==17)
    {
       str.remove(QChar(':'), Qt::CaseInsensitive);
       for(i=0;i<12;i=i+4)
       {
          str1=str.mid(i,4);
          pOperationData->musnMacComm[i/4]=(unsigned short)(str1.toUShort(ok,16));
       }
    }
}

void MainWindow::on_Ipaddres_PAY_textChanged(const QString &arg1)
{
    QHostAddress addr=QHostAddress(arg1);
    pOperationData->nIpPAYnew=addr.toIPv4Address();
}

void MainWindow::on_radioButton_vih2_clicked()
{
   pOperationData->uchWork=2;
}

void MainWindow::on_radioButton_vih1_clicked()
{
    pOperationData->uchWork=1;
}

void MainWindow::on_radioButton_vih3_clicked()
{
    pOperationData->uchWork=3;
}

void MainWindow::on_radioButton_vih4_clicked()
{
    pOperationData->uchWork=4;
}


void MainWindow::on_radioButton_vh1_clicked()
{
     pOperationData->uchWork=1;
}

void MainWindow::on_radioButton_vh2_clicked()
{
    pOperationData->uchWork=2;
}


void MainWindow::on_radioButton_vh3_clicked()
{
    pOperationData->uchWork=3;
}

void MainWindow::on_radioButton_vh4_clicked()
{
    pOperationData->uchWork=4;
}

/****/

void MainWindow::on_sw1vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[0]=index;
}

void MainWindow::on_sw2vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[1]=index;
}

void MainWindow::on_sw3vhvih_currentIndexChanged(int index)
{
     pOperationData->muchSwitchComm[2]=index;
}

void MainWindow::on_sw4vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[3]=index;
}

void MainWindow::on_sw5vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[4]=index;
}

void MainWindow::on_sw6vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[5]=index;
}

void MainWindow::on_sw7vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[6]=index;
}

void MainWindow::on_sw8vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[7]=index;
}

void MainWindow::on_sw9vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[8]=index;
}

void MainWindow::on_sw10vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[9]=index;
}

void MainWindow::on_sw11vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[10]=index;
}

void MainWindow::on_sw12vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[11]=index;
}

void MainWindow::on_sw13vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[12]=index;
}

void MainWindow::on_sw14vhvih_currentIndexChanged(int index)
{
     pOperationData->muchSwitchComm[13]=index;
}

void MainWindow::on_sw15vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[14]=index;
}

void MainWindow::on_sw16vhvih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[15]=index;
}

/********/

void MainWindow::on_sw1vih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[0]=index;
}

void MainWindow::on_sw2vih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[1]=index;
}

void MainWindow::on_sw3vih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[2]=index;
}

void MainWindow::on_sw4vih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[3]=index;
}

void MainWindow::on_sw5vih_currentIndexChanged(int index)
{
   pOperationData->muchSwitchComm[4]=index;
}

void MainWindow::on_sw6vih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[5]=index;
}

void MainWindow::on_sw7vih_currentIndexChanged(int index)
{
     pOperationData->muchSwitchComm[6]=index;
}

void MainWindow::on_sw8vih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[7]=index;
}

void MainWindow::on_sw9vih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[8]=index;
}

void MainWindow::on_sw10vih_currentIndexChanged(int index)
{
  pOperationData->muchSwitchComm[9]=index;
}

void MainWindow::on_sw11vih_currentIndexChanged(int index)
{
   pOperationData->muchSwitchComm[10]=index;
}

void MainWindow::on_sw12vih_currentIndexChanged(int index)
{
   pOperationData->muchSwitchComm[11]=index;
}

void MainWindow::on_sw13vih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[12]=index;
}

void MainWindow::on_sw14vih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[13]=index;
}

void MainWindow::on_sw15vih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[14]=index;
}

void MainWindow::on_sw16vih_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[15]=index;
}

/*****/

void MainWindow::on_sw1vh1_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[0]=index;
}

void MainWindow::on_sw1vh2_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[1]=index;
}

void MainWindow::on_sw1vh3_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[2]=index;
}

void MainWindow::on_sw1vh4_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[3]=index;
}

void MainWindow::on_sw1vh5_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[4]=index;
}

void MainWindow::on_sw1vh6_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[5]=index;
}

void MainWindow::on_sw1vh7_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[6]=index;
}

void MainWindow::on_sw1vh8_currentIndexChanged(int index)
{
   pOperationData->muchSwitchComm[7]=index;
}

void MainWindow::on_sw1vh9_currentIndexChanged(int index)
{
   pOperationData->muchSwitchComm[8]=index;
}

void MainWindow::on_sw1vh10_currentIndexChanged(int index)
{
   pOperationData->muchSwitchComm[9]=index;
}

void MainWindow::on_sw1vh11_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[10]=index;
}

void MainWindow::on_sw1vh12_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[11]=index;
}

void MainWindow::on_sw1vh13_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[12]=index;
}

void MainWindow::on_sw1vh14_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[13]=index;
}

void MainWindow::on_sw1vh15_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[14]=index;
}

void MainWindow::on_sw1vh16_currentIndexChanged(int index)
{
    pOperationData->muchSwitchComm[15]=index;
}
/*****/

void MainWindow::on_horizontalSlider1a_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit1a->setText(QString("%1").arg(number_val));
    if(pOperationData->uchTypeComm==2)
    {
        pOperationData->muchGainCorrectNool[4]=(unsigned char)(number_val*2.0);
    }
    pOperationData->muchGainCorrectNool[0]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider2a_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit2a->setText(QString("%1").arg(number_val));
    if(pOperationData->uchTypeComm==2)
    {
        pOperationData->muchGainCorrectNool[5]=(unsigned char)(number_val*2.0);
    }
    pOperationData->muchGainCorrectNool[1]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider3a_sliderMoved(int position)
{
   float number_val;
   number_val=((float)(position))/2.0;
   ui->lineEdit3a->setText(QString("%1").arg(number_val));
   if(pOperationData->uchTypeComm==2)
   {
      pOperationData->muchGainCorrectNool[6]=(unsigned char)(number_val*2.0);
   }
   pOperationData->muchGainCorrectNool[2]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider4a_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit4a->setText(QString("%1").arg(number_val));
    if(pOperationData->uchTypeComm==2)
    {
        pOperationData->muchGainCorrectNool[7]=(unsigned char)(number_val*2.0);
    }
    pOperationData->muchGainCorrectNool[3]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider5a_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit5a->setText(QString("%1").arg(number_val));
    pOperationData->muchGainCorrectNool[4]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider6a_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit6a->setText(QString("%1").arg(number_val));
    pOperationData->muchGainCorrectNool[5]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider7a_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit7a->setText(QString("%1").arg(number_val));
    pOperationData->muchGainCorrectNool[6]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider8a_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit8a->setText(QString("%1").arg(number_val));
    pOperationData->muchGainCorrectNool[7]=(unsigned char)(number_val*2.0);
}

/***/

void MainWindow::on_cof1_1_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectMinus[0]=number_val;
    }
}

void MainWindow::on_cof2_1_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectMinus[1]=number_val;
    }
}


void MainWindow::on_cof3_1_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectMinus[2]=number_val;
    }
}


void MainWindow::on_cof4_1_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectMinus[3]=number_val;
    }
}

void MainWindow::on_cof5_1_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectMinus[4]=number_val;
    }
}

void MainWindow::on_cof6_1_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectMinus[5]=number_val;
    }
}

void MainWindow::on_cof7_1_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectMinus[6]=number_val;
    }
}

void MainWindow::on_cof8_1_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectMinus[7]=number_val;
    }
}

void MainWindow::on_cof1_2_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectNormal[0]=number_val;
    }
}

void MainWindow::on_cof2_2_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectNormal[1]=number_val;
    }
}


void MainWindow::on_cof3_2_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectNormal[2]=number_val;
    }
}

void MainWindow::on_cof4_2_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectNormal[3]=number_val;
    }
}

void MainWindow::on_cof5_2_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectNormal[4]=number_val;
    }
}

void MainWindow::on_cof6_2_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectNormal[5]=number_val;
    }
}

void MainWindow::on_cof7_2_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectNormal[6]=number_val;
    }
}

void MainWindow::on_cof8_2_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectNormal[7]=number_val;
    }
}

void MainWindow::on_cof1_3_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectPlus[0]=number_val;
    }
}

void MainWindow::on_cof2_3_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectPlus[1]=number_val;
    }
}

void MainWindow::on_cof3_3_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectPlus[2]=number_val;
    }
}

void MainWindow::on_cof4_3_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectPlus[3]=number_val;
    }
}

void MainWindow::on_cof5_3_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectPlus[4]=number_val;
    }
}

void MainWindow::on_cof6_3_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectPlus[5]=number_val;
    }
}

void MainWindow::on_cof7_3_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectPlus[6]=number_val;
    }
}

void MainWindow::on_cof8_3_textChanged(const QString &arg1)
{
    float number_val;
    char data;
    number_val=arg1.toFloat();
    number_val=number_val*2.0;
    data=number_val;
    if((data>=0)&(data<=23))
    {
        pOperationData->muchGainCorrectPlus[7]=number_val;
    }
}

void MainWindow::on_horizontalSlider1b_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit1b->setText(QString("%1").arg(number_val-10.0));
    if(pOperationData->uchTypeComm==2)
    {
         pOperationData->muchGainManger[4]=(unsigned char)(number_val*2.0);
    }
    pOperationData->muchGainManger[0]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider2b_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit2b->setText(QString("%1").arg(number_val-10.0));
    if(pOperationData->uchTypeComm==2)
    {
        pOperationData->muchGainManger[5]=(unsigned char)(number_val*2.0);
    }
    pOperationData->muchGainManger[1]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider3b_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit3b->setText(QString("%1").arg(number_val-10.0));
    if(pOperationData->uchTypeComm==2)
    {
        pOperationData->muchGainManger[6]=(unsigned char)(number_val*2.0);
    }
    pOperationData->muchGainManger[2]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider4b_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit4b->setText(QString("%1").arg(number_val-10.0));
    if(pOperationData->uchTypeComm==2)
    {
        pOperationData->muchGainManger[7]=(unsigned char)(number_val*2.0);
    }
    pOperationData->muchGainManger[3]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider5b_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit5b->setText(QString("%1").arg(number_val-10.0));
    pOperationData->muchGainManger[4]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider6b_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit6b->setText(QString("%1").arg(number_val-10.0));
    pOperationData->muchGainManger[5]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider7b_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit7b->setText(QString("%1").arg(number_val-10.0));
    pOperationData->muchGainManger[6]=(unsigned char)(number_val*2.0);
}

void MainWindow::on_horizontalSlider8b_sliderMoved(int position)
{
    float number_val;
    number_val=((float)(position))/2.0;
    ui->lineEdit8b->setText(QString("%1").arg(number_val-10.0));
    pOperationData->muchGainManger[7]=(unsigned char)(number_val*2.0);
}

