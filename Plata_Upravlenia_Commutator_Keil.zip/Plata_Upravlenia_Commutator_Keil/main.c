﻿#include "opora.h"
#include  <stdio.h>
#include  <stdint.h>
#include "FullUserHeader.h"

uint8_t NextAction=0; //следующие действие 

uint8_t InitGood=0;
uint16_t CountSec=0;

int main()
{
	int i;
	hardware_init();	
	while(1)
	{
		i++;
	}
}


void TIMER3_Handler(void)
{
	//функция установки усиления
  TIMER3->CNT = 0x0000;
  TIMER3->STATUS &= ~(1 << 1);
	NVIC_ClearPendingIRQ(TIMER3_IRQn);
	readTemperaturaCommutator();
}

void TIMER1_Handler(void)
{
	TIMER1->CNT = 0x0000;	
  TIMER1->STATUS &= ~(1 << 1);
	NVIC_ClearPendingIRQ(TIMER1_IRQn);	
	TIMER1->CNTRL = 0; /*таймер выкл.*/
	Tim1_ok=1;
}


void TIMER2_Handler(void)
{
	//функция установки усиления
	TIMER2->CNTRL = 0; /*таймер выкл.*/
  TIMER2->CNT = 0x0000;
  TIMER2->STATUS &= ~(1 << 1);
	TimeHasCome=1; //Истекло время ожидания ответа по Uart
	NVIC_ClearPendingIRQ(TIMER2_IRQn);
}

void UART2_Handler(void)
{
	uint16_t data; 
	uint8_t ReqError=COMANDA_UART_ERORR; 
	data=0;
	if((((UART2->MIS)&0x0010)==0x0010)) //прерывание по переполнению приёмника 
	{
		data=UART2->DR;		
    if(((data&0xF00)>>8)==0)
 		{	 
			 if(IndexMassivDataUart==0)
			 {
						switch(data)
						{
							case COMANDA_UART_OK:
											Comanda_OK=1;// ответ пришел
							        TypeComandUartMaster=0;
											SizeReadByteUart=1;
											break;
							case COMANDA_UART_ERORR:
											TypeComandUartMaster=0;
					            Comanda_OK=2;// данные некорректны 
											SizeReadByteUart=1;
											break;
							case SETING_COMMUTATOR_UART:
								      TypeComandUartMaster=1;
					            SizeReadByteUart=sizeof(UartTransSetting);
											break;
							case TEMPERATURA_2_UART:
								      TypeComandUartMaster=2;
					            SizeReadByteUart=sizeof(UartTransTemperatura);
											break;
							case TEMPERATURA_2_UART_ANSWER:
										TypeComandUartMaster=0;
								    WriteTemperaturaCommUart();
										SizeReadByteUart=1;
								    break;
							case READ_STATUS:  
								    WriteStatusFlagCommUart();
										TypeComandUartMaster=0;
									  SizeReadByteUart=1;
								    break;
							case READ_STATUS_ANSWER:
								    TypeComandUartMaster=3;
										SizeReadByteUart=sizeof(UartTransStatusFlag);
								    break;
							default:
								    TypeComandUartMaster=0;	
										SizeReadByteUart=1;
							break;
			      }			
		   }
			 MassivDataUart[IndexMassivDataUart]=data;
			 IndexMassivDataUart++;
       if(IndexMassivDataUart==SizeReadByteUart)
			 {
				 if(TypeComandUartMaster!=0)
				 {
					 ReadMessageUart(TypeComandUartMaster);
				 }
				  IndexMassivDataUart=0;
			 }				 
		}	
		else
    {
			  send_data_uart(&ReqError,1);
		}			
	}
	if((((UART2->MIS)&0x0040)==0x0040)) //прерывание по таймауту от приема
  {
		 data=UART2->DR;	
		 IndexMassivDataUart=0;
	}	
  UART2->ICR|=0x07ff;	
  NVIC_ClearPendingIRQ(UART2_IRQn);		
}

void ETHERNET_Handler(void) 
{
      uint16_t Status,StatusBuff;
      Status=ETHERNET->IFR;
			ETHERNET->IFR=Status;	  
			if(((Status&0x01)==0x01)|((Status&0x04)==0x04))
			{ 			
					StatusBuff=ETHERNET->STAT;
        	while((StatusBuff&0x00E0)!=0)
        	{	
						 ReadPacket();
						 StatusBuff=ETHERNET->STAT;	
          }	 		
		  }
     	NVIC_ClearPendingIRQ(ETHERNET_IRQn); 	
}



