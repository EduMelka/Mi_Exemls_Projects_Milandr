﻿#ifndef WORK_UART_COMMUTATOR_H
#define WORK_UART_COMMUTATOR_H

//static void send_data_uart(uint8_t *buffer, uint32_t suze_buffer);
extern void InitUART2Interface(void);
void send_data_uart(uint8_t *buffer, uint32_t suze_buffer);

static uint16_t Uart2Speed[12][12]={
 	{0x0001,0x0005}, // 460800 бит/с
	{0x0002,0x000B},  // 230400 бит/с
	{0x0004,0x0016}, // 115200 бит/с
	{0x0006,0x0021},// 76800  бит/с
	{0x0008,0x002C}, // 57600  бит/с
	{0x000C,0x0001},// 38400  бит/с
	{0x0022,0x002E}, // 14400  бит/с
	{0x0034,0x0005},// 9600   бит/с 
	{0x00D0,0x0015}, // 2400   бит/с
	{0x01A0,0x002B},// 1200   бит/с
	{0x11C1,0x001D} //  110    бит/с
};

#define TRANSMITER_UART2_ON   UART2->CR|=0x0100;
#define RECIVER_UART2_ON     UART2->CR|=0x0200; 
#define TRANSMITER_UART2_OFF  UART2->CR&=0xFEFF;
#define RECIVER_UART2_OFF    UART2->CR&=0xFDFF; 
#define START_UART2   UART2->CR|=0x0001;
#define STOP_UART2    UART2->CR&=0xFFFE;
#define START_UART2_TEST  UART2->CR|=0x0080;
#define STOP_UART2_TEST   UART2->CR&=0xFF7F;

#define SET_UART2_OEIM  UART2->IMSC&=0xFBFF;
#define CLEAR_UART2_OEIM  UART2->IMSC|=0x0400; 
#define SET_UART2_RTIM UART2->IMSC&=0xFFBF;
#define CLEAR_UART2_RTIM UART2->IMSC|=0x0040;

#define OERIS_IRQ_ON  (((UART2->MIS)&0x0400)==0x0400)
#define RTMIS_IRQ_ON  (((UART2->MIS)&0x0040)==0x0040)

#define OERIS_IRQ_CLEAR  UART2->ICR|=0x0400;
#define RTMIS_IRQ_CLEAR  UART2->ICR|=0x0040;

#endif /*WORK_UART_COMMUTATOR_H*/
