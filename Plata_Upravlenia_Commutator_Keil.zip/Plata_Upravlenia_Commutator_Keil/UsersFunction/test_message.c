﻿#include "FullUserHeader.h"
#include <string.h>
uint16_t xtBuffer[1500]; //xtBuffer[sizeof(PackEthernet)/2+1];
PackEthernet *pPackEthernet;
rotIpaddres nrotIpaddres,nrotIpaddres1;
rotTypeData nrotTypeData,nrotTypeData1;


void pack_interpritator(uint8_t mode)
{
		uint32_t i;
	  DataUDPCreat unDataUDPCreat;
	  uint16_t dataRepeatIcmp[18];
	  uint16_t IcmpPackSize=0;
	  uint16_t head,head1,nSizeSend,size_dop,size_curr,size_udp,size_correct,data;
	  head=ETHERNET->X_Head;
	  head1=head;
	  if(operation_data->TypePlata==0)
		{ 
			 operation_data->TypePlata=1;//ведуща¤ плата
			 SaveDataStructToFlash();
		}
	  switch(mode)
		{
			 case 90:
						 return;
			 case 91:
						nSizeSend=BASE_SIZE_PACK+4;	      
						break;
			 case 60: 
				     nSizeSend=sizeof(HeaderPackEthernet)+sizeof(ARPPackEthernet);
						 break;
			 case 50:
						 IcmpPackSize=((pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)>>8U)-24U;  
						 IcmpPackSize=(IcmpPackSize+(IcmpPackSize-((IcmpPackSize>>1)<<1)))/2u;
				     for(i=0;i<(IcmpPackSize-2);i++)
						 {
							 dataRepeatIcmp[i]=*((uint16_t*)((&pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.DataICMPEcho)+i));			 						
						 }
						 dataRepeatIcmp[IcmpPackSize-2]=pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.IcmpIdentificator;
						 dataRepeatIcmp[IcmpPackSize-1]=pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.IcmpSequenceNumber;
						 nSizeSend=(sizeof(HeaderPackEthernet)-4)+((pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)>>8U)+4u;		
						 break;
			 case 11:
				     nSizeSend=(BASE_SIZE_PACK+4)+4;
			       break;
			 case 12:
			       nSizeSend=(BASE_SIZE_PACK+4)+4;
			       break;
			 case 13:
				     nSizeSend=(BASE_SIZE_PACK+2)+4;
			       break;
			 case 14:
				     nSizeSend=(BASE_SIZE_PACK+6)+4;
			       break;
			 case 15:
				     nSizeSend=(BASE_SIZE_PACK+sizeof(SettingCommutator))+4;
			       break;
			 case 16:
				     nSizeSend=(BASE_SIZE_PACK+sizeof(SettingCommutator))+4;
			       break;
			 case 17:
				     nSizeSend=(BASE_SIZE_PACK+sizeof(SettingSystemCommutator))+4;
			       break;	 
			 case 1:
				     nSizeSend=(BASE_SIZE_PACK)+4;
			       nrotIpaddres.Ipaddress=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.NewIp;
			       nrotIpaddres1.ByteData[0]=nrotIpaddres.ByteData[3];
						 nrotIpaddres1.ByteData[1]=nrotIpaddres.ByteData[2];
						 nrotIpaddres1.ByteData[2]=nrotIpaddres.ByteData[1];
             nrotIpaddres1.ByteData[3]=nrotIpaddres.ByteData[0];		 
						 operation_data->nIpComm=nrotIpaddres1.Ipaddress;
					//	 operation_data->nIpComm=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.NewIp;
			       SaveDataStructToFlash();	 
				     break;
			 case 2: 				 
						 nSizeSend=(BASE_SIZE_PACK)+4;
						 nrotIpaddres.Ipaddress=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.NewMaskIp;
			       nrotIpaddres1.ByteData[0]=nrotIpaddres.ByteData[3];
						 nrotIpaddres1.ByteData[1]=nrotIpaddres.ByteData[2];
						 nrotIpaddres1.ByteData[2]=nrotIpaddres.ByteData[1];
             nrotIpaddres1.ByteData[3]=nrotIpaddres.ByteData[0];		  
						 operation_data->nIpMaskComm=nrotIpaddres1.Ipaddress;
						// operation_data->nIpMaskComm=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.NewMaskIp;
			       SaveDataStructToFlash();
				     break;
			 case 3:
				     nSizeSend=(BASE_SIZE_PACK)+4;
			       nrotIpaddres.UdpPort=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.NewUDPPort;
						 nrotIpaddres1.ByteData[0]=nrotIpaddres.ByteData[1];
						 nrotIpaddres1.ByteData[1]=nrotIpaddres.ByteData[0];
			       operation_data->usnNumberPortComm=nrotIpaddres1.UdpPort;
			       SaveDataStructToFlash();
				     break;
			 case 4:
						 nSizeSend=(BASE_SIZE_PACK)+4;
			       nrotTypeData.WordData[0]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stMacPack.CommMacHSource;
			       nrotTypeData.WordData[1]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stMacPack.CommMacMSource;
			       nrotTypeData.WordData[2]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stMacPack.CommMacLSource;
						 nrotTypeData1.ByteData[0]=nrotTypeData.ByteData[5];
						 nrotTypeData1.ByteData[1]=nrotTypeData.ByteData[4];
						 nrotTypeData1.ByteData[2]=nrotTypeData.ByteData[3];
						 nrotTypeData1.ByteData[3]=nrotTypeData.ByteData[2];
						 nrotTypeData1.ByteData[4]=nrotTypeData.ByteData[1];
						 nrotTypeData1.ByteData[5]=nrotTypeData.ByteData[0];	
			       operation_data->musnMacComm[0]=nrotTypeData1.WordData[0];
			       operation_data->musnMacComm[1]=nrotTypeData1.WordData[1];
			       operation_data->musnMacComm[2]=nrotTypeData1.WordData[2];
			       ETHERNET->MAC_T=operation_data->musnMacComm[0];
             ETHERNET->MAC_M=operation_data->musnMacComm[1];
             ETHERNET->MAC_H=operation_data->musnMacComm[2];
			       /*
						 operation_data->musnMacComm[0]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stMacPack.CommMacHSource;
			       operation_data->musnMacComm[1]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stMacPack.CommMacMSource;
			       operation_data->musnMacComm[2]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stMacPack.CommMacLSource;
			       operation_data->musnMacComm[0]=((((uint16_t)(operation_data->musnMacComm[0]))&0xFF00)>>8u)|((((uint16_t)(operation_data->musnMacComm[0]))&0x00FF)<<8u);
						 operation_data->musnMacComm[1]=((((uint16_t)(operation_data->musnMacComm[1]))&0xFF00)>>8u)|((((uint16_t)(operation_data->musnMacComm[1]))&0x00FF)<<8u);
						 operation_data->musnMacComm[2]=((((uint16_t)(operation_data->musnMacComm[2]))&0xFF00)>>8u)|((((uint16_t)(operation_data->musnMacComm[2]))&0x00FF)<<8u);
			       ETHERNET->MAC_T=operation_data->musnMacComm[0];
             ETHERNET->MAC_M=operation_data->musnMacComm[1];
             ETHERNET->MAC_H=operation_data->musnMacComm[2];	*/
       			 SaveDataStructToFlash();
				     break;
			 case 5:	 
						 nSizeSend=(BASE_SIZE_PACK)+4;
						 operation_data->uchWork=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingCommutator.ModeWorkCommutator;
						 for(i=0;i<16;i++)
						 {
								if(i<8)
								{
										operation_data->muchGainManger[i]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingCommutator.TransferFactor[i]+20U;	//»—ѕ–¬Ћ≈Ќќ 15.10.19
								    if(operation_data->muchGainManger[i]>40)
										{
											operation_data->muchGainManger[i]=40;
										}
								}
								operation_data->muchSwitchComm[i]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingCommutator.OUT_OR_IN_Numer[i];		
						 }
						 SetCommunicationPin(); 				 
				     break;
			 case 7:
						 nSizeSend=(BASE_SIZE_PACK)+4;
			       operation_data->uchTypeComm=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingSystemCommutator.TypeCommutator;
						 operation_data->uchResetSetting=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingSystemCommutator.ResetCommutator;
						/* unARPIPsender.IPSender=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingSystemCommutator.IpAddressPay;
			       unARPIPsender1.IPSender=unARPIPsender.IPSender;
			       unARPIPsender.byteIP[0]=unARPIPsender1.byteIP[3];
			       unARPIPsender.byteIP[1]=unARPIPsender1.byteIP[2];
			       unARPIPsender.byteIP[2]=unARPIPsender1.byteIP[1];
			       unARPIPsender.byteIP[3]=unARPIPsender1.byteIP[0];
			       operation_data->nIpPAY=unARPIPsender.IPSender;*/
						 for(i=0;i<12;i++)
						 {
								if(i<8)
								{
									operation_data->muchGainCorrectNool[i]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingSystemCommutator.GainCorrectChennel[i];
									operation_data->muchGainCorrectMinus[i]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingSystemCommutator.GainCorrectMinus[i];
									operation_data->muchGainCorrectNormal[i]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingSystemCommutator.GainCorrectNool[i];
									operation_data->muchGainCorrectPlus[i]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingSystemCommutator.GainCorrectPlus[i];
								}
								operation_data->muchFactoryNumer[i]=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingSystemCommutator.FactoryNummer[i]; 
						} 
						if(operation_data->uchResetSetting==1) //сброс на начальные настройки
						{
							 NewInitSettingCommutator(1);
							 operation_data->uchResetSetting=0;
							 SetCommunicationPin();
						   SaveDataStructToFlash(); 
						}
						else
						{
							SetCommunicationPin();
						  SaveDataStructToFlash();
						}					
      			break;
			 case 0xFE:
				    nSizeSend=(BASE_SIZE_PACK)+4;
			      break;
			 case 0xFF:
				    nSizeSend=(BASE_SIZE_PACK)+4;
			      break;	 
		}	
		nSizeSend=(4-(nSizeSend-((nSizeSend>>2)<<2)))+nSizeSend;
		if((head+nSizeSend+4u)>0x2000)
		{
				ClearMemoryTransmiter(0x1000);
				size_dop=(((head+nSizeSend+4u)-0x2000)>>1);
				size_curr=((nSizeSend+4u)/2)-size_dop;
				head=0x1000;
			  pPackEthernet=(PackEthernet*)(xtBuffer);
		}
		else
		{
			size_dop=0;
			size_curr=0;
			pPackEthernet=(PackEthernet*)(BaseAddresEhernet+head);
		}	
		*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.LengthPack)))=0x0000;
		if(mode==91)
		{
				*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderH)))=0xFFFF;
	      *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderM)))=0xFFFF;
	      *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderL)))=0xFFFF;
		}
		else
		{
			*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderH)))=operation_data->musnMacPay[0];
	    *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderM)))=operation_data->musnMacPay[1];
	    *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderL)))=operation_data->musnMacPay[2];	
			
		}
		*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSourceH)))=operation_data->musnMacComm[0];
		*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSourceM)))=operation_data->musnMacComm[1];
		*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSourceL)))=operation_data->musnMacComm[2];	
    if((mode!=60)&(mode!=50))
	  {	 
		  switch(operation_data->uchTypeComm)
		  {
				case 1:
							 unDataUDPCreat.data.stPAYHeaderPackEthernet.IDO_FIELD=IDP_IDO_CM16_4;
							 break;
				case 2:
							 unDataUDPCreat.data.stPAYHeaderPackEthernet.IDO_FIELD=IDP_IDO_DM4_16;
							 break;
				case 3:
					     unDataUDPCreat.data.stPAYHeaderPackEthernet.IDO_FIELD=IDP_IDO_CMDM8_4;
							 break;						
		  } 
			*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.SourceUDPPort)))=operation_data->usnNumberPortComm;
			if(mode==91)
			{
					*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.SenderUDPPort)))=0x4475;	
				  unDataUDPCreat.data.stPAYHeaderPackEthernet.IDP_FIELD=IDP_IDO_BROADCAST;
			}
			else
			{
					*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.SenderUDPPort)))=operation_data->usnNumberPortPAY;
					unDataUDPCreat.data.stPAYHeaderPackEthernet.IDP_FIELD=IDP_IDO_PAY;
			}
			
	  }		
		switch(mode)
		{
			 case 91:
						*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
						*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK)+((BASE_SIZE_PACK)-(((BASE_SIZE_PACK)>>1)<<1));
			      creat_ip_heder(mode);
						unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY)))<<8u);
			      unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=VC_LEVEL_SIGNAL;
			      unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_LEVEL_SIGNAL;
						unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_EVEL_SIGNAL;
			      *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP)<<8);
					  size_udp=(BASE_SIZE_PAY+4)+((BASE_SIZE_PAY+4)-(((BASE_SIZE_PAY+4)>>1)<<1));
					  size_correct=size_udp-(BASE_SIZE_PAY+4);
						for(i=0;i<size_udp/2;i++)
						{
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						}
						*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();		
			      break;
			 case 50:
				     *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=nSizeSend-4u;
						 creat_ICMP_message(dataRepeatIcmp,IcmpPackSize-2u);
						break;
			 case 60:
						 *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=Type_ARP_MESG;
			       *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=sizeof(HeaderPackEthernet)+sizeof(ARPPackEthernet)-4u;
			       creat_arp_answer();
						 break;
			 case 11:
						 *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
						 *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK+4)+((BASE_SIZE_PACK+4)-(((BASE_SIZE_PACK+4)>>1)<<1));
             creat_ip_heder(mode);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY+4)))<<8u);
			       unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_SYSTEM;
			       unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_IP_pack;	
			       nrotIpaddres.Ipaddress=operation_data->nIpComm;
			       nrotIpaddres1.ByteData[0]=nrotIpaddres.ByteData[3];
						 nrotIpaddres1.ByteData[1]=nrotIpaddres.ByteData[2];
						 nrotIpaddres1.ByteData[2]=nrotIpaddres.ByteData[1];
             nrotIpaddres1.ByteData[3]=nrotIpaddres.ByteData[0];		 
			       unDataUDPCreat.data.unUdpData.NewIp=nrotIpaddres1.Ipaddress;
					   //unDataUDPCreat.data.unUdpData.NewIp=operation_data->nIpComm;
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP+4)<<8);
						 size_udp=(BASE_SIZE_PAY+4)+((BASE_SIZE_PAY+4)-(((BASE_SIZE_PAY+4)>>1)<<1));
						 size_correct=size_udp-(BASE_SIZE_PAY+4);
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
						 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();		
			       break;
			 case 12:
				     *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
						 *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK+4)+((BASE_SIZE_PACK+4)-(((BASE_SIZE_PACK+4)>>1)<<1));
             creat_ip_heder(mode);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY+4)))<<8u);
			       unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_SYSTEM;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_IPMASK_pack;
			 			 nrotIpaddres.Ipaddress=operation_data->nIpMaskComm;
			       nrotIpaddres1.ByteData[0]=nrotIpaddres.ByteData[3];
						 nrotIpaddres1.ByteData[1]=nrotIpaddres.ByteData[2];
						 nrotIpaddres1.ByteData[2]=nrotIpaddres.ByteData[1];
             nrotIpaddres1.ByteData[3]=nrotIpaddres.ByteData[0];		 
			       unDataUDPCreat.data.unUdpData.NewMaskIp=nrotIpaddres1.Ipaddress;
						 // operation_data->nIpMaskComm=operation_data->nIpMaskComm;	
						 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP+4)<<8);
						 size_udp=(BASE_SIZE_PAY+4)+((BASE_SIZE_PAY+4)-(((BASE_SIZE_PAY+4)>>1)<<1));
						 size_correct=size_udp-(BASE_SIZE_PAY+4);
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();		
			       break;
			 case 13:
				     *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
						 *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK+2)+((BASE_SIZE_PACK+2)-(((BASE_SIZE_PACK+2)>>1)<<1));;
             creat_ip_heder(mode);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY+2)))<<8u);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_SYSTEM;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
					   unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_NUMBER_PORT_pack;
						 nrotIpaddres.UdpPort=operation_data->usnNumberPortComm;
						 nrotIpaddres1.ByteData[0]=nrotIpaddres.ByteData[1];
						 nrotIpaddres1.ByteData[1]=nrotIpaddres.ByteData[0];
			       unDataUDPCreat.data.unUdpData.NewUDPPort=nrotIpaddres1.UdpPort;
						 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP+2)<<8);
						 size_udp=(BASE_SIZE_PAY+2)+((BASE_SIZE_PAY+2)-(((BASE_SIZE_PAY+2)>>1)<<1));
						 size_correct=size_udp-(BASE_SIZE_PAY+4);
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();			
			       break;
			 case 14:
				     *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
						 *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK+6)+((BASE_SIZE_PACK+6)-(((BASE_SIZE_PACK+6)>>1)<<1));;
             creat_ip_heder(mode);
				     unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY+6)))<<8u);
			       unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_SYSTEM;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_MAC_pack;
						 unDataUDPCreat.data.unUdpData.stMacPack.CommMacHSource=(((operation_data->musnMacComm[2])&0xFF00)>>8U)|(((operation_data->musnMacComm[2])&0x00FF)<<8U);
						 unDataUDPCreat.data.unUdpData.stMacPack.CommMacMSource=(((operation_data->musnMacComm[1])&0xFF00)>>8U)|(((operation_data->musnMacComm[1])&0x00FF)<<8U);
						 unDataUDPCreat.data.unUdpData.stMacPack.CommMacLSource=(((operation_data->musnMacComm[0])&0xFF00)>>8U)|(((operation_data->musnMacComm[0])&0x00FF)<<8U);
					   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP+6)<<8);
						 size_udp=(BASE_SIZE_PAY+6)+((BASE_SIZE_PAY+6)-(((BASE_SIZE_PAY+6)>>1)<<1));
			       size_correct=size_udp-(BASE_SIZE_PAY+6);
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();	
			       break;
			 case 15:
				     *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
						 *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK+sizeof(SettingCommutator))+((BASE_SIZE_PACK+sizeof(SettingCommutator))-(((BASE_SIZE_PACK+sizeof(SettingCommutator))>>1)<<1));
             creat_ip_heder(mode);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY+sizeof(SettingCommutator))))<<8u);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_APLICATION;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
			       unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_CONFIGURE_COMMUTATOR_pack; 
			       //(0-4)-дата,(5-8)-мес¤ц, (9-15)-год (верси¤ прошивки)
			       unDataUDPCreat.data.unUdpData.stSettingCommutator.RezervByte[0]=0x82;//02.12 //»—ѕ–¬Ћ≈Ќќ 02.12.19
			       unDataUDPCreat.data.unUdpData.stSettingCommutator.RezervByte[1]=0x27;//19г//»—ѕ–¬Ћ≈Ќќ 02.12.19
						 unDataUDPCreat.data.unUdpData.stSettingCommutator.RezervByte[2]=(uint8_t)(addres_spi_memory&0xFF000000);	//»—ѕ–¬Ћ≈Ќќ 02.12.19
						 unDataUDPCreat.data.unUdpData.stSettingCommutator.RezervByte[3]=(uint8_t)(addres_spi_memory&0x00FF0000);	//»—ѕ–¬Ћ≈Ќќ 02.12.19
						 unDataUDPCreat.data.unUdpData.stSettingCommutator.RezervByte[4]=(uint8_t)(addres_spi_memory&0x0000FF00);	//»—ѕ–¬Ћ≈Ќќ 02.12.19
						 unDataUDPCreat.data.unUdpData.stSettingCommutator.RezervByte[5]=(uint8_t)(addres_spi_memory&0x000000FF);	//»—ѕ–¬Ћ≈Ќќ 02.12.19
						 for(i=0;i<16;i++)
						 {
							 unDataUDPCreat.data.unUdpData.stSettingCommutator.OUT_OR_IN_Numer[i]=operation_data->muchSwitchComm[i];
							 if(i<8)
							 {
								  unDataUDPCreat.data.unUdpData.stSettingCommutator.TransferFactor[i]=operation_data->muchGainManger[i]-20U;//»—ѕ–¬Ћ≈Ќќ 15.10.19
							 }
							 if((i>5)&(i<11))//»—ѕ–¬Ћ≈Ќќ 02.12.19
							 {
							    unDataUDPCreat.data.unUdpData.stSettingCommutator.RezervByte[i]=0;
							 }
						 }
						 unDataUDPCreat.data.unUdpData.stSettingCommutator.ModeWorkCommutator=operation_data->uchWork;
						 ReadStatusFlagSlavePlata();
						 unDataUDPCreat.data.unUdpData.stSettingCommutator.FlagState=operation_data->uchStatusFlags;
				     unDataUDPCreat.data.unUdpData.stSettingCommutator.TemperaruraPlataN1=operation_data->usnTemperatureN1;
						 unDataUDPCreat.data.unUdpData.stSettingCommutator.TemperaruraPlataN2=operation_data->usnTemperatureN2;
						 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP+sizeof(SettingCommutator))<<8);
						 size_udp=(BASE_SIZE_PAY+sizeof(SettingCommutator))+((BASE_SIZE_PAY+sizeof(SettingCommutator))-(((BASE_SIZE_PAY+sizeof(SettingCommutator))>>1)<<1));
						 size_correct=size_udp-(BASE_SIZE_PAY+sizeof(SettingCommutator));
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();	 
			       break;
			 case 16:
				     *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
						 *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK+sizeof(SettingCommutator))+((BASE_SIZE_PACK+sizeof(SettingCommutator))-(((BASE_SIZE_PACK+sizeof(SettingCommutator))>>1)<<1));
			       creat_ip_heder(mode);
			       unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY+sizeof(SettingCommutator))))<<8u);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_APLICATION;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_READ_TEMPERATURE_pack;
						 for(i=0;i<16;i++)
						 {
							 unDataUDPCreat.data.unUdpData.stSettingCommutator.OUT_OR_IN_Numer[i]=operation_data->muchSwitchComm[i];
							 if(i<8)
							 {
								  unDataUDPCreat.data.unUdpData.stSettingCommutator.TransferFactor[i]=operation_data->muchGainManger[i];
							 }
							 if(i<11)
							 {
							    unDataUDPCreat.data.unUdpData.stSettingCommutator.RezervByte[i]=0;
							 }
						 }
						 unDataUDPCreat.data.unUdpData.stSettingCommutator.ModeWorkCommutator=operation_data->uchWork;
						 unDataUDPCreat.data.unUdpData.stSettingCommutator.FlagState=operation_data->uchStatusFlags;
				     unDataUDPCreat.data.unUdpData.stSettingCommutator.TemperaruraPlataN1=operation_data->usnTemperatureN1;
						 ReadTemperaSlavePlata();
						 unDataUDPCreat.data.unUdpData.stSettingCommutator.TemperaruraPlataN2=operation_data->usnTemperatureN2;
						 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP+sizeof(SettingCommutator))<<8);
						 size_udp=(BASE_SIZE_PAY+sizeof(SettingCommutator))+((BASE_SIZE_PAY+sizeof(SettingCommutator))-(((BASE_SIZE_PAY+sizeof(SettingCommutator))>>1)<<1));
						 size_correct=size_udp-(BASE_SIZE_PAY+sizeof(SettingCommutator));
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();
			       break;
			 case 17:
				     *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
				     *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK+sizeof(SettingSystemCommutator))+((BASE_SIZE_PACK+sizeof(SettingSystemCommutator))-(((BASE_SIZE_PACK+sizeof(SettingSystemCommutator))>>1)<<1));
			       creat_ip_heder(mode);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY+sizeof(SettingSystemCommutator))))<<8u);	
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_APLICATION;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
			       unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_CONFIGURE_SYSTEM_COMMUTATOR_pack;
						 for(i=0;i<12;i++)
						 {
							  unDataUDPCreat.data.unUdpData.stSettingSystemCommutator.FactoryNummer[i]=operation_data->muchFactoryNumer[i];
							  if(i<8)
								{
									unDataUDPCreat.data.unUdpData.stSettingSystemCommutator.GainCorrectMinus[i]=operation_data->muchGainCorrectMinus[i];
									unDataUDPCreat.data.unUdpData.stSettingSystemCommutator.GainCorrectNool[i]=operation_data->muchGainCorrectNool[i];
									unDataUDPCreat.data.unUdpData.stSettingSystemCommutator.GainCorrectPlus[i]=operation_data->muchGainCorrectPlus[i];
									unDataUDPCreat.data.unUdpData.stSettingSystemCommutator.GainCorrectChennel[i]=operation_data->muchGainCorrectNormal[i];
								}
						 }
						 nrotIpaddres.Ipaddress=operation_data->nIpPAY;
			       nrotIpaddres1.ByteData[0]=nrotIpaddres.ByteData[3];
						 nrotIpaddres1.ByteData[1]=nrotIpaddres.ByteData[2];
						 nrotIpaddres1.ByteData[2]=nrotIpaddres.ByteData[1];
             nrotIpaddres1.ByteData[3]=nrotIpaddres.ByteData[0];		 
						 unDataUDPCreat.data.unUdpData.stSettingSystemCommutator.IpAddressPay=nrotIpaddres1.Ipaddress;
						 unDataUDPCreat.data.unUdpData.stSettingSystemCommutator.ResetCommutator=operation_data->uchResetSetting;
						 unDataUDPCreat.data.unUdpData.stSettingSystemCommutator.TypeCommutator=operation_data->uchTypeComm;
						 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP+sizeof(SettingSystemCommutator))<<8);	
             size_udp=(BASE_SIZE_PAY+sizeof(SettingSystemCommutator))+((BASE_SIZE_PAY+sizeof(SettingSystemCommutator))-(((BASE_SIZE_PAY+sizeof(SettingSystemCommutator))>>1)<<1));
						 size_correct=size_udp-(BASE_SIZE_PAY+sizeof(SettingSystemCommutator));
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();						 
			       break;		
			 case 1: 
						 *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
			       *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK)+((BASE_SIZE_PACK)-(((BASE_SIZE_PACK)>>1)<<1));
			       creat_ip_heder(mode);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY)))<<8u);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_SYSTEM;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_IP_pack;
					   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP)<<8);
				     size_udp=(BASE_SIZE_PAY)+((BASE_SIZE_PAY)-(((BASE_SIZE_PAY)>>1)<<1));
			       size_correct=size_udp-(BASE_SIZE_PAY);
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();			
						 break;
			 case 2:
             *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
			       *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK)+((BASE_SIZE_PACK)-(((BASE_SIZE_PACK)>>1)<<1));
             creat_ip_heder(mode);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY)))<<8u);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_SYSTEM;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
					   unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_IPMASK_pack;
					   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP)<<8);
				     size_udp=(BASE_SIZE_PAY)+((BASE_SIZE_PAY)-(((BASE_SIZE_PAY)>>1)<<1));
			       size_correct=size_udp-(BASE_SIZE_PAY);
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();			
						 break;					 
			 case 3:
				     *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
			       *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK)+((BASE_SIZE_PACK)-(((BASE_SIZE_PACK)>>1)<<1));
						 creat_ip_heder(mode);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY)))<<8u);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_SYSTEM;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
					   unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_NUMBER_PORT_pack;
						 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP)<<8);
						 size_udp=(BASE_SIZE_PAY)+((BASE_SIZE_PAY)-(((BASE_SIZE_PAY)>>1)<<1));
						 size_correct=size_udp-(BASE_SIZE_PAY);
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();			
				     break;
			 case 4:
				     *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
			       *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK)+((BASE_SIZE_PACK)-(((BASE_SIZE_PACK)>>1)<<1));
						 creat_ip_heder(mode);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY)))<<8u);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_SYSTEM;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_MAC_pack;
						 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP)<<8);
						 size_udp=(BASE_SIZE_PAY)+((BASE_SIZE_PAY)-(((BASE_SIZE_PAY)>>1)<<1));
						 size_correct=size_udp-(BASE_SIZE_PAY);
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();			
				     break;
			 case 5:
             *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
			       *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK)+((BASE_SIZE_PACK)-(((BASE_SIZE_PACK)>>1)<<1));
						 creat_ip_heder(mode);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY)))<<8u);
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_APLICATION;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
						 unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_CONFIGURE_COMMUTATOR_pack; 
						 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP)<<8);
						 size_udp=(BASE_SIZE_PAY)+((BASE_SIZE_PAY)-(((BASE_SIZE_PAY)>>1)<<1));
					   size_correct=size_udp-(BASE_SIZE_PAY);
						 for(i=0;i<size_udp/2;i++)
						 {
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						 }
						 if(size_correct!=0)
						 {
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						 }
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();			
				     break;
			 case 7:
				    *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
			      *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK)+((BASE_SIZE_PACK)-(((BASE_SIZE_PACK)>>1)<<1));
						creat_ip_heder(mode);
					  unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY)))<<8u);
					  unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_APLICATION;
					  unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_REQEST_PAY_OPERATE;
			      unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_CONFIGURE_SYSTEM_COMMUTATOR_pack; 
						*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP)<<8);
						size_udp=(BASE_SIZE_PAY)+((BASE_SIZE_PAY)-(((BASE_SIZE_PAY)>>1)<<1));
						size_correct=size_udp-(BASE_SIZE_PAY);
						for(i=0;i<size_udp/2;i++)
						{
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						}
						if(size_correct!=0)
						{
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						}
			      *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();			
      			break;
			 case 0xFE:
            *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
			      *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK)+((BASE_SIZE_PACK)-(((BASE_SIZE_PACK)>>1)<<1));
						creat_ip_heder(mode);
						unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY)))<<8u);
						unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_APLICATION;
					  unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_error_OPERATE_PAY;
						unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_CONFIGURE_SYSTEM_COMMUTATOR_pack;
						unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_REQEST_PAY;
						*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP)<<8);
					  size_udp=(BASE_SIZE_PAY)+((BASE_SIZE_PAY)-(((BASE_SIZE_PAY)>>1)<<1));
						size_correct=size_udp-(BASE_SIZE_PAY);
						for(i=0;i<size_udp/2;i++)
						{
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						}
						if(size_correct!=0)
						{
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						}
			      *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();			
			      break;
			 case 0xFF:
				    *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
			      *((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(BASE_SIZE_PACK)+((BASE_SIZE_PACK)-(((BASE_SIZE_PACK)>>1)<<1));
						creat_ip_heder(mode);
						unDataUDPCreat.data.stPAYHeaderPackEthernet.DLC_FIELD=(((uint16_t)((BASE_SIZE_PAY)))<<8u);
						unDataUDPCreat.data.stPAYHeaderPackEthernet.WS_FIELD=WS_FIELD_APLICATION;
					  unDataUDPCreat.data.stPAYHeaderPackEthernet.KOP_FIELD=KOP_error_format_PAY;
						unDataUDPCreat.data.stPAYHeaderPackEthernet.NP_FIELD=NP_REQEST_PAY;
						*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack)))=((BASE_SIZE_UDP)<<8);
						size_udp=(BASE_SIZE_PAY)+((BASE_SIZE_PAY)-(((BASE_SIZE_PAY)>>1)<<1));
						size_correct=size_udp-(BASE_SIZE_PAY);
						for(i=0;i<size_udp/2;i++)
						{
							  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+i])))=unDataUDPCreat.shUdpData[i];
						}
						if(size_correct!=0)
						{
							   data=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)];
							   data&=0x00FF;
							   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[4+(i-1)])))=data;
						}
			       *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm)))=WritecheskSumUDP();			
			      break;			
		}
		if(size_dop!=0)
		{
			 for(i=0;i<(size_dop);i++)
			 {
				  *((uint16_t*)(BaseAddresEhernet+head+i*2))=xtBuffer[size_curr+i]; 
			 }
			 for(i=0;i<(size_curr);i++)
			 {
				 *((uint16_t*)(BaseAddresEhernet+head1+i*2))=xtBuffer[i];
			 }	 
		}
		SendPacket(nSizeSend);
 }
 
 
uint8_t UniversalBufferDataRD() 
{
	uint32_t head_xt;
	uint16_t head,head1,perenos,perenos1,head_t;
	uint8_t type_message=0;
	uint16_t length_icmp=0;
	head_xt=length_Reciver_Message;
	head_t=(uint16_t)(head_xt&0xFFFF);
	head=ETHERNET->R_Head;
	head1=head;
	head=head+head_t+4;
	if(head>0x1000)
	{	
				perenos=head-0x1000;
		    perenos1=((uint16_t)(length_Reciver_Message)+4)-perenos;	  
		    memcpy((void *)xtBuffer,(const void*)(BaseAddresEhernet+head1),perenos1);	
        memcpy((void *)(xtBuffer+perenos1/2),(const void*)(BaseAddresEhernet+0),perenos); 
				pPackEthernet=(PackEthernet*)(xtBuffer);
	}
	pPackEthernet=(PackEthernet*)(BaseAddresEhernet+head1);
  if(pPackEthernet->stHeaderPackEthernet.TypeProtocol==TYPE_IP_MASSAGE)
	{	
		  if((pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSenderIp.IPSender==operation_data->nIpComm)|(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSenderIp.IPSender==0xFFFFFFFF))
			{
//				 if((pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSourceIp.IPSource==operation_data->nIpPAY)|
//					 (pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSourceIp.IPSource==BRODCAST_IP_ADDRES))
//				 {
					   if((pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.IpcheckSumm==WritecheskSumIP())|(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.IpcheckSumm==0x0000))
						 {
									  if(((pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.TipeProtocol)&0xFF00)==TYPE_UDP_MESG)
										{
													// if(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.SourceUDPPort==operation_data->usnNumberPortPAY)
													//{
												 if((pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.IDP_FIELD==IDP_COMMUTATOR_R)|
													 (pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.IDP_FIELD==IDP_IDO_BROADCAST))
												 {
														 if(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.IDO_FIELD==IDP_IDO_PAY)
														 {
																if(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.KOP_FIELD==KOP_LEVEL_SIGNAL)
																{
																		 if((pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm==WritecheskSumUDP())|
																		 (pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm==0xFFFF))
																	   {
																				type_message=90; //уровень сигнала 
																		 }
																}
																if(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.KOP_FIELD==KOP_WRITE_DATA)
																{
																	 if((pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm==WritecheskSumUDP())|
																		 (pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm==0xFFFF))
																	 {
																		  if(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.WS_FIELD==VC_SYSTEM_INFO)
																			{
																				 type_message=10+pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.NP_FIELD;
																			}
																			if(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.WS_FIELD==VC_APLICATE_DATA)
																			{
																				 type_message=15+pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.NP_FIELD;
																			}	
																	 }
																	 else
																	 {
																			 type_message=0xFF;																			 
																	 }	
																}
																if(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.KOP_FIELD==KOP_READ_DATA)
																{
																	 if((pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm==WritecheskSumUDP())|
																		 (pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.UDPChekSumm==0xFFFF))
																	 {
																		  if(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.WS_FIELD==VC_SYSTEM_INFO)
																			{
																				 type_message=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.NP_FIELD;
																			}
																			if(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.WS_FIELD==VC_APLICATE_DATA)
																			{
																				 type_message=5+pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.NP_FIELD;
																			}		
																	 }
																	 else
																	 {
																			 type_message=0xFF;
																	 }
																}
														 }
												 }
												 if(type_message!=0)
												 {
														operation_data->nIpPAY=pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSourceIp.IPSource;
													  
													  operation_data->usnNumberPortPAY=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.SourceUDPPort;
												 }
												 
											// }
										} 
										if(((pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.TipeProtocol)&0xFF00)==TYPE_ICMP_MESG)
										{
												if(pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.TypeAndCodeICMPMessage==TYPE_AND_CODE_ICMP) //Ё’ќ «јѕ–ќ—
												{
													  length_icmp=((pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)>>8u)-20u;
													  length_icmp=(length_icmp+(length_icmp-((length_icmp>>1u)<<1u)))/2u;
														if(pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.IcmpCheckSumm==WritecheskSumICMP(length_icmp))
														{
															type_message=50; //пинг «јѕ–ќ—
														}											
												}
												if(type_message!=0)
												{
														operation_data->nIpPAY=pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSourceIp.IPSource;
												}
										}	
						 }
		}
//			}	
	}
	if(pPackEthernet->stHeaderPackEthernet.TypeProtocol==Type_ARP_MESG)
	{
		  if(pPackEthernet->unIPdata.stARPPackEthernet.TipeArpPack==ANSWER_ARP_MESG)
			{
					//if(pPackEthernet->unIPdata.stARPPackEthernet.ARPIPSource==operation_data->nIpPAY)
					//{
						if(pPackEthernet->unIPdata.stARPPackEthernet.unARPIPsender.ARPIPSender==(operation_data->nIpComm))
						{
								type_message=60;
							  operation_data->nIpPAY=pPackEthernet->unIPdata.stARPPackEthernet.ARPIPSource;
						}
					//}
			}	 	
	}
	if(type_message!=0) 
	{
					operation_data->musnMacPay[0]=pPackEthernet->stHeaderPackEthernet.MacSourceH;
				  operation_data->musnMacPay[1]=pPackEthernet->stHeaderPackEthernet.MacSourceM;
				  operation_data->musnMacPay[2]=pPackEthernet->stHeaderPackEthernet.MacSourceL;          
	}
	return type_message;
};	
 
//‘ункци¤ формировани¤ ARP запроса клиенска¤ часть

void ARP_replay_client(void)
{
	uint16_t head,head1,nSizeSend,size_dop,size_curr,i;
	head=ETHERNET->X_Head;
	head1=head;
	nSizeSend=sizeof(HeaderPackEthernet)+sizeof(ARPPackEthernet);
	nSizeSend=(4-(nSizeSend-((nSizeSend>>2)<<2)))+nSizeSend;
	if((head+nSizeSend+4u)>0x2000)
	{
				ClearMemoryTransmiter(0x1000);
				size_dop=(((head+nSizeSend+4u)-0x2000)>>1);
				size_curr=((nSizeSend+4u)/2)-size_dop;
				head=0x1000;
			  pPackEthernet=(PackEthernet*)(xtBuffer);
	}
	else
	{
			size_dop=0;
			size_curr=0;
			pPackEthernet=(PackEthernet*)(BaseAddresEhernet+head);
	}	
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.LengthPack)))=0x0000;
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderH)))=0xFFFF;
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderM)))=0xFFFF;
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderL)))=0xFFFF;	
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSourceH)))=operation_data->musnMacComm[0];
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSourceM)))=operation_data->musnMacComm[1];
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSourceL)))=operation_data->musnMacComm[2];	
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=Type_ARP_MESG;
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=sizeof(HeaderPackEthernet)+sizeof(ARPPackEthernet)-4u;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.TypeCarrier)))=0x0100;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.IPV4Protocol)))=0x0008;
  *((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.SizeARPPack)))=0x0406;	
	*((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.TipeArpPack)))=0x0100;
  *((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacHSource)))=operation_data->musnMacComm[0];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacMSource)))=operation_data->musnMacComm[1];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacLSource)))=operation_data->musnMacComm[2];
	*((uint32_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPIPSource)))=operation_data->nIpComm;
  *((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacHSender)))=0x0000;
  *((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacMSender)))=0x0000;
  *((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacLSender)))=0x0000;
  *(((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.unARPIPsender.chARPIPSender[0]))))=0x0000;//0x0C0A;
	*(((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.unARPIPsender.chARPIPSender[1]))))=0x0000;//0x8000;
	if(size_dop!=0)
		{
			 for(i=0;i<(size_dop);i++)
			 {
				  *((uint16_t*)(BaseAddresEhernet+head+i*2))=xtBuffer[size_curr+i]; 
			 }
			 for(i=0;i<(size_curr);i++)
			 {
				 *((uint16_t*)(BaseAddresEhernet+head1+i*2))=xtBuffer[i];
			 }	 
		}
	 SendPacket(nSizeSend);
}



//‘ункци¤ формировани¤ IGMP запроса о присоединение  клиенска¤ часть

void IGMP_replay_client(void)
{
	uint16_t head,head1,nSizeSend,size_dop,size_curr,i;
	head=ETHERNET->X_Head;
	ARPIPsender snARPIPsender;
	head1=head;
  nSizeSend=(sizeof(HeaderPackEthernet))+sizeof(IPHeaderPackEthernet)+20u;
	nSizeSend=(4-(nSizeSend-((nSizeSend>>2)<<2)))+nSizeSend;
	if((head+nSizeSend+4u)>0x2000)
	{
				ClearMemoryTransmiter(0x1000);
				size_dop=(((head+nSizeSend+4u)-0x2000)>>1);
				size_curr=((nSizeSend+4u)/2)-size_dop;
				head=0x1000;
			  pPackEthernet=(PackEthernet*)(xtBuffer);
	}
	else
	{
			size_dop=0;
			size_curr=0;
			pPackEthernet=(PackEthernet*)(BaseAddresEhernet+head);
	}	
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.LengthPack)))=0x0000;
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderH)))=0x0001;
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderM)))=0x005E;
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSenderL)))=0x1600;	
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSourceH)))=operation_data->musnMacComm[0];
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSourceM)))=operation_data->musnMacComm[1];
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.MacSourceL)))=operation_data->musnMacComm[2];
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.StatusPack)))=(sizeof(HeaderPackEthernet)-4)+sizeof(IPHeaderPackEthernet)+20u;
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.VersiaIP)))=0x0046;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.IndetificatorPack)))=0x0000;
 	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.NumerFragment)))=0x0000;
  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.TipeProtocol)))=0x0201;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=sizeof(IPHeaderPackEthernet)+20U;	
	snARPIPsender.IPSender=0x160000e0; 
  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSenderIp.chARPIPSender[0])))=snARPIPsender.chARPIPSender[0];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSenderIp.chARPIPSender[1])))=snARPIPsender.chARPIPSender[1];
	snARPIPsender.IPSource=operation_data->nIpComm;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSourceIp.chARPIPSender[0])))=snARPIPsender.chARPIPSender[0];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSourceIp.chARPIPSender[1])))=snARPIPsender.chARPIPSender[1];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.IpcheckSumm)))=WritecheskSumIP();
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.mDataIGMP_4[0])))=0x0494;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.mDataIGMP_4[1])))=0x0000;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.mDataIGMP_4[2])))=0x0022;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.mDataIGMP_4[3])))=0x01f9;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.mDataIGMP_4[4])))=0x0000;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.mDataIGMP_4[5])))=0x0100;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.mDataIGMP_4[6])))=0x0004;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.mDataIGMP_4[7])))=0x0000;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.mDataIGMP_4[8])))=0x00e0;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.mDataIGMP_4[9])))=0xfc00;
	if(size_dop!=0)
		{
			 for(i=0;i<(size_dop);i++)
			 {
				  *((uint16_t*)(BaseAddresEhernet+head+i*2))=xtBuffer[size_curr+i]; 
			 }
			 for(i=0;i<(size_curr);i++)
			 {
				 *((uint16_t*)(BaseAddresEhernet+head1+i*2))=xtBuffer[i];
			 }	 
		}
	 SendPacket(nSizeSend);
}


uint32_t CyrcleShift(uint32_t data, uint8_t size_data, uint8_t shift)
{
	 uint8_t i;
	 uint64_t xt;
   xt=data;	
	 for(i=0;i<shift;i++)
	 {
		 xt=xt<<1;
		 xt=xt+((xt&(1<<size_data))>>size_data);
		 xt&=((1<<size_data)-1);
	 }
	 return (uint32_t)(xt);
}
