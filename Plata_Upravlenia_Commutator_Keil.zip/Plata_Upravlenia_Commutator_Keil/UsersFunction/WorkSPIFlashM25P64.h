﻿//Библеотека WorkSPIFlashM25P64.h для работы с SPIFlash M25P64

#ifndef WORK_SPI_FLASH_M25P64_H
#define WORK_SPI_FLASH_M25P64_H

#include "opora.h"
extern void WREN_Operation(void); // Функция включения записи у SPIFlash
extern void Read_status(uint8_t falag_ok);  // Функция чтения статус байта SPIFlash
extern uint32_t Test_connect_Flash(void); // Функция тестирования связи SPIFlash c микроконтроллером
extern void write_data_flash(uint8_t *buffer, uint32_t number_byte, uint32_t addres_write); // Функция записи данных в SPIFlash
extern void read_data_flash(uint8_t *buffer, uint32_t number_byte, uint32_t addres_read); // Функция чтения данных в SPIFlash

extern void ReadDataFlashToStruct(void); //функция чтения из SPIFLASH 
extern void SaveDataStructToFlash(void); //функция записи из SPIFLASH
extern void clean_sector(uint32_t addres_write);//функция стерания выбраного сектора
extern void clean_all_sectores(void); //фуекция стирание всех секторов

#define SSP_OFF     PORTC->RXTX&=0xEFFF
#define SSP_ON      PORTC->RXTX|=4096
#define Start_SPI   SPI2->SSPx_CR1=2
#define Stop_SPI    SPI2->SSPx_CR1=1
#define SPI_NOT_ACTIVE (((SPI2->SSPx_SR)&0x10)==0x10)
#define SPI_BUFFER_PUST (((SPI2->SSPx_SR)&0x01)==0x01)
#define SPI_BUFFER_TR_OK (((SPI2->SSPx_SR)&0x02)==0x02)

extern uint32_t addres_spi_memory;

#endif /*WORK_SPI_FLASH_M25P64_H*/
