#ifndef DATA_PACKET_H
#define DATA_PACKET_H
#define struct __packed struct
#define union __packed union
#pragma anon_unions

#include <stdint.h>
static uint32_t header_hardware_r[9]={2,2,2,2,2,2,2,2,2};
#define STATUS_PACK_R nBuffer[0]
#define LENGTH_PACK_R nBuffer[1]
#define MAC_SENDER_R_H nBuffer[2] //2
#define MAC_SENDER_R_M nBuffer[3] //2
#define MAC_SENDER_R_L nBuffer[4] //2
#define MAC_SOURSE_R_H nBuffer[5] //2
#define MAC_SOURSE_R_M nBuffer[6] //2
#define MAC_SOURSE_R_L nBuffer[7] //2
#define TYPE_PROTOCOL_R nBuffer[8] //2
//************************************
static uint32_t ip_header_r[8]={2,2,2,2,2,2,4,4};
#define VERSIA_IP_R nBuffer[9]//2
#define LENGTH_FULL_PACK_R IP nBuffer[10]//2
#define IDETIFICATOR_PACK_R nBuffer[11]//2
#define NUMER_FRAGMENT_R nBuffer[12]//2
#define TIPE_PROTOCOL_R  nBuffer[13]//2
#define IP_CHEKSUMM_R  nBuffer[14]//2
#define SOURSE_IP_R  nBuffer[15]//4
#define SENDER_IP_R  nBuffer[16]//4
//************************************
static uint32_t arp_pack_r[12]={2,2,2,2,2,2,2,4,2,2,2,4};
#define TYPE_CARRIER_R nBuffer[9]//2
#define IPV4_PROTOCOL_R nBuffer[10]//2
#define SIZE_ARP_PACK_R nBuffer[11]//2
#define TYPE_ARP_R nBuffer[12]//2
#define ARP_MAC_SOURSE_R_H nBuffer[13]//2
#define ARP_MAC_SOURSE_R_M nBuffer[14]//2
#define ARP_MAC_SOURSE_R_L nBuffer[15]//2
#define ARP_IP_SOURSE_R nBuffer[16]//4
#define ARP_MAC_SENDER_R_H nBuffer[17]//2
#define ARP_MAC_SENDER_R_M nBuffer[18]//2
#define ARP_MAC_SENDER_R_L nBuffer[19]//2
#define ARP_IP_SENDER_R nBuffer[20]//4
//************************************
static uint32_t udp_header_r[4]={2,2,2,2};
#define SOURSE_UDP_PORT_R nBuffer[17]//2
#define SENDER_UDP_PORT_R nBuffer[18]//2
#define LENGTH_UDP_PACK_R nBuffer[19]//2
#define UDP_CHEKSUMM_R nBuffer[20]//2
//************************************
static uint32_t pay_format_r[6]={2,2,2,1,1,1};
#define IDP_FIELD_R nBuffer[21]//2
#define IDO_FIELD_R nBuffer[22]//2
#define DLC_FIELD_R nBuffer[23]//2
#define WS_FIELD_R nBuffer[24]//1
#define KOP_FIELD_R nBuffer[25]//1
#define NP_FIELD_R nBuffer[26]//1 
//************************************
static uint32_t packet_new_ip_r[1]={4};
#define NEW_IP_COMMUTATOR_R nBuffer[27]//4
//************************************
static uint32_t packet_new_ipmask_r[1]={4};
#define NEW_IPMASK_COMMUTATOR_R nBuffer[27]//4
//************************************
static uint32_t packet_new_UDPport_r[1]={2};
#define NEW_UDP_PORT_COMMUTATOR_R nBuffer[27]//2
//************************************
static uint32_t packet_new_mac_r[3]={2,2,2};
#define NEW_MAK_COMMUTATOR_R_H nBuffer[27]//2
#define NEW_MAK_COMMUTATOR_R_M nBuffer[28]//2
#define NEW_MAK_COMMUTATOR_R_L nBuffer[29]//2
//************************************
static uint32_t packet_new_setting_commutator_r[41]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1,1,1,1};
#define MODE_WORK_COMMUTATOR_R nBuffer[27]//1
#define OUT_OR_IN_NUMER_R(X) nBuffer[28+X]//1:16
#define TRANSFER_FACTOR_R(X) nBuffer[44+X]//1:8
#define TEMPERATURE_PLATA_N1_R nBuffer[52]//2
#define TEMPERATURE_PLATA_N2_R nBuffer[53]//2
#define FLAG_STATE nBuffer[54]//1 
			
//************************************
static uint32_t packet_new_system_setting_commutator_r[40]={1,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
#define TYPE_COMMUTATOR_R nBuffer[27]//1
#define FACTORY_NUMER_SYMBOL_R(X) nBuffer[28+X]//2:6
#define RESET_COMMUTATOR_R nBuffer[34]//1
#define GAIN_CORRECT_MINUS_CHANNEL_R(X) nBuffer[35+X]//1:8
#define GAIN_CORRECT_NORMAL_CHANNEL_R(X) nBuffer[43+X]//1:8
#define GAIN_CORRECT_PLUS_CHANNEL_R(X) nBuffer[51+X]//1:8
#define GAIN_CORRECT_CHANNEL_R(X) nBuffer[35+X]//1:8

	
#define CONTROL_POINT_1  8	
	

#define UDP_HEADER_R_BYTE_SIZE 8
#define PACKET_NEW_MAC_R_BYTE_SIZE 6
#define PACKET_NEW_UDPPORT_R_BYTE_SIZE 2
#define PACKET_NEW_IPMASK_R_BYTE_SIZE 4
#define PACKET_NEW_IP_R_BYTE_SIZE 4
#define PACKET_NEW_SYSTEM_SETTING_COMMUTATOR_R_BYTE_SIZE 40
#define PACKET_NEW_SETTING_COMMUTATOR_R_BYTE_SIZE 41
#define PAY_FORMAT_R_BYTE_SIZE 9
#define ARP_PACK_R_SIZE 12
#define IP_HEADER_R_BYTE_SIZE 20 
#define HEADER_HARDWARE_R_BYTE_SIZE 18	
	
	
#define UDP_HEADER_R_SIZE 4
#define PACKET_NEW_MAC_R_SIZE 3
#define PACKET_NEW_UDPPORT_R_SIZE 1
#define PACKET_NEW_IPMASK_R_SIZE 1
#define PACKET_NEW_IP_R_SIZE 1
#define PACKET_NEW_SYSTEM_SETTING_COMMUTATOR_R_SIZE 40
#define PACKET_NEW_SETTING_COMMUTATOR_R_SIZE 41
#define PAY_FORMAT_R_SIZE 6
#define ARP_PACK_R_SIZE 12
#define IP_HEADER_R_SIZE 8 
#define HEADER_HARDWARE_R_SIZE 9

//************************************
static uint32_t header_packet_t[2]={2,2};
#define STATUS_PACK_T    nBuffer[0]=0x0000;//2
#define LENGTH_PACK_T(X) nBuffer[1]=X;//2
#define LENGTH_PACKET_TYMESSAGE_0 50u //DLC_reqest_operate_PAY+8+20+14
#define LENGTH_PACKET_TYMESSAGE_1 55u //DLC_set_IP+8+20+14
#define LENGTH_PACKET_TYMESSAGE_2 55u //DLC_set_IP_mask+8+20+14
#define LENGTH_PACKET_TYMESSAGE_3 53u	//DLC_SET_NUMBER_PORT+8+20+14
#define LENGTH_PACKET_TYMESSAGE_4 57u //DLC_set_MAC+8+20+14
#define LENGTH_PACKET_TYMESSAGE_5 92u	//DLC_SET_READ_DATA+8+20+14
#define LENGTH_PACKET_TYMESSAGE_6 92u	//DLC_SET_WRITE_DATA+8+20+14
#define LENGTH_PACKET_TYMESSAGE_7 97u	//DLC_SET_READ_DATA_SYSTEM+8+20+14
//************************************
static uint32_t header_hardware_t[7]={2,2,2,2,2,2,2};
#define MAC_SENDER_T_H nBuffer[2]=operation_data->musnMacPay[0]; //2
#define MAC_SENDER_T_M nBuffer[3]=operation_data->musnMacPay[1]; //2
#define MAC_SENDER_T_L nBuffer[4]=operation_data->musnMacPay[2]; //2
#define MAC_SOURSE_T_H nBuffer[5]=operation_data->musnMacComm[0]; //2
#define MAC_SOURSE_T_M nBuffer[6]=operation_data->musnMacComm[1]; //2
#define MAC_SOURSE_T_L nBuffer[7]=operation_data->musnMacComm[2]; //2
#define ARP_TYPE_T   nBuffer[8]=0x0806; //2
#define IP_TYPE_T    nBuffer[8]=0x0800; //2
#define TYPE_ARP_PACK 2
#define TYPE_IP_PACK 1
//************************************
static uint32_t ip_header_t[8]={2,2,2,2,2,2,4,4};
#define VERSIA_IP_T nBuffer[9]=0x4500;//2
#define LENGTH_FULL_PACK_T(X)  nBuffer[10]=X;//2
#define IDETIFICATOR_PACK_T nBuffer[11]=0x0000;//2
#define IDETIFICATOR_FRAGMENT_PACK_T nBuffer[12]=0x0000;//2
#define TIPE_PROTOCOL_T  nBuffer[13]=0x8011;//2
#define IP_CHEKSUMM_T  nBuffer[14]=WritecheskSumIP();//2 //функция подсчета чексуммы
#define SOURSE_IP_T  nBuffer[15]=operation_data->nIpComm;//4
#define SENDER_IP_T  nBuffer[16]=operation_data->nIpPAY;//4
#define LENGTH_IP_TYMESSAGE_0 36u //DLC_reqest_operate_PAY+8+20
#define LENGTH_IP_TYMESSAGE_1 41u //DLC_set_IP+8+20
#define LENGTH_IP_TYMESSAGE_2 41u //DLC_set_IP_mask+8+20
#define LENGTH_IP_TYMESSAGE_3 39u	//DLC_SET_NUMBER_PORT+8+20
#define LENGTH_IP_TYMESSAGE_4 43u //DLC_set_MAC+8+20
#define LENGTH_IP_TYMESSAGE_5 78u	//DLC_SET_READ_DATA+8+20
#define LENGTH_IP_TYMESSAGE_6 78u	//DLC_SET_WRITE_DATA+8+20
#define LENGTH_IP_TYMESSAGE_7 83u	//DLC_SET_READ_DATA_SYSTEM+8+20

//************************************
static uint32_t arp_pack_t[12]={2,2,2,2,2,2,2,4,2,2,2,4};
#define TYPE_CARRIER_T nBuffer[9]=0x0001;//2
#define IPV4_PROTOCOL_T nBuffer[10]=0x0800;//2
#define SIZE_ARP_PACK_T nBuffer[11]=0x0604;//2
#define TYPE_ARP_T nBuffer[12]=0x0002;//2
#define ARP_MAC_SOURSE_T_H nBuffer[13]=operation_data->musnMacComm[0]; //2
#define ARP_MAC_SOURSE_T_M nBuffer[14]=operation_data->musnMacComm[1]; //2
#define ARP_MAC_SOURSE_T_L nBuffer[15]=operation_data->musnMacComm[2]; //2
#define ARP_IP_SOURSE_T nBuffer[16]=operation_data->nIpComm;//4
#define ARP_MAC_SENDER_T_H nBuffer[17]=operation_data->musnMacPay[0];//2
#define ARP_MAC_SENDER_T_M nBuffer[18]=operation_data->musnMacPay[1];//2
#define ARP_MAC_SENDER_T_L nBuffer[19]=operation_data->musnMacPay[2];//2
#define ARP_IP_SENDER_T nBuffer[20]=operation_data->nIpPAY;//4
//************************************
static uint32_t pay_format_t[6]={2,2,2,1,1,1};
#define IDP_FIELD_T(X) nBuffer[21]=X;//2
#define IDO_FIELD_T(X) nBuffer[22]=X;//2
#define DLC_FIELD_T(X) nBuffer[23]=X;//2
#define WS_FIELD_T(X) nBuffer[24]=X;//1
#define KOP_FIELD_T(X) nBuffer[25]=X;//1
#define NP_FIELD_T(X) nBuffer[26]=X;//1
#define IDP_IDO_CM16_4   0x6400 // ИДП/ИДО коммутатора СМ16-4
#define IDP_IDO_DM4_16  0x6500 // ИДП/ИДО коммутатора ДМ4-16
#define IDP_IDO_CMDM8_4  0x6600 //ИДП/ИДО коммутатора СМДМ8-4
#define IDP_IDO_PAY  0x0080 // ИДП/ИДО ПАУ
#define IDP_IDO_BROADCAST  0x0000 // ИДП/ИДО ШИРОКОВЕЩАТЕЛЬНЫЙ 
#define DLC_reqest_operate_PAY  0x0900  // ДЛС при ответе на сообщения от ПАУ
#define DLC_error_operate_PAY  0x0900 // ДЛС при ответе на сообщения от ПАУ
#define DLC_error_format_PAY  0x0900 // ДЛС при ответе на сообщения от ПАУ
#define DLC_set_MAC  15 // ДЛС при записи MAC адреса коммутатора
#define DLC_set_IP  13 // ДЛС при записи IP адреса коммутатора
#define DLC_set_IP_mask  13 // ДЛС при записи IP MACки коммутатора
#define DLC_SET_NUMBER_PORT  11 // ДЛС при записи номера порта коммутатора
#define DLC_SET_READ_DATA  50 // ДЛС при чтение формата управления коммутатора
#define DLC_SET_WRITE_DATA  50 // ДЛС при записи формата управления коммутатора
#define DLC_SET_READ_DATA_SYSTEM  55 // ДЛС при чтение служебных данных коммутатора
#define DLC_SET_WRITE_DATA_SYSTEM  55 // ДЛС при записи служебных данных коммутатора
#define VC_SYSTEM_INFO  0x30 //  ВС - служебная команда
#define VC_APLICATE_DATA  0x31 //  ВС - команда содержащая блок прикладной информации
#define VC_LEVEL_SIGNAL  0xE5 // ВС - Уровень сигнала 
#define KOP_READ_DATA  0x44 //  КОП -запись данных
#define KOP_WRITE_DATA  0x48 // КОП -чтение данных
#define KOP_REQEST_PAY_OPERATE  0x00 // КОП - команда  от ПАУ обработана
#define KOP_error_OPERATE_PAY  0x02 // КОП - неверный код операции
#define KOP_error_format_PAY  0x03 // КОП - неформатное сообщение от ПАУ
#define KOP_LEVEL_SIGNAL  0x12 // КОП - Уровень сигнала

#define NP_REQEST_PAY 0x00 // квитанция для ПАУ
#define NP_IP_pack  0x01 // НП - Ip адрес коммутатора
#define NP_IPMASK_pack  0x02 // НП - Ip MACка  коммутатора
#define NP_NUMBER_PORT_pack  0x03 // НП - номер порта коммутатора
#define NP_MAC_pack  0x04 // НП - MAC адрес коммутатора
#define NP_CONFIGURE_COMMUTATOR_pack  0x00 // НП - конфигурация коммутатора
#define NP_READ_TEMPERATURE_pack  0x01 // НП - температуры коммутатора
#define NP_CONFIGURE_SYSTEM_COMMUTATOR_pack  0x02 // НП  - служебная информация коммутатора
#define NP_EVEL_SIGNAL 0x34 // НП - Уровень сигнала
static uint32_t ido_comm[4]={IDP_IDO_CM16_4,IDP_IDO_CM16_4,IDP_IDO_DM4_16,IDP_IDO_CMDM8_4};
#define IDP_COMMUTATOR_R ido_comm[operation_data->uchTypeComm]  
//************************************
static uint32_t packet_new_setting_commutator_t[41]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1,1,1,1};
#define MODE_WORK_COMMUTATOR_T nBuffer[27]=operation_data->uchWork;//1
#define OUT_OR_IN_NUMER_T(X) nBuffer[28+X]=operation_data->muchSwitchComm[X]; //1:16
#define TRANSFER_FACTOR_T(X) nBuffer[44+X]=operation_data->muchGainManger[X]; //1:8
#define TEMPERATURE_PLATA_N1_T nBuffer[52]=operation_data->usnTemperatureN1; //2
#define TEMPERATURE_PLATA_N2_T nBuffer[53]=operation_data->usnTemperatureN2;  //2
#define FLAG_STATE_T nBuffer[54]=operation_data->uchStatusFlags;//1
#define REZERV_BYTE_T(X) nBuffer[55+X]=operation_data->muchRezervByte[X];//1:11 
//************************************
static uint32_t packet_new_system_setting_commutator_t[40]={1,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
#define TYPE_COMMUTATOR_T nBuffer[27]=operation_data->uchTypeComm;//1
#define FACTORY_NUMER_SYMBOL_T(X) nBuffer[28+X]=operation_data->muchFactoryNumer[X];//2:6
#define RESET_COMMUTATOR_T nBuffer[34]=operation_data->uchResetSetting;//1
#define GAIN_CORRECT_MINUS_CHANNEL_T(X) nBuffer[35+X]=operation_data->muchGainCorrectMinus[X];//1:8
#define GAIN_CORRECT_NORMAL_CHANNEL_T(X) nBuffer[43+X]=operation_data->muchGainCorrectNormal[X];//1:8
#define GAIN_CORRECT_PLUS_CHANNEL_T(X) nBuffer[51+X]=operation_data->muchGainCorrectPlus[X];//1:8
#define GAIN_CORRECT_CHANNEL_T(X) nBuffer[59+X]=operation_data->muchGainCorrectNool[X];//1:8	
//************************************	
static uint32_t packet_new_ip_t[1]={4};
#define NEW_IP_COMMUTATOR_T nBuffer[27]=operation_data->nIpComm;//4
//************************************
static uint32_t packet_new_ipmask_t[1]={4};
#define NEW_IPMASK_COMMUTATOR_T nBuffer[27]=operation_data->nIpMaskComm;//4
//************************************
static uint32_t packet_new_UDPport_t[1]={2};
#define NEW_UDP_PORT_COMMUTATOR_T nBuffer[27]=operation_data->usnNumberPortComm;//2
//************************************
static uint32_t packet_new_mac_t[3]={2,2,2};
#define NEW_MAK_COMMUTATOR_T_H nBuffer[27]=operation_data->musnMacComm[0];//2
#define NEW_MAK_COMMUTATOR_T_M nBuffer[28]=operation_data->musnMacComm[1];//2
#define NEW_MAK_COMMUTATOR_T_L nBuffer[29]=operation_data->musnMacComm[2];//2
//************************************
static uint32_t udp_header_t[4]={2,2,2,2};
#define SOURSE_UDP_PORT_T nBuffer[17]=operation_data->usnNumberPortComm;//2
#define SENDER_UDP_PORT_T nBuffer[18]=operation_data->usnNumberPortPAY;//2
#define LENGTH_UDP_PACK_T(X) nBuffer[19]=X;//2
#define UDP_CHEKSUMM_T(X,A,B,C,D,E,F) nBuffer[20]=WritecheskSumUDP(X,A,B,C,D,E,F);//2
#define LENGTH_UDP_TYMESSAGE_0 16u //DLC_reqest_operate_PAY+8
#define LENGTH_UDP_TYMESSAGE_1 21u //DLC_set_IP+8
#define LENGTH_UDP_TYMESSAGE_2 21u //DLC_set_IP_mask+8
#define LENGTH_UDP_TYMESSAGE_3 19u	//DLC_SET_NUMBER_PORT+8
#define LENGTH_UDP_TYMESSAGE_4 23u //DLC_set_MAC+8
#define LENGTH_UDP_TYMESSAGE_5 58u	//DLC_SET_READ_DATA+8
#define LENGTH_UDP_TYMESSAGE_6 58u	//DLC_SET_WRITE_DATA+8
#define LENGTH_UDP_TYMESSAGE_7 63u	//DLC_SET_READ_DATA_SYSTEM+8
//************************************
#define UDP_HEADER_T_SIZE 4
#define PACKET_NEW_MAC_T_SIZE 3
#define PACKET_NEW_UDPPORT_T_SIZE 1
#define PACKET_NEW_IPMASK_T_SIZE 1
#define PACKET_NEW_IP_T_SIZE 1
#define PACKET_NEW_SYSTEM_SETTING_COMMUTATOR_T_SIZE 40
#define PACKET_NEW_SETTING_COMMUTATOR_T_SIZE 41
#define PAY_FORMAT_T_SIZE 6
#define ARP_PACK_T_SIZE 12
#define IP_HEADER_T_SIZE 8 
#define HEADER_HARDWARE_T_SIZE 7
#define HEADER_PACKET_T_SIZE 2
//*************************************
#define UDP_HEADER_T_POINT (uint32_t)udp_header_t
#define PACKET_NEW_MAC_T_POINT (uint32_t)packet_new_mac_t
#define PACKET_NEW_UDPPORT_T_POINT (uint32_t)packet_new_UDPport_t
#define PACKET_NEW_IPMASK_T_POINT (uint32_t)packet_new_ipmask_t
#define PACKET_NEW_IP_T_POINT (uint32_t)packet_new_ip_t
#define PACKET_NEW_SYSTEM_SETTING_COMMUTATOR_T_POINT (uint32_t)packet_new_system_setting_commutator_t
#define PACKET_NEW_SETTING_COMMUTATOR_T_POINT (uint32_t)packet_new_setting_commutator_t 
#define PAY_FORMAT_T_POINT (uint32_t)pay_format_t
#define ARP_PACK_T_POINT (uint32_t)arp_pack_t
#define IP_HEADER_T_POINT (uint32_t)ip_header_t 
#define HEADER_HARDWARE_T_POINT (uint32_t)header_hardware_t
#define HEADER_PACKET_T_POINT (uint32_t)header_packet_t
//*************************************


#define LENGTH_RAZMETKA_TYMESSAGE_0  HEADER_PACKET_T_SIZE+HEADER_HARDWARE_T_SIZE+IP_HEADER_T_SIZE+UDP_HEADER_T_SIZE+PAY_FORMAT_T_SIZE 
#define LENGTH_RAZMETKA_TYMESSAGE_1  HEADER_PACKET_T_SIZE+HEADER_HARDWARE_T_SIZE+IP_HEADER_T_SIZE+UDP_HEADER_T_SIZE+PAY_FORMAT_T_SIZE+PACKET_NEW_IP_T_SIZE
#define LENGTH_RAZMETKA_TYMESSAGE_2  HEADER_PACKET_T_SIZE+HEADER_HARDWARE_T_SIZE+IP_HEADER_T_SIZE+UDP_HEADER_T_SIZE+PAY_FORMAT_T_SIZE+PACKET_NEW_IPMASK_T_SIZE
#define LENGTH_RAZMETKA_TYMESSAGE_3  HEADER_PACKET_T_SIZE+HEADER_HARDWARE_T_SIZE+IP_HEADER_T_SIZE+UDP_HEADER_T_SIZE+PAY_FORMAT_T_SIZE+PACKET_NEW_UDPPORT_T_SIZE
#define LENGTH_RAZMETKA_TYMESSAGE_4  HEADER_PACKET_T_SIZE+HEADER_HARDWARE_T_SIZE+IP_HEADER_T_SIZE+UDP_HEADER_T_SIZE+PAY_FORMAT_T_SIZE+PACKET_NEW_MAC_T_SIZE
#define LENGTH_RAZMETKA_TYMESSAGE_5  HEADER_PACKET_T_SIZE+HEADER_HARDWARE_T_SIZE+IP_HEADER_T_SIZE+UDP_HEADER_T_SIZE+PAY_FORMAT_T_SIZE+PACKET_NEW_SETTING_COMMUTATOR_T_SIZE
#define LENGTH_RAZMETKA_TYMESSAGE_6  HEADER_PACKET_T_SIZE+HEADER_HARDWARE_T_SIZE+IP_HEADER_T_SIZE+UDP_HEADER_T_SIZE+PAY_FORMAT_T_SIZE+PACKET_NEW_SETTING_COMMUTATOR_T_SIZE
#define LENGTH_RAZMETKA_TYMESSAGE_7  HEADER_PACKET_T_SIZE+HEADER_HARDWARE_T_SIZE+IP_HEADER_T_SIZE+UDP_HEADER_T_SIZE+PAY_FORMAT_T_SIZE+PACKET_NEW_SYSTEM_SETTING_COMMUTATOR_T_SIZE
#define LENGTH_RAZMETKA_ARP_ANSWER   HEADER_PACKET_T_SIZE+HEADER_HARDWARE_T_SIZE+ARP_PACK_T_SIZE

//Константы протокола Ethernet 
#define Brodcast_L (uint16_t)(0xFFFF)
#define Brodcast_S (uint16_t)(0xFFFF)
#define Brodcast_M (uint16_t)(0xFFFF)
#define BRODCAST_PORT_COMMUTATOR  (uint16_t)(0x0000)
#define BRODCAST_IP_ADDRES  (uint32_t)(0xFFFFFFFF)
#define TYPE_IP_MASSAGE  (uint16_t)(0x0008)
#define LENGTH_IP_HEADER  (uint16_t)(0x0045)
#define IDENTIFICATOR_IP_PACK_L  (uint16_t)(0x0000)
#define IDENTIFICATOR_IP_PACK_M  (uint16_t)(0x0000)
#define TYPE_UDP_MESG  (uint16_t)(0x1100)
#define TYPE_ICMP_MESG  (uint16_t)(0x0100)
#define TYPE_AND_CODE_ICMP (uint16_t)(0x0008)
#define ICMP_ECHO_REPLAY (uint16_t)(0x0000)
#define Type_ARP_MESG   (uint16_t)(0x0608)
#define Type_ethernet_MESG    (uint16_t)(0x0100)
#define IP4_protocol_MESG   (uint16_t)(0x0008)
#define Length_ARP_MESG   (uint16_t)(0x0406)
#define ANSWER_ARP_MESG   (uint16_t)(0x0100)
#define REQEST_ARP_MESG  (uint16_t)(0x0200)
#define IP_ADDRESS_PAY (uint32_t)(0xC0A80180)
#define LENGTH_ARP_REQEST_PACK (uint32_t)(42) // Длинна 4б + данные 42б + 4б статуса

//Функции 

extern void creat_heder_pack(uint8_t TypeMessage, uint8_t TypeProtocolMessage);
extern void creat_ip_heder(uint8_t TypeMessage);
extern uint16_t WritecheskSumIP(void);
extern void creat_arp_answer(void);
extern void creat_pay_header(uint8_t NumerPack, uint8_t NumerComand);
extern void creat_configure_commutator(void);
extern void creat_system_configure_commutator(void); 
extern void creat_udp_header(uint8_t TypeMessage);
extern uint16_t WritecheskSumUDP(void);
//extern uint16_t WritecheskSumUDP(uint8_t LengthUDP,uint32_t *DataA,uint32_t *DataB, uint32_t *DataC, uint8_t sizeA, uint8_t sizeB, uint8_t sizeC);
extern void creat_Message(uint8_t TypeProtocolMessage,uint8_t TypeMessage, uint8_t NumerComand, uint8_t NomerPack);
extern void summ_razmetka(uint32_t *dATbuff, uint8_t *dSizeof, uint8_t *dData, uint8_t *NewSize, uint8_t *SizeByte, uint8_t NumberMassiv);
extern uint32_t nBuffer[80];

extern void creat_ICMP_message(uint16_t *pdata, uint16_t size_data_icmp);
extern void SetCommunicationPin(void);
extern void SetAtenuation(uint8_t NumerAntenna,uint8_t NumerSwitch,uint8_t TypePlata, uint8_t NumerChannel);
extern void SetSmolPalataKeys(uint8_t NumerAntenna, uint8_t mode, uint8_t TypePlata);
extern void SetEnSwitch(uint8_t NumerAntenna,uint8_t NumerSwitch,uint8_t TypePlata);
extern void SetSwitchCode(uint8_t NumerAntenna, uint8_t NumerSwitch, uint8_t TypePlata);
extern uint16_t WritecheskSumICMP(uint16_t size_icmp); 
//****************


typedef struct 
{
	uint16_t StatusPack; //2
  uint16_t LengthPack; //2*
  uint16_t MacSenderH; //2
  uint16_t MacSenderM; //2*
  uint16_t MacSenderL; //2 
	uint16_t MacSourceH; //2*
  uint16_t MacSourceM; //2
  uint16_t MacSourceL; //2*
	uint16_t TypeProtocol;//2	
}HeaderPackEthernet;


typedef union
{
	uint32_t	 ARPIPSender;
	uint32_t   IPSender;
	uint32_t   IPSource;
	uint16_t   chARPIPSender[2];
	uint8_t    byteIP[4];
}ARPIPsender;

typedef struct
{
	 uint16_t VersiaIP;//2*
	 uint16_t LengthFullPack;//2 
	 uint16_t IndetificatorPack;//2* 
	 uint16_t NumerFragment;//2
	 uint16_t TipeProtocol;//2*  
	 uint16_t IpcheckSumm;//2 
	 ARPIPsender unSourceIp;
	 ARPIPsender unSenderIp;
}IPHeaderPackEthernet;

typedef struct
{
	uint16_t TypeAndCodeICMPMessage;
	uint16_t IcmpCheckSumm;
	uint16_t IcmpIdentificator;
	uint16_t IcmpSequenceNumber;
	uint16_t DataICMPEcho;
}ICMPEchoProtocol;

typedef union
{
   ICMPEchoProtocol stICMPEchoProtocol;
	 uint16_t ICMPdataCheckSumm[20];	
}uICMPEchoProtocol;

typedef struct
{
	uint16_t TypeCarrier;//2*
  uint16_t IPV4Protocol;//2
	uint16_t SizeARPPack;//2*
	uint16_t TipeArpPack;//2
	uint16_t ARPMacHSource;//2*
	uint16_t ARPMacMSource;//2
	uint16_t ARPMacLSource;//2*
	uint32_t ARPIPSource;//4
	uint16_t ARPMacHSender;//2
	uint16_t ARPMacMSender;//2*
	uint16_t ARPMacLSender;//2
	ARPIPsender unARPIPsender;//4
}ARPPackEthernet;

typedef struct
{
	uint16_t StatusPack; //2
  uint16_t LengthPack; //2*
  uint16_t MacSenderH; //2
  uint16_t MacSenderM; //2*
  uint16_t MacSenderL; //2 
	uint16_t MacSourceH; //2*
  uint16_t MacSourceM; //2
  uint16_t MacSourceL; //2*
	uint16_t TypeProtocol;//2	
	uint16_t TypeCarrier;//2*
  uint16_t IPV4Protocol;//2
	uint16_t SizeARPPack;//2*
	uint16_t TipeArpPack;//2
	uint16_t ARPMacHSource;//2*
	uint16_t ARPMacMSource;//2
	uint16_t ARPMacLSource;//2*
	uint32_t ARPIPSource;//4
	uint16_t ARPMacHSender;//2
	uint16_t ARPMacMSender;//2*
	uint16_t ARPMacLSender;//2
	ARPIPsender unARPIPsender;//4
}ARPPackClient;


typedef struct
{
	uint16_t SourceUDPPort;
	uint16_t SenderUDPPort;
	uint16_t LengthUDPPack;
	uint16_t UDPChekSumm;
}UDPHeaderPackEthernet;


typedef struct
{
	 uint16_t IDP_FIELD;
	 uint16_t IDO_FIELD;
	 uint16_t DLC_FIELD;
	 uint8_t  WS_FIELD;
	 uint8_t KOP_FIELD;
	 uint8_t NP_FIELD;
}PAYHeaderPackEthernet;

#define WS_FIELD_SYSTEM 0x30 
#define WS_FIELD_APLICATION 0x31

typedef struct
{
	uint16_t CommMacHSource;
	uint16_t CommMacMSource;
	uint16_t CommMacLSource;	
}MacPack;

typedef struct
{
	uint8_t  ModeWorkCommutator;
	uint8_t  OUT_OR_IN_Numer[16];
	uint8_t	 TransferFactor[8];
	uint16_t TemperaruraPlataN1;
	uint16_t TemperaruraPlataN2;
	uint8_t  FlagState;
	uint8_t  RezervByte[11];
}SettingCommutator;
 
typedef struct
{
		uint8_t  TypeCommutator;
	  uint8_t  FactoryNummer[12];
	  uint8_t  ResetCommutator;
	  uint8_t  GainCorrectMinus[8];
	  uint8_t  GainCorrectNool[8];
	  uint8_t  GainCorrectPlus[8];
	  uint8_t  GainCorrectChennel[8];
	  uint32_t IpAddressPay;
}SettingSystemCommutator;



//extern uint16_t	PackIGMP[10]={0x9404 0x0000 0x0022 0x01f9 0x0000 0x0100 0x0004 0x0000 0x00e0 0xfc00};


typedef union
{
	IPHeaderPackEthernet stIPHeaderPackEthernet;
	uint16_t IPChekSumm[sizeof(IPHeaderPackEthernet)/2]; 	
}IPHead;

typedef union
{
		MacPack stMacPack;
		SettingCommutator stSettingCommutator;
		SettingCommutator stTempratureCommutator;
		SettingSystemCommutator stSettingSystemCommutator;
    uint32_t NewIp;
    uint32_t NewMaskIp;	
		uint16_t NewUDPPort;
}UdpData;

typedef union
{
	struct
	{
		PAYHeaderPackEthernet stPAYHeaderPackEthernet;
		UdpData unUdpData; 
	}data;
	 uint16_t shUdpData[sizeof(UdpData)/2+1];
}DataUDPCreat;


typedef struct
{
	UDPHeaderPackEthernet stUDPHeaderPackEthernet;
	PAYHeaderPackEthernet stPAYHeaderPackEthernet;
	UdpData unUdpData;
}UdpPack;

typedef union
{
  UdpPack stUdpPack;
	uint16_t UDPChekSumm[(sizeof(UdpPack)/2)+1]; 	
}UDPEthernet;

typedef struct
{
	IPHead unIPHead;
	union
  {		
			UDPEthernet unUDPEthernet;
			uICMPEchoProtocol stICMPEchoProtocol;
		  uint16_t mDataIGMP_4[10];  
  };		
}IPPackEthernet;

typedef union
{
	 IPPackEthernet stIPPackEthernet;
   ARPPackEthernet stARPPackEthernet;
}IPdata;

typedef struct
{
	HeaderPackEthernet stHeaderPackEthernet;
	IPdata unIPdata; 
}PackEthernet;

extern uint16_t xtBuffer[1500];
	
extern PackEthernet *pPackEthernet;

typedef union
{
	uint8_t ByteData[4];
	uint32_t Ipaddress;
	uint16_t UdpPort;
}rotIpaddres;

typedef union
{
	 uint8_t ByteData[8];
	 uint16_t WordData[4];
	 uint32_t DWordData[2];
	 uint64_t QWordData;
}rotTypeData;







extern rotIpaddres nrotIpaddres,nrotIpaddres1;
extern rotTypeData nrotTypeData,nrotTypeData1;


#define MAX_SIZE_PACK  sizeof(UdpData)+12u+14u+20u+8u+9u
#define BASE_SIZE_PACK ((sizeof(HeaderPackEthernet)-4)+sizeof(IPHeaderPackEthernet)+sizeof(UDPHeaderPackEthernet)+sizeof(PAYHeaderPackEthernet))
#define BASE_SIZE_IP (sizeof(IPHeaderPackEthernet)+sizeof(UDPHeaderPackEthernet)+sizeof(PAYHeaderPackEthernet))
#define BASE_SIZE_PAY sizeof(PAYHeaderPackEthernet)
#define BASE_SIZE_UDP (sizeof(UDPHeaderPackEthernet)+sizeof(PAYHeaderPackEthernet)) 	


#endif // DATA_PACKET_H

