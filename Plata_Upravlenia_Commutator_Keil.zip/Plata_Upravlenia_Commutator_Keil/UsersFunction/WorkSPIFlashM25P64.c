﻿#include "opora.h"
#include "FullUserHeader.h"

uint32_t addres_spi_memory=0;
	
void WREN_Operation()
{
    uint8_t commanda=0x06;
    wrate_byte_spi(&commanda, 1, 1,2,0);
    Read_status(0x02);
}

void write_data_flash(uint8_t *buffer, uint32_t number_byte, uint32_t addres_write)
{
   uint8_t commanda[4]={0xD8,0x00,0x00,0x00};
   commanda[1]=(uint8_t)((addres_write&0x00FF0000)>>16);
   commanda[2]=(uint8_t)((addres_write&0x0000FF00)>>8);
   commanda[3]=(uint8_t)((addres_write&0x000000FF)>>0);
   WREN_Operation();
   wrate_byte_spi(&commanda[0], 4, 1,2,0);
   Read_status(0x00);
   commanda[0]=0x02;
   WREN_Operation();
   wrate_byte_spi(&commanda[0], 4,0,2,0);
   wrate_byte_spi(buffer, number_byte, 1,2,0);
   Read_status(0x00);
   return;
}

void clean_sector(uint32_t addres_write) 
{
	 uint8_t commanda[4]={0xD8,0x00,0x00,0x00};
   commanda[1]=(uint8_t)((addres_write&0x00FF0000)>>16);
   commanda[2]=(uint8_t)((addres_write&0x0000FF00)>>8);
   commanda[3]=(uint8_t)((addres_write&0x000000FF)>>0);	
	 WREN_Operation();
	 wrate_byte_spi(commanda, 4, 1,2,0);
	 Read_status(0x00);
}

void clean_all_sectores(void)//добавлено 02.12.2019
{
	uint32_t i=0;
	uint32_t addres_write=0;
	for(i=0;i<128;i++)
	{
		addres_write=i<<16;
		clean_sector(addres_write);
	}
}

void read_data_flash(uint8_t *buffer, uint32_t number_byte, uint32_t addres_read)
{
  uint8_t commanda[4]={0x03,0x00,0x00,0x00};
  commanda[1]=(uint8_t)((addres_read&0x00FF0000)>>16);
  commanda[2]=(uint8_t)((addres_read&0x0000FF00)>>8);
  commanda[3]=(uint8_t)((addres_read&0x000000FF)>>0);
  WREN_Operation();
  wrate_byte_spi(commanda, 4, 0, 2,0);
  read_byte_spi(buffer, number_byte, 1,2);
}

uint32_t Test_connect_Flash()
{
	 uint8_t i=0;
   uint8_t commanda=0x9f;
   uint8_t idetificator[3];
	 idetificator[0]=0;
	 idetificator[1]=0;
	 idetificator[2]=0;
	 while(i<10)
	 {
		 wrate_byte_spi(&commanda,1,0,2,0);
     read_byte_spi(idetificator,3,1,2);
		 if((idetificator[0]==0x20)&&(idetificator[1]==0x20)&&(idetificator[2]==0x17))
     {
        return 0;
     }
		 i++;
	 }		 
   return 1;  
}



void Read_status(uint8_t falag_ok)
{
   uint8_t commanda=0x05;
   uint8_t buffer;
   wrate_byte_spi(&commanda, 1, 0,2,0);
   read_byte_spi(&buffer,1,0,2);
   while(falag_ok!=buffer)
   {
     read_byte_spi(&buffer,1,0,2);
   }
   read_byte_spi(&buffer,0,1,2);
   return;
}

void ReadDataFlashToStruct() // функция чтение данных из SPIFLASH
{
    uint32_t summ=0;
    uint32_t summ_rd=1;
    uint16_t i=0;
	  uint16_t k=0;
    while((summ!=summ_rd)&(i!=32768))//пока несойдутся контрольные суммы или не конец spiflash 
    {
        read_data_flash(Operation_Data.chsOperation_Data,sizeof(stOperation_Data),addres_spi_memory+(i*256));
			  if(operation_data->FlagInit!=0xDEEDBEEF)
				{
					 NewInitSettingCommutator(0);
					 SaveDataStructToFlash();
					 i=1;  
					 break;
				}
  			for(k=0;k<(sizeof(stOperation_Data)-2);k++)
        {
           summ=summ+Operation_Data.chsOperation_Data[k];
					 summ=summ+((summ&0x10000)>>16);
					 summ&=0xFFFF;
        }
        summ_rd=operation_data->usnCheksumm;			
        i++;
    }
		if(i==32768) //не найдена запись данных
		{
			 NewInitSettingCommutator(0); 
			 if(operation_data->uchTypeComm==1)
			 {
				  operation_data->uchStatusFlags|=8;//ошибка чтения/записи данных из памяти  платы
			 }
			 else
			 {
				  operation_data->uchStatusFlags|=16;//ошибка чтения/записи данных из памяти  платы
			 }
			 // SaveDataStructToFlash();//Изменения 02.12.2019
		}
		else
		{
					if((((operation_data->uchStatusFlags)&0x08)==0x08))
					{
						operation_data->uchStatusFlags&=0xF7;
						//SaveDataStructToFlash();//Изменения 02.12.2019
					}
					if((((operation_data->uchStatusFlags)&0x10)==0x10))	
					{
						operation_data->uchStatusFlags&=0xEF;
						//SaveDataStructToFlash();//Изменения 02.12.2019
					}					
			    addres_spi_memory=addres_spi_memory+((i-1)*256);
		}
}

void SaveDataStructToFlash() //функция записи данных в SPIFLASH
{
    uint32_t summ,addr;
		uint32_t summ_rd;
    uint16_t i=0;
	  unsOperation_Data data;
	  summ=0;
		for(i=0;i<(sizeof(stOperation_Data)-2);i++)
		{
       summ=summ+Operation_Data.chsOperation_Data[i];
			 summ=summ+((summ&0x10000)>>16);
			 summ&=0xFFFF;
		}
		summ_rd=summ+1;
		i=0;
		addr=addres_spi_memory;
		while((summ!=summ_rd)&(i!=(32768-(addr/256))))
    {
			operation_data->usnCheksumm=(uint16_t)(summ);
			write_data_flash(Operation_Data.chsOperation_Data,sizeof(stOperation_Data),addres_spi_memory+(i*256));
			read_data_flash(data.chsOperation_Data,sizeof(stOperation_Data),addres_spi_memory+(i*256));
			summ_rd=data.sOperation_Data.usnCheksumm;
			i++;
			addr=addr+((i-1)*256);
		}
		if(i==(32768-(addr/256)))
		{
			 if(operation_data->uchTypeComm==1)
			 {
				  operation_data->uchStatusFlags|=8;//ошибка чтения/записи данных из памяти  платы
			 }
			 else
			 {
				  operation_data->uchStatusFlags|=16;//ошибка чтения/записи данных из памяти  платы
			 }
		}		
}



