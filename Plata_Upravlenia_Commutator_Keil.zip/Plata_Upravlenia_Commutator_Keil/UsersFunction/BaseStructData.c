#include "FullUserHeader.h"







/*void Paste_stuct(void *a, unsigned char size_a,  void *b,  unsigned char size_b,  void *c, unsigned char size_c)
{
    unsigned char i;
    unsigned char *buff;
    unsigned char *pa;
    unsigned char *pb;
    unsigned char *pc;
    pa=a;
    pb=b;
    pc=c;
    buff=(unsigned char*)malloc(size_a+size_b+size_c);
    for(i=0;i<size_a;i++)
    {
       *(buff+i)=*(pa+i);
    }
    free(pa);
    for(i=size_a;i<(size_a+size_b);i++)
    {
       *(buff+i)=*(pb+i);
    }
    free(pb);
    for(i=(size_a+size_b);i<(size_a+size_b+size_c);i++)
    {
       *(buff+i)=*(pc+i);
    }
    free(pc);

}



void Init_Struct()
{
    unsigned char *buffer;
    short summ=0;
    short summ_rd=1;
    unsigned i;
    buffer=&operation_data.uchWork;
    heder_pack_ip_udp_reqest.Idetificator_pack[0]=(unsigned short)(IDENTIFICATOR_IP_PACK_L);
    heder_pack_ip_udp_reqest.Idetificator_pack[1]=(unsigned short)(IDENTIFICATOR_IP_PACK_M);
    heder_pack_ip_udp_reqest.Type_IP=(unsigned short)(TYPE_IP_MASSAGE);
    heder_pack_ip_udp_reqest.Type_UDP=(unsigned short)(TYPE_UDP_MESG);
    heder_pack_ip_udp_reqest.Length_IP=(unsigned short)(LENGTH_IP_HEADER);
    mesage_ANSWER_PAY_Commutator.ANSWER_ARP=(unsigned short)(REQEST_ARP_MESG);
    mesage_ANSWER_PAY_Commutator.Length_ARP=(unsigned short)(Length_ARP_MESG);
    mesage_ANSWER_PAY_Commutator.Type_ARP=(unsigned short)(Type_ARP_MESG);
    mesage_ANSWER_PAY_Commutator.Type_ethernet=(unsigned short)(Type_ethernet_MESG);
    while(summ!=summ_rd)
    {
        read_data_flash(buffer,SIZE_MEMORY_FLASH_DATA,addres_spi_memory);
        for(i=0;i<SIZE_MEMORY_FLASH_DATA-2;i++)
        {
           summ=summ+(short)buffer[i];
        }
        summ_rd=(short)(buffer[SIZE_MEMORY_FLASH_DATA-1]<<8)+(short)(buffer[SIZE_MEMORY_FLASH_DATA-2]);
        addres_spi_memory=addres_spi_memory+256;
    }
}


void TestSummDataFlash(unsigned char* a)
{
    unsigned char *buffer;
    short summ=0;
    short summ_rd=1;
    unsigned i;
    unsigned char xt[SIZE_MEMORY_FLASH_DATA],xt1[SIZE_MEMORY_FLASH_DATA];
    buffer=(unsigned char*)malloc(SIZE_MEMORY_FLASH_DATA);
    while(summ!=summ_rd)
    {
       write_data_flash(a,SIZE_MEMORY_FLASH_DATA, addres_spi_memory);
       read_data_flash(buffer,SIZE_MEMORY_FLASH_DATA,addres_spi_memory);
       for(i=0;i<SIZE_MEMORY_FLASH_DATA-2;i++)
       {
                summ=summ+(short)buffer[i];
       }
       summ_rd=(short)(buffer[SIZE_MEMORY_FLASH_DATA-1]<<8)+(short)(buffer[SIZE_MEMORY_FLASH_DATA-2]);
       addres_spi_memory=addres_spi_memory+256;
    }
}


void Save_Struct()
{
    unsigned char *buffer, xt[SIZE_MEMORY_FLASH_DATA];
    short summ=0;
    unsigned i;
    unsigned addres_spi_memory_offset;
    buffer=&operation_data.uchWork;
    for(i=0;i<SIZE_MEMORY_FLASH_DATA-2;i++)
    {
       summ=summ+(short)buffer[i];
    }
    operation_data.ControlSumm=summ;
    addres_spi_memory_offset=addres_spi_memory;
    TestSummDataFlash(buffer);
    write_data_flash(buffer,SIZE_MEMORY_FLASH_DATA, addres_spi_memory_offset-256);
}
 */

// read_type ������������ ���� ��

/*void fSendDataAplicateCommPAY(unsigned char read_type)
{
    unsigned i;
    for(i=0;i<3;i++)
    {
        heder_pack_ip_udp_reqest.MAC_PAY[i]=operation_data.musnMacPay[i];
        heder_pack_ip_udp_reqest.MAC_COMUTATOR[i]=operation_data.musnMacComm[i];
    }
    heder_pack_ip_udp_reqest.IP_Pay=operation_data.nIpPAY;
    heder_pack_ip_udp_reqest.IP_comutator=operation_data.nIpComm;
    heder_pack_ip_udp_reqest.Number_port_PAY=operation_data.usnNumberPortPAY;
    heder_pack_ip_udp_reqest.Number_port_commutator=operation_data.usnNumberPortComm;
    heder_pack_data_UDP.IDP=(unsigned short)(IDP_IDO_PAY);
    switch (operation_data.uchTypeComm)
    {
    case 0:
        heder_pack_data_UDP.IDO=(unsigned short)(IDP_IDO_CM16_4);
        break;
    case 1:
        heder_pack_data_UDP.IDO=(unsigned short)(IDP_IDO_CM16_4);
        break;
    case 2:
        heder_pack_data_UDP.IDO=(unsigned short)(IDP_IDO_DM4_16);
        break;
    case 3:
        heder_pack_data_UDP.IDO=(unsigned short)(IDP_IDO_CMDM8_4);
        break;
    }
    if((read_type==3)||(read_type==4)||(read_type==5)||(read_type==6))
    {
        heder_pack_data_UDP.VC=(unsigned char)(VC_SYSTEM_INFO);
    }
    else
    {
        heder_pack_data_UDP.VC=(unsigned char)(VC_APLICATE_DATA);
    }
    heder_pack_data_UDP.KOP=(unsigned char)(KOP_REQEST_PAY_OPERATE);
    switch (read_type) {
    case 0:
        heder_pack_data_UDP.NP=(unsigned char)(NP_CONFIGURE_COMMUTATOR_pack);
        break;
    case 1:
        heder_pack_data_UDP.NP=(unsigned char)(NP_READ_TEMPERATURE_pack);
        break;
    case 2:
        heder_pack_data_UDP.NP=(unsigned char)(NP_CONFIGURE_SYSTEM_COMMUTATOR_pack);
        break;
    case 3:
        heder_pack_data_UDP.NP=(unsigned char)(NP_IP_pack);
        break;
    case 4:
        heder_pack_data_UDP.NP=(unsigned char)(NP_IPMASK_pack);
        break;
    case 5:
        heder_pack_data_UDP.NP=(unsigned char)(NP_NUMBER_PORT_pack);
        break;
    case 6:
        heder_pack_data_UDP.NP=(unsigned char)(NP_MAC_pack);
        break;
    default:
        break;
    }
    if((read_type==5)||(read_type==6))
    {
        heder_pack_data_UDP.DLC=(unsigned short)(DLC_SET_READ_DATA);
        aplate_pack_data_UDP.work=operation_data.uchWork;
        for(i=0;i<16;i++)
        {
            aplate_pack_data_UDP.switch_comm[i]=operation_data.muchSwitchComm[i];
            if(i<8)
            {
                aplate_pack_data_UDP.gain_manager[i]=operation_data.muchGainManger[i];
            }
            if(i<11)
            {
                 aplate_pack_data_UDP.rezerv_byte[i]=operation_data.muchRezervByte[i];
            }
        }
        aplate_pack_data_UDP.temperatura_plata_1=operation_data.usnTemperatureN1;
        aplate_pack_data_UDP.temperatura_plata_1=operation_data.usnTemperatureN2;
        aplate_pack_data_UDP.flags_status=operation_data.uchStatusFlags;

        heder_pack_ip_udp_reqest.Length_mesage=(unsigned char)(size_byte_heder_pack_data_UDP)+
        (unsigned char)(size_byte_aplate_pack_data_UDP)+(unsigned char)(size_byte_heder_pack_ip_udp_reqest)-14;

        heder_pack_ip_udp_reqest.Length_UDP=(unsigned char)(size_byte_heder_pack_data_UDP)+(unsigned char)(size_byte_aplate_pack_data_UDP)+8;

        Paste_stuct(&heder_pack_ip_udp_reqest,(unsigned char)(size_byte_heder_pack_ip_udp_reqest),&heder_pack_data_UDP,
        (unsigned char)(size_byte_heder_pack_data_UDP),&aplate_pack_data_UDP, (unsigned char)(size_byte_aplate_pack_data_UDP));
    }
    if(read_type==7)
    {
        heder_pack_data_UDP.DLC=(unsigned short)(DLC_SET_READ_DATA_SYSTEM);
        aplate_system_pack_data_UDP.Type_commutator=operation_data.uchTypeComm;
        aplate_system_pack_data_UDP.reset_setting=operation_data.uchResetSetting;
        for(i=0;i<12;i++)
        {
           aplate_system_pack_data_UDP.Factory_numer[i]=operation_data.muchFactoryNumer[i];
           if(i<8)
           {
              aplate_system_pack_data_UDP.gain_correct_minus[i]=operation_data.muchGainCorrectMinus[i];
              aplate_system_pack_data_UDP.gain_correct_normal[i]=operation_data.muchGainCorrectNormal[i];
              aplate_system_pack_data_UDP.gain_correct_plus[i]=operation_data.muchGainCorrectPlus[i];
           }
        }
        heder_pack_ip_udp_reqest.Length_mesage=(unsigned char)(size_byte_heder_pack_ip_udp_reqest)+(unsigned char)(size_byte_heder_pack_data_UDP)
        +(unsigned char)(size_byte_aplate_system_pack_data_UDP)-14;
        heder_pack_ip_udp_reqest.Length_UDP=(unsigned char)(size_byte_heder_pack_data_UDP)+(unsigned char)(size_byte_aplate_system_pack_data_UDP)+8;
        Paste_stuct(&heder_pack_ip_udp_reqest,(unsigned char)(size_byte_heder_pack_ip_udp_reqest),&heder_pack_data_UDP,
        (unsigned char)(size_byte_heder_pack_data_UDP),&aplate_system_pack_data_UDP,(unsigned char)(size_byte_aplate_system_pack_data_UDP));
    }
    if(read_type==1)
    {
        heder_pack_data_UDP.DLC=(unsigned short)(DLC_set_IP);
        system_pack_ip_UDP.IP_commutator=operation_data.nIpComm;

        heder_pack_ip_udp_reqest.Length_mesage=(unsigned char)(size_byte_heder_pack_ip_udp_reqest)+(unsigned char)(size_byte_heder_pack_data_UDP)+(unsigned char)(size_byte_system_pack_ip_UDP)-14;
        heder_pack_ip_udp_reqest.Length_UDP=(unsigned char)(size_byte_heder_pack_data_UDP)+(unsigned char)(size_byte_system_pack_ip_UDP)+8;
        Paste_stuct(&heder_pack_ip_udp_reqest,(unsigned char)(size_byte_heder_pack_ip_udp_reqest),&heder_pack_data_UDP,
        (unsigned char)(size_byte_heder_pack_data_UDP),&system_pack_ip_UDP, (unsigned char)(size_byte_system_pack_ip_UDP));
    }
    if(read_type==2)
    {
        heder_pack_data_UDP.DLC=(unsigned short)(DLC_set_IP_mask);
        system_pack_Maska_UDP.Maska_commutator=operation_data.nIpMaskComm;
        heder_pack_ip_udp_reqest.Length_mesage=(unsigned char)(size_byte_heder_pack_ip_udp_reqest)+(unsigned char)(size_byte_heder_pack_data_UDP)+(unsigned char)(size_byte_system_pack_Maska_UDP)-14;
        heder_pack_ip_udp_reqest.Length_UDP=(unsigned char)(size_byte_heder_pack_data_UDP)+(unsigned char)(size_byte_system_pack_Maska_UDP)+8;
        Paste_stuct(&heder_pack_ip_udp_reqest,(unsigned char)(size_byte_heder_pack_ip_udp_reqest),&heder_pack_data_UDP,
        (unsigned char)(size_byte_heder_pack_data_UDP),&system_pack_Maska_UDP, (unsigned char)(size_byte_system_pack_Maska_UDP));
    }
    if(read_type==3)
    {
        heder_pack_data_UDP.DLC=(unsigned short)(DLC_SET_NUMBER_PORT);
        system_pack_numer_port_UDP.Numer_port_commutator=operation_data.usnNumberPortComm;
        heder_pack_ip_udp_reqest.Length_mesage=(unsigned char)(size_byte_heder_pack_ip_udp_reqest)+(unsigned char)(size_byte_heder_pack_data_UDP)+(unsigned char)(size_byte_system_pack_numer_port_UDP)-14;
        heder_pack_ip_udp_reqest.Length_UDP=(unsigned char)(size_byte_heder_pack_data_UDP)+(unsigned char)(size_byte_system_pack_numer_port_UDP)+8;
        Paste_stuct(&heder_pack_ip_udp_reqest,(unsigned char)(size_byte_heder_pack_ip_udp_reqest),&heder_pack_data_UDP,
        (unsigned char)(size_byte_heder_pack_data_UDP),&system_pack_numer_port_UDP, (unsigned char)(size_byte_system_pack_numer_port_UDP));
    }
    if(read_type==4)
    {
       heder_pack_data_UDP.DLC=(unsigned short)(DLC_set_MAC);
       system_pack_MAC_UDP.MAC_commutator[0]=operation_data.musnMacComm[0];
       system_pack_MAC_UDP.MAC_commutator[1]=operation_data.musnMacComm[1];
       system_pack_MAC_UDP.MAC_commutator[2]=operation_data.musnMacComm[2];
       heder_pack_ip_udp_reqest.Length_mesage=(unsigned char)(size_byte_heder_pack_ip_udp_reqest)+(unsigned char)(size_byte_heder_pack_data_UDP)+(unsigned char)(size_byte_system_pack_MAC_UDP)-14;
       heder_pack_ip_udp_reqest.Length_UDP=(unsigned char)(size_byte_heder_pack_data_UDP)+(unsigned char)(size_byte_system_pack_MAC_UDP)+8;
       Paste_stuct(&heder_pack_ip_udp_reqest,(unsigned char)(size_byte_heder_pack_ip_udp_reqest),&heder_pack_data_UDP,
       (unsigned char)(size_byte_heder_pack_data_UDP),&system_pack_MAC_UDP,(unsigned char)(size_byte_system_pack_MAC_UDP));
    }

}

*/









/* unsigned nSummChek=0;
 unsigned short nElement=0;
 unsigned short nPerenos=0;

int cControlSumIP(FILE *pStream)  // ������ ����������� �����
{
    unsigned i;
    for(i=0;i<10;i++)
    {
         if(i == 5)
         {
            fscanf(pStream,"%2s", &nElement);
         }
         else
         {
            fscanf(pStream,"%2s", &nElement);
            nSummChek=(unsigned)(nElement)+nSummChek;
         }
    }
       nPerenos=(nSummChek>>16);
       nSummChek=((unsigned short)(~(nSummChek&0xFFFF)))-nPerenos;
   return 0;
}




unsigned short RdMessage=0;
unsigned tail;
*/



void InterprtataPack(uint8_t mode)
{
 /* uint16_t i;
  uint32_t xt;
   if(mode==1)
   {	 
      if(Type_Message_Reciver==TYPE_IP_MASSAGE)// ip �����
      {
          ;//cControlSumIP(pStream);
      }
      else
      {
          if(TYPE_ARP_MESSAGE==Type_ARP_MESG) // ��� �����
          {
              if(DIRECT_ARP_MASSAGE==ANSWER_ARP_MESG) // ��� ������
              {
										if(IP_PAY==IP_ADDRESS_PAY)
										{
												operation_data->musnMacPay[0]=MAC_PAY_SENDER_HEAD_WORLD;
											  operation_data->musnMacPay[1]=MAC_PAY_SENDER_MIDDLE_WORLD;
											  operation_data->musnMacPay[2]=MAC_PAY_SENDER_LOVER_WORLD;
												operation_data->nIpPAY=IP_PAY;								
												//-----------------------------------------------------------------------								
											  LENGTH_SEND_MESAGE(42)
												MAC_SENDER_HEAD_WORD(operation_data->musnMacPay[0])
												MAC_SENDER_MIDDLE_WORD(operation_data->musnMacPay[1])
												MAC_SENDER_LOVER_WORD(operation_data->musnMacPay[2])
												MAC_SOURCE_HEAD_WORD(operation_data->musnMacComm[0])
											  MAC_SOURCE_MIDDLE_WORD(operation_data->musnMacComm[1])
												MAC_SOURCE_LOVER_WORD(operation_data->musnMacComm[2])
												TYPE_ARP_MESSAGE_SENDER
												TYPE_ETHERNET_MESSAGE_SENDER
												LENGTH_ARP_MESSAGE_SENDER
												TYPE_ETHERNET_IP4_MESGAGE_SENDER
												ARP_ANSWER_MESSAGE_SENDER
											  MAC_SOURCE_HEAD_WORD_1(operation_data->musnMacComm[0])
												MAC_SOURCE_MIDDLE_WORD_1(operation_data->musnMacComm[1])
												MAC_SOURCE_LOVER_WORD_1(operation_data->musnMacComm[2])
												IP_SOURCE_ARP_SENDER(operation_data->nIpComm)
												MAC_SENDER_HEAD_WORD_1(operation_data->musnMacPay[0])
												MAC_SENDER_MIDDLE_WORD_1(operation_data->musnMacPay[1])
												MAC_SENDER_LOVER_WORD_1(operation_data->musnMacPay[2])	
												IP_SENDER_ARP_SENDER(operation_data->nIpPAY) 
														
												//SendPacket(LENGTH_ARP_REQEST_PACK);
										}																
              }
          }
       }
		}*/
		;
}
 /** ������� ���������� ������� �� ���������
	 * @param chBuffer - ������ ������, ������� ����� ������ �� ����������  
   * @return 
*/
 /*void WriteMessageInBuffer(uint8_t *chBuffer)
 {
	 uint32_t	i,k,n;	
	 uint32_t *pMessage,Fract,Integer;
	 pMessage=Buffer_Transmit;
	 k=0;
	 Fract=size_byte_mesage_ANSWER_PAY_Commutator-(((size_byte_mesage_ANSWER_PAY_Commutator)>>2)<<2);
	 Integer=(size_byte_mesage_ANSWER_PAY_Commutator)>>2; 
	 for(i=0;i<Integer;i++)
	 {
		 pMessage[i]=(chBuffer[i+k+3]<<8u)|(chBuffer[i+k+2])|(chBuffer[i+k+1]<<24u)|(chBuffer[i+k+0]<<16u);
		 k=k+3;
	 }
	 for(n=0;n<Fract;n++)
	 {
		  pMessage[i]|=(chBuffer[(i+k)+n]<<(24u-n*8u));
	 } 
 }*/
 
 /** ������� ���������� ��������� �� ��������� ���������
	 * @param chBuffer - ������ ������, ������� ����� ������ �� ����������  
   * @return 
*/
void ReadMessageInStruct(uint8_t *chBuffer)
 {
	/* uint32_t	i,k,dWvariable;
	 uint32_t *pMessage;
	 pMessage=Buffer_Reciver;
	 k=0;
	 for(i=0;i<length_Reciver_Message;i++)
	 {
			 dWvariable|=(InvertDBwort(pMessage[i]&0xFFFF, 8u, 16u)<<16u);
		   dWvariable|=InvertDBwort(((pMessage[i]&0xFFFF0000)>>16), 8u, 16u);
		   chBuffer[i+k+1]=(uint8_t)((pMessage[i]&0xFF000000)>>24u);
		   chBuffer[i+k]=(uint8_t)((pMessage[i]&0xFF0000)>>16u);
		   chBuffer[i+k+3]=(uint8_t)((pMessage[i]&0xFF00)>>8u);
		   chBuffer[i+k+2]=(uint8_t)(pMessage[i]&0xFF);
			 k=k+3;
		 }	 */
	 ;
}	 


