﻿#ifndef TEST_MESSAGE 
#define TEST_MESSAGE
#include <stdio.h>
#include <stdint.h>
#define struct __packed struct
	
extern void send_testmessage(uint32_t *dataBuffer,uint32_t size_message_byte);
extern uint32_t* read_testmessage(uint32_t size_message_byte);
extern void pack_interpritator(uint8_t mode);
extern uint8_t UniversalBufferDataRD(void);
extern void UniversalBufferDataWR(uint32_t *pnAddress, uint8_t *pchTypeData, uint8_t nNumberVariable, uint8_t SyzePack);
extern uint32_t CyrcleShift(uint32_t data, uint8_t size_data,uint8_t shift);
extern void ARP_replay_client(void);
extern void IGMP_replay_client(void);


	 
/*#define R_MAC_SENDER_HEAD_WORD  	 
#define R_MAC_SENDER_MIDDLE_WORD	 	 
#define R_MAC_SENDER_LOWER_WORD  

#define R_MAC_SOURCE_HEAD_WORD 	 
#define R_MAC_SOURCE_MIDDLE_WORD  
#define R_MAC_SOURCE_LOWER_WORD 

// Принятый ARP пакет	 
#define R_ARP_TYPE_SETI *((uint16_t*)(databuff+14u))
#define R_ARP_TYPE_PROTOCOL *((uint16_t*)(databuff+12u))
#define R_ARP_lENGTH_PACK *((uint16_t*)(databuff+18u))
#define R_ARP_OPERATION *((uint16_t*)(databuff+16u))
#define R_ARP_SENDER_HEAD_WORD *((uint16_t*)(databuff+22u))
#define	R_ARP_SENDER_MIDDLE_WORD *((uint16_t*)(databuff+20u))
#define R_ARP_SENDER_LOWER_WORD *((uint16_t*)(databuff+26u))*/
	 	 
#endif //TEST_MESSAGE


	 