#ifndef BASE_STRUCT_DATA_H
#define BASE_STRUCT_DATA_H

#include <stdio.h>
#include <stdint.h>
#include "opora.h"
#define struct __packed struct

     

#endif /*_BASE_STRUCT_DATA*/
