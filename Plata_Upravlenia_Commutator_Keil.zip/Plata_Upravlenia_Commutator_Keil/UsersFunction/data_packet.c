#include "FullUserHeader.h"
#include <stdint.h>

uint32_t nBuffer[80];


/* ������� ���������� IP ���������*/
void creat_ip_heder(uint8_t TypeMessage)
{
	ARPIPsender snARPIPsender;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.VersiaIP)))=0x0045;
	switch(TypeMessage)
	{
			case 11:
					 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP+4)<<8);	
				   break;
			case 12:
					 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP+4)<<8);		
				   break;
			case 13:
					 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP+2)<<8);	
				   break;
			case 14:
					 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP+6)<<8);	
				   break;
			case 15:
					 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP+sizeof(SettingCommutator))<<8);	
				   break;
			case 16:
					 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP+sizeof(SettingCommutator))<<8);			
				   break;
			case 17:
					  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP+sizeof(SettingSystemCommutator))<<8);		
           break;				
			case 1:
					 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP)<<8);	
					 break;
			case 2:
					  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP)<<8);	
					 break;
			case 3:
					  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP)<<8);		
					 break;
			case 4:
					  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP)<<8);			 
					 break;
			case 5:
					  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP)<<8);			
					 break;
			case 6:
					  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP)<<8);			
					 break;
			case 7:
					 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP)<<8);		
					 break;	
			case 0xFE:
				   *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP)<<8);		
					 break;	
			case 0xFF:
					 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=((BASE_SIZE_IP)<<8);			
					 break;	
	}
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.IndetificatorPack)))=0x0000;
 	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.NumerFragment)))=0x0000;
  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.TipeProtocol)))=0x1180;
	if(TypeMessage==91)
	{	
		 snARPIPsender.IPSender=((operation_data->nIpMaskPAY)&(operation_data->nIpComm))|((~(operation_data->nIpMaskPAY)));
	}
	else
	{
		snARPIPsender.IPSender=operation_data->nIpPAY;
	}
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSenderIp.chARPIPSender[0])))=snARPIPsender.chARPIPSender[0];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSenderIp.chARPIPSender[1])))=snARPIPsender.chARPIPSender[1];
	snARPIPsender.IPSource=operation_data->nIpComm;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSourceIp.chARPIPSender[0])))=snARPIPsender.chARPIPSender[0];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSourceIp.chARPIPSender[1])))=snARPIPsender.chARPIPSender[1];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.IpcheckSumm)))=WritecheskSumIP();
}

/* ������� ���������� IP+ICMP ������*/
void creat_ICMP_message(uint16_t *pdata, uint16_t size_data_icmp)
{
	uint16_t i;
	ARPIPsender snARPIPsender;	
	*((uint16_t*)(&(pPackEthernet->stHeaderPackEthernet.TypeProtocol)))=0x0008;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.LengthFullPack)))=0x3c00;		
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.VersiaIP)))=0x0045;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.IndetificatorPack)))=0x0000;
 	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.NumerFragment)))=0x0000;
  *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.TipeProtocol)))=0x0180;
	snARPIPsender.IPSender=operation_data->nIpPAY;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSenderIp.chARPIPSender[0])))=snARPIPsender.chARPIPSender[0];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSenderIp.chARPIPSender[1])))=snARPIPsender.chARPIPSender[1];
	snARPIPsender.IPSource=operation_data->nIpComm;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSourceIp.chARPIPSender[0])))=snARPIPsender.chARPIPSender[0];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.unSourceIp.chARPIPSender[1])))=snARPIPsender.chARPIPSender[1];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.stIPHeaderPackEthernet.IpcheckSumm)))=WritecheskSumIP();
	//---------
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.TypeAndCodeICMPMessage)))=ICMP_ECHO_REPLAY;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.IcmpIdentificator)))=pdata[size_data_icmp];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.IcmpSequenceNumber)))=pdata[size_data_icmp+1];
	for(i=0;i<size_data_icmp;i++)
	{
		*((uint16_t*)((&(pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.DataICMPEcho))+i))=pdata[i];
	}
	*((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.IcmpCheckSumm)))=WritecheskSumICMP(size_data_icmp+4u);
};


/**
 * ������� �������� ����������� ����� IP ��������� 
 * @param 
 * @return ������������ ����������� ����� IP ��������� 
 */
uint16_t WritecheskSumIP() 
{
    uint32_t i;
    uint32_t nSumm=0;
    for(i=0;i<10;i++)
    {
         if(i == 5) continue;
         else
         {
						nSumm=nSumm+pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.IPChekSumm[i];	
					  nSumm=nSumm+((nSumm&0x10000)>>16);
						nSumm&=0xFFFF;
         }
    }
    return (uint16_t)(~nSumm);   
}

/* ������� �������� ����������� ����� ICMP */
uint16_t WritecheskSumICMP(uint16_t size_icmp) 
{
		uint32_t i;
    uint32_t nSumm=0;
    for(i=0;i<size_icmp;i++)
    {
         if(i == 1) continue;
         else
         {	 
						//xt=*((uint16_t*)((&(pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.TypeAndCodeICMPMessage))+i));
					  nSumm=nSumm+*((uint16_t*)((&(pPackEthernet->unIPdata.stIPPackEthernet.stICMPEchoProtocol.stICMPEchoProtocol.TypeAndCodeICMPMessage))+i));
					  nSumm=nSumm+((nSumm&0x10000)>>16);
						nSumm&=0xFFFF;
         }
    }
    return (uint16_t)(~nSumm); 
}

/* ������� �������� ����������� ����� UDP  */

uint16_t WritecheskSumUDP()
{
	  uint32_t i;
    uint32_t nSumm=0;
    uint16_t size_udp=0;
	  uint16_t flag,xt;
	  if(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.KOP_FIELD==KOP_WRITE_DATA)
    {
			size_udp=(sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet)+
				sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet)); 			
		}
    else
    {
			/* if(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.WS_FIELD==0x30)
			 {
				  NumerPack=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.NP_FIELD;
			 }
			 else
			 {
				  NumerPack=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.NP_FIELD+5u;
			 }*/
			 size_udp=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack;
			 size_udp=((size_udp&0xFF00)>>8u)|((size_udp&0x00FF)<<8u);
			/* switch(NumerPack)
			 {
				 case 1:
					   size_udp=(sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet)+
							sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet)+sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.NewIp));
					   break;
				 case 2:
					   size_udp=(sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet)+
							sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet)+sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.NewMaskIp));
					   break;
				 case 3:
					   size_udp=(sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet)+
							sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet)+sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.NewUDPPort)); 
					   break;
				 case 4:
					   size_udp=(sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet)+
							sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet)+sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stMacPack));
					   break;
				 case 5:
					  size_udp=sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet)+(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet.DLC_FIELD);
							//sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet)+sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingCommutator));
					  break;
				 case 6:
						 size_udp=(sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet)+
							sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet)+sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stTempratureCommutator));	
					   break;
         case 7:
					   size_udp=(sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet)+
							sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stPAYHeaderPackEthernet)+sizeof(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.unUdpData.stSettingSystemCommutator));
             break;					 
			 }*/
		}
    flag=size_udp;
		size_udp=((size_udp+1)/2);
		flag=(size_udp*2)-flag;
		if(flag!=0)
		{
			 xt=pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[size_udp-1];
			 xt&=0x00FF;
			 *((uint16_t*)(&(pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[size_udp-1])))=xt;
		}
		size_udp=size_udp+6;
		nSumm=0;
		for(i=0;i<size_udp;i++)
    {
			  if(i == 9) continue;
        else
        { 
					 if(i<4)
					 {
						  nSumm=nSumm+pPackEthernet->unIPdata.stIPPackEthernet.unIPHead.IPChekSumm[i+6];
					 }
					 if(i==4)
					 {
						  nSumm=nSumm+pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.stUdpPack.stUDPHeaderPackEthernet.LengthUDPPack;
					 }
					 if(i==5)
					 {
						 nSumm=nSumm+0x1100;
					 }
					 if(i>5)
					 {
						 nSumm=nSumm+pPackEthernet->unIPdata.stIPPackEthernet.unUDPEthernet.UDPChekSumm[i-6];	
					 }
					  nSumm=nSumm+((nSumm&0x10000)>>16);
						nSumm&=0xFFFF;
				}	
		}
		return (uint16_t)(~nSumm);	
}

/**
 * ������� ����������� ��������� ������ ARP
 * @param 
 * @return 
 */
void creat_arp_answer(void)
{
	ARPIPsender snARPIPsender;
	snARPIPsender.ARPIPSender=operation_data->nIpPAY;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.TypeCarrier)))=0x0100;
	*((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.IPV4Protocol)))=0x0008;
  *((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.SizeARPPack)))=0x0406;	
	*((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.TipeArpPack)))=0x0200;
  *((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacHSource)))=operation_data->musnMacComm[0];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacMSource)))=operation_data->musnMacComm[1];
	*((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacLSource)))=operation_data->musnMacComm[2];
	*((uint32_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPIPSource)))=operation_data->nIpComm;
  *((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacHSender)))=operation_data->musnMacPay[0];
  *((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacMSender)))=operation_data->musnMacPay[1];
  *((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.ARPMacLSender)))=operation_data->musnMacPay[2];
  *(((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.unARPIPsender.chARPIPSender[0]))))=snARPIPsender.chARPIPSender[0];
	*(((uint16_t*)(&(pPackEthernet->unIPdata.stARPPackEthernet.unARPIPsender.chARPIPSender[1]))))=snARPIPsender.chARPIPSender[1];
}

void SetSwitchCode(uint8_t NumerAntenna, uint8_t NumerSwitch, uint8_t TypePlata)
{
	 uint8_t code;
	 switch(NumerAntenna)
	 {
		 case 1:
			    code=3;
		 	    break;
		 case 2:
					code=2;
			    break;
		 case 3:
			    code=0;
					break;
		 case 4:
				  code=1;
			    break;					
	 }
	 if(TypePlata==1)//�������
   {
		  operation_data->usnKeyCode|=(code<<(NumerSwitch*2));
	 }
	 else
	 {
		  operation_data->usnKeyCode|=((code<<(NumerSwitch*2))<<16u);
	 }
}

void SetEnSwitch(uint8_t NumerAntenna,uint8_t NumerSwitch,uint8_t TypePlata)
{
	 uint32_t code;
	 code=(1<<((NumerAntenna-1)*8+NumerSwitch));	 
	 if(TypePlata==1)//�������
	 {
		 operation_data->EnChannelComm[0]|=((code&0x00001FFF)<<3); 
		 operation_data->EnChannelComm[1]|=((code&0x1FFFE000)>>13);
		 operation_data->EnChannelComm[2]|=((code&0xE0000000)>>29);
	 }
	 else
	 {  
		 operation_data->EnChannelComm[3]|=((code&0x00001FFF)<<3);
		 operation_data->EnChannelComm[4]|=((code&0x1FFFE000)>>13);
		 operation_data->EnChannelComm[5]|=((code&0xE0000000)>>29); 
	 }
}



void SetSmolPalataKeys(uint8_t NumerAntenna, uint8_t mode, uint8_t TypePlata)
{
	//���������� ���
	//
	if(mode==0) //������� �����
	{	 
		 switch(NumerAntenna)
		 {
			 case 1:
						switch(operation_data->uchTypeComm)
						{
								case 1:
									  operation_data->SystemChannel&=0xFFFFFFFD; //RF1-ON EN2-0 CTRL2-1	
										break;
								case 2:
											operation_data->SystemChannel&=0xFFFDFFFF;											
									  break;
								case 3:
										if(TypePlata==1)//���
										{
											  operation_data->SystemChannel&=0xFFFFFFFD; //RF1-ON EN2-0 CTRL2-1	
										}
										else //���
										{
											  operation_data->SystemChannel&=0xFFFDFFFF; //RF1-ON EN2-0 CTRL2-1	
										}
										break;
						}
				    break;
			 case 2:
				    switch(operation_data->uchTypeComm)
						{
								case 1:
									  operation_data->SystemChannel&=0xFFFFFFEE; //RF2-ON EN1-0 CTRL2-0	
										break;
								case 2:
										operation_data->SystemChannel&=0xFFEEFFFF; //RF1-ON EN2-0 CTRL2-1
									  break;
								case 3:
										if(TypePlata==1)//���
										{
											  operation_data->SystemChannel&=0xFFFFFFEE; //RF2-ON EN2-1 CTRL2-1	
										}
										else //���
										{
											  operation_data->SystemChannel&=0xFFEEFFFF; //RF2-ON EN2-2 CTRL2-1	
										}
										break;
						}
				    break;
			 case 3:
						switch(operation_data->uchTypeComm)
						{
								case 1:
									  operation_data->SystemChannel&=0xFFFDFFFF; //RF1-ON EN2-0 CTRL2-1	
										break;
								case 2:
									  operation_data->SystemChannel&=0xFFFFFFFD; //RF1-ON EN2-0 CTRL2-1		
									  break;
								case 3:
										if(TypePlata==1)//���
										{
											  operation_data->SystemChannel&=0xFFFFFDFF; //RF1-ON EN2-0 CTRL2-1	
										}
										else //���
										{
											  operation_data->SystemChannel&=0xFDFFFFFF; //RF1-ON EN2-0 CTRL2-1	
										}
										break;
						}
						break;
			 case 4:
						switch(operation_data->uchTypeComm)
						{
								case 1:
									  operation_data->SystemChannel&=0xFFEEFFFF; //RF2-ON EN1-0 CTRL2-0	
										break;
								case 2:
										operation_data->SystemChannel&=0xFFFFFFEE; //RF2-ON EN1-0 CTRL1-0	
									  break;
								case 3:
										if(TypePlata==1)//���
										{
											  operation_data->SystemChannel&=0xFFFFEEFF; //RF2-ON EN2-1 CTRL2-1	
										}
										else //���
										{
											  operation_data->SystemChannel&=0xEEFFFFFF; //RF2-ON EN2-2 CTRL2-1	
										}
							  break;
						}	
		 }	 
	}
	else // ���������� 10���
	{
		switch(NumerAntenna)
		{
			 case 1:
						switch(operation_data->uchTypeComm)
						{
								case 1:
									  operation_data->SystemChannel&=0xFF33FFD9; //[EN2-0,CTR2-0,EN3-0,CTRL3-1],[EN3-0,CTRL3-0,EN4-0,CTRL4-0]
										break;
								case 2:
										operation_data->SystemChannel&=0xFFD9FF33; //[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN2-0,CTR2-0,EN3-0,CTRL3-1]
									  break;
								case 3:
										if(TypePlata==1)//���
										{
											  operation_data->SystemChannel&=0xFFFF33D9; //[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN2-0,CTR2-0,EN3-0,CTRL3-1]	
										}
										else //���
										{
											  operation_data->SystemChannel&=0x33D93333; //[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN2-0,CTR2-0,EN3-0,CTRL3-1],[EN3-0,CTRL3-0,EN4-0,CTRL4-0]
										}
										break;
						}
				    break;
			 case 2:
						switch(operation_data->uchTypeComm)
						{
								case 1:
									  operation_data->SystemChannel&=0xFF33FFB2; //[EN1-0 CTRL-1,EN4-0 CTRL4-1, EN3-0 CTRL3-0],[EN3-0,CTRL3-0,EN4-0,CTRL4-0]
										break;
								case 2:
										operation_data->SystemChannel&=0xFFB2FF33; //[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN1-0 CTRL-1,EN4-0 CTRL4-1, EN3-0 CTRL3-0]
									  break;
								case 3:
										if(TypePlata==1)//���
										{
											  operation_data->SystemChannel&=0xFFFF33B2; //[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN1-0 CTRL-1,EN4-0 CTRL4-1, EN3-0 CTRL3-0]
										}
										else //���
										{
											  operation_data->SystemChannel&=0x33B23333; //[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN3-0,CTRL3-0,EN4-0,CTRL4-0],
										}
										break;
						}
						break;
			 case 3:
				    switch(operation_data->uchTypeComm)
						{
								case 1:
									  operation_data->SystemChannel&=0xFFD9FF33; //[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN2-0,CTR2-0,EN3-0,CTRL3-1]
										break;
								case 2:
										operation_data->SystemChannel&=0xFF33FFD9; //[EN2-0,CTR2-0,EN3-0,CTRL3-1], [EN3-0,CTRL3-0,EN4-0,CTRL4-0]
									  break;
								case 3:
										if(TypePlata==1)//���
										{
											  operation_data->SystemChannel&=0xFFFFD9FF; //[EN2-0,CTR2-0,EN3-0,CTRL3-1],[EN3-0,CTRL3-0,EN4-0,CTRL4-0]
										}
										else //���
										{
											  operation_data->SystemChannel&=0xD9FF3333; //[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN2-0,CTR2-0,EN3-0,CTRL3-1]
										}
										break;
						}
						break;
			 case 4:
				    switch(operation_data->uchTypeComm)
						{
								case 1:
									  operation_data->SystemChannel&=0xFFB2FF33; //[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN1-0 CTRL-1,EN4-0 CTRL4-1, EN3-0 CTRL3-0]
										break;
								case 2:
										operation_data->SystemChannel&=0xFF33FFB2; //[EN1-0 CTRL-1,EN4-0 CTRL4-1, EN3-0 CTRL3-0],[EN3-0,CTRL3-0,EN4-0,CTRL4-0],
									  break;
								case 3:
										if(TypePlata==1)//���
										{
											  operation_data->SystemChannel&=0xFFFFB2FF; //[EN1-0 CTRL-1,EN4-0 CTRL4-1, EN3-0 CTRL3-0],[EN3-0,CTRL3-0,EN4-0,CTRL4-0]
										}
										else //���
										{
											  operation_data->SystemChannel&=0xB2FF3333; //[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN3-0,CTRL3-0,EN4-0,CTRL4-0],[EN3-0,CTRL3-0,EN4-0,CTRL4-0],
										}
										break;
						}
				    break;
		}
	}
}

void SetAtenuation(uint8_t NumerAntenna,uint8_t NumerSwitch,uint8_t TypePlata, uint8_t NumerChannel)
{
	  uint8_t k=0; //�������� 12.12.2019
	  uint8_t i=0; //�������� 12.12.2019
	  uint8_t n=0; //�������� 12.12.2019
	
	  NumerChannel--;
	  int8_t correct_kof[8];
	  for(i=0;i<8;i++)
	  {	
			correct_kof[i]=0;
			if((operation_data->muchGainManger[i]==0)&(operation_data->muchGainCorrectNool[i]!=0))
			{
				correct_kof[i]=-1;
			}
			if((operation_data->muchGainManger[i]==40)&(operation_data->muchGainCorrectNool[i]==0))
			{
				correct_kof[i]=1;
			}	
			
			
		} 
		switch(operation_data->uchTypeComm)
		{
			case 1:
						if(TypePlata==1)//�������
						{
							 k=0;
							 n=0;//�������� 12.12.2019
						}
						else
						{
							 k=8;
							 n=4;//�������� 12.12.2019
						}
				    switch(NumerAntenna)
						{
							case 1:
									 operation_data->uschAttenuation[k+0]=((((operation_data->muchGainManger[NumerChannel]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel]))&0x3F)<<2)|0; //�������� 12.12.2019
									 break;
							case 2:
								   operation_data->uschAttenuation[k+1]=((((operation_data->muchGainManger[NumerChannel]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel]))&0x3F)<<2)|0; //�������� 12.12.2019
									 break;
              case 3:
								   operation_data->uschAttenuation[k+2]=((((operation_data->muchGainManger[NumerChannel]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel]))&0x3F)<<2)|0;	 //�������� 12.12.2019
									 break;
							case 4:
								   operation_data->uschAttenuation[k+3]=((((operation_data->muchGainManger[NumerChannel]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel]))&0x3F)<<2)|0; //�������� 12.12.2019
									 break;
						}
				  break;
			case 2:
				  if(TypePlata==1)//�������
					{
							 k=0;
						   n=0;//�������� 12.12.2019
					}
					else
					{
							 k=16;
						   n=4;//�������� 12.12.2019
					}
					switch(NumerSwitch)
					{
						 case 0:
									operation_data->uschAttenuation[k+0+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;//�������� 12.12.2019
									break;
						 case 1:
							    operation_data->uschAttenuation[k+0+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;//�������� 12.12.2019
									break;
						 case 2:
								  operation_data->uschAttenuation[k+1+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;//�������� 12.12.2019
									break;
						 case 3:
									operation_data->uschAttenuation[k+1+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;//�������� 12.12.2019
									break;
						 case 4:
									operation_data->uschAttenuation[k+2+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;//�������� 12.12.2019
									break;
						 case 5:
									operation_data->uschAttenuation[k+2+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;//�������� 12.12.2019
									break;
						 case 6:
									operation_data->uschAttenuation[k+3+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;//�������� 12.12.2019
									break;
						 case 7:
									operation_data->uschAttenuation[k+3+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+n]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;//�������� 12.12.2019
									break;
					}
					break;
			case 3:
				  if(TypePlata==1)//�������
					{
							 k=0;
					}
					else
					{
							 k=16;
					}
					if(TypePlata==1)
					{						
						switch(NumerSwitch)
						{
						 case 0:
									operation_data->uschAttenuation[k+0+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+4]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;
									break;
						 case 1:
							    operation_data->uschAttenuation[k+0+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+4]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;
									break;
						 case 2:
								  operation_data->uschAttenuation[k+1+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+4]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;
									break;
						 case 3:
									operation_data->uschAttenuation[k+1+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+4]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;
									break;
						 case 4:
									operation_data->uschAttenuation[k+2+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+4]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;
									break;
						 case 5:
									operation_data->uschAttenuation[k+2+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+4]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;
									break;
						 case 6:
									operation_data->uschAttenuation[k+3+4*(NumerAntenna-1)]=((((operation_data->muchGainManger[NumerChannel+4]+operation_data->muchGainCorrectNool[NumerChannel+4]+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;
									break;
						 case 7:
									operation_data->uschAttenuation[k+3+4*(NumerAntenna-1)]=(((uint8_t)(((int8_t)(operation_data->muchGainManger[NumerChannel+4])+(int8_t)(operation_data->muchGainCorrectNool[NumerChannel+4])+correct_kof[NumerChannel+4]))&0x3F)<<2)|0;
									break;
					}
				 }
				 else
				 {
						 	switch(NumerAntenna)
					    {
							  case 1:
									 operation_data->uschAttenuation[k+0]=((((operation_data->muchGainManger[NumerChannel]+operation_data->muchGainCorrectNool[NumerChannel]+correct_kof[NumerChannel]))&0x3F)<<2)|0;
								   break;
							 case 2:
								   operation_data->uschAttenuation[k+1]=((((operation_data->muchGainManger[NumerChannel]+operation_data->muchGainCorrectNool[NumerChannel]+correct_kof[NumerChannel]))&0x3F)<<2)|0;
									 break;
               case 3:
								   operation_data->uschAttenuation[k+2]=((((operation_data->muchGainManger[NumerChannel]+operation_data->muchGainCorrectNool[NumerChannel]+correct_kof[NumerChannel]))&0x3F)<<2)|0;
									 break;
							 case 4:
								   operation_data->uschAttenuation[k+3]=((((operation_data->muchGainManger[NumerChannel]+operation_data->muchGainCorrectNool[NumerChannel]+correct_kof[NumerChannel]))&0x3F)<<2)|0;
									 break;
					   }
					}			
					break;
		}
}

void SetCommunicationPin()
{
   uint32_t i,k;
	 uint8_t mode,SwitchChannel;
	 //��������� ������� ������������ ����������
	 for(i=0;i<32;i++)
	 {
		 operation_data->uschAttenuation[i]=0;
		 if(i<6)
		 {
			   operation_data->EnChannelComm[i]=0;
		 }
	 }
	 operation_data->SystemChannel=0xFFFFFFFF;//��������� ��� ������
	 operation_data->usnKeyCode=0;
	 if(operation_data->uchWork!=0)
	 {
		 if(operation_data->uchTypeComm==3)
		 {
				if(operation_data->uchWork>4)
				{
					 SetSmolPalataKeys(operation_data->uchWork-4U,1,1);
				}
				else
				{
					 SetSmolPalataKeys(operation_data->uchWork,1,0);
				}
		 }
		 else
		 {
			 SetSmolPalataKeys(operation_data->uchWork,1,0);
		 }      
	 }
	 else
	 {
			 for(i=0;i<16;i++)
			 {
						if(i<8)
						{
							 mode=1;
						}
						else
						{
							 mode=0;
						}
				 if((operation_data->muchSwitchComm[i]!=0)&(operation_data->muchSwitchComm[i]<5))//����� ������ � ��������� �� 1 �� 4
				 {
					 switch(operation_data->uchTypeComm)
					 {
							case 1:
									 switch(operation_data->muchSwitchComm[i])//�������������� �������
									 {
												 case 1:
															if(i<8)//������� 
															{
																	SwitchChannel=3;
															}
															else//�������
															{
																	SwitchChannel=4;
															}	
															break;
												 case 2:
															if(i<8)
															{
																	SwitchChannel=1;
															}
															else//�������
															{
																	SwitchChannel=2;
															}
															break;
												 case 3:
															if(i<8)
															{
																	SwitchChannel=4;
															}
															else//�������
															{
																	SwitchChannel=3; 
															}
															break;
												 case 4:
															if(i<8)
															{
																SwitchChannel=2;
															}
															else//�������
															{
																SwitchChannel=1;
															}	
															break;	 
									}	
									if(mode==1)
									{
										 SetSwitchCode(SwitchChannel,i,mode);
										 SetEnSwitch(SwitchChannel,i,mode);
										 SetSmolPalataKeys(operation_data->muchSwitchComm[i],0,mode);
										 SetAtenuation(SwitchChannel,i,mode,operation_data->muchSwitchComm[i]);
									}
									else
									{
										 SetSwitchCode(SwitchChannel,i-8,mode);
										 SetEnSwitch(SwitchChannel,i-8,mode);	
										 SetSmolPalataKeys(operation_data->muchSwitchComm[i],0,mode);
										 SetAtenuation(SwitchChannel,i-8,mode,operation_data->muchSwitchComm[i]);
									}
								break;
							case 2:
									switch(operation_data->muchSwitchComm[i])//�������������� �������
									{
												case 1:
															if(i<8)//�������
															{
																	SwitchChannel=3;
															}
															else//�������
															{
																	SwitchChannel=4;
															}	
															break;
												 case 2:
															if(i<8)//�������
															{
																	SwitchChannel=1;
															}
															else
															{
																	SwitchChannel=2;
															}
															break;
												 case 3:
															if(i<8)//�������
															{
																	SwitchChannel=4;
															}
															else
															{
																	SwitchChannel=3; 
															}
															break;
												 case 4:
															if(i<8)//�������
															{
																SwitchChannel=2;
															}
															else
															{
																SwitchChannel=1;
															}	
															break;	 
									}
									k=i;
							 	if((SwitchChannel==2)&(mode==0))
									{
										 switch(k)
										 {
											   case 12:
												    k=14;   
												 break;
											   case 13: 
												    k=15; 
												 break;
											   case 14:
												    k=12;
												 break;
											   case 15:
													  k=13;
												 break;
										 }
									}
									if((SwitchChannel==2)&(mode==1))
									{								
					   				 switch((k))
										 {
											   case 4:
												    k=6;
												 break;
											   case 5:
												    k=7;
												 break;
											   case 6:
												    k=4;
												 break;
											   case 7:
													  k=5;
												 break;
										 }
									}
									if(mode==0)
									{				
										 SetSwitchCode(SwitchChannel,i-8,1);
										 SetEnSwitch(SwitchChannel,k-8,1);
										 SetSmolPalataKeys(operation_data->muchSwitchComm[i],0,1);
										 SetAtenuation(SwitchChannel,i-8,1,operation_data->muchSwitchComm[i]);
									}
									else
									{
										 SetSwitchCode(SwitchChannel,i,0);
										 SetEnSwitch(SwitchChannel,k,0);	
										 SetSmolPalataKeys(operation_data->muchSwitchComm[i],0,1);
										 SetAtenuation(SwitchChannel,i,0,operation_data->muchSwitchComm[i]);
									}
									break;
							case 3:
									 switch(operation_data->muchSwitchComm[i])//�������������� �������
									 {
											case 1:
													if(i<8)//�������
													{
																SwitchChannel=4;
													}
													else//������� 
													{
																SwitchChannel=2;
													}	
													break;
										 case 2:
													if(i<8)//�������
													{
															SwitchChannel=3;
													}
													else //�������
													{
															SwitchChannel=1;
													}
															break;
										case 3:
													if(i<8)//�������
													{
															SwitchChannel=2; 
													}
													else//�������
													{
															SwitchChannel=4;
													}
													break;
										case 4:
													if(i<8)//�������
													{
																SwitchChannel=1;
													}
													else//�������
													{
																SwitchChannel=3;
													}	
													break;	 
									}
									k=i; 
									if((mode==0)&(SwitchChannel==2))
									{
										 switch(k)
										 {
											   case 12:
												    k=14;
												 break;
											   case 13:
												    k=15;
												 break;
											   case 14:
												    k=12;
												 break;
											   case 15:
													  k=13;
												 break;
										 }
									}																	
									if(mode==1)
									{
										 SetSwitchCode(SwitchChannel,i,0);
										 SetEnSwitch(SwitchChannel,k,0);
										 SetSmolPalataKeys(operation_data->muchSwitchComm[i],0,0);
										 SetAtenuation(SwitchChannel,i,0,operation_data->muchSwitchComm[i]);
									}
									else
									{
										 SetSwitchCode(SwitchChannel,i-8,1);
										 SetEnSwitch(SwitchChannel,k-8,1);	
										 SetSmolPalataKeys(operation_data->muchSwitchComm[i],0,1);
										 SetAtenuation(SwitchChannel,i-8,1,operation_data->muchSwitchComm[i]);
									}
							 break;				
					 }
				 }
			 }
	 }			 
	 HardwareSet(1);
	 WriteSettingCommUart();	
}

