﻿#ifndef SPI_INTERFACE_H
#define SPI_INTERFACE_H
extern  void InitSPI(void); // Функция инициализации SPI интерфейса
extern void wrate_byte_spi(uint8_t *buffer, uint32_t number_write_byte, uint8_t mode, uint8_t NomerSpi,uint8_t RdWr); //Функция  записи в SPI интерфейс
extern void read_byte_spi(uint8_t *buffer, uint32_t number_read_byte, uint8_t mode,  uint8_t NomerSpi); // Функция  чтения в SPI интерфейс
#endif /*SPI_INTERFACE_H*/

