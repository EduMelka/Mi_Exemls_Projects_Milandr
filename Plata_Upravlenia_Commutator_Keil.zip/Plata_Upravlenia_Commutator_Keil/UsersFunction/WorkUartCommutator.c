﻿#include "opora.h"
#include "FullUserHeader.h"

uint8_t buffer_reciv_uart[255];
UartData unUartData;

void send_data_uart(uint8_t *buffer, uint32_t suze_buffer)
{
   uint16_t  status;
   uint32_t i; 
	 UART2->CR&=0xFFFE;
	 UART2->CR|=0x0100;
	 for(i=0;i<suze_buffer;i++)
	 {
			 UART2->DR=buffer[i];
		   UART2->CR|=1;
			 status=UART2->FR;	
			 while((status&0x0008)==0x0008)
			 {
					status=UART2->FR;
			 } 
	 }
	UART2->CR&=0xFFFE; 
	UART2->CR&=0xFEFF;
	UART2->CR|=1; 
}


void InitUART2Interface(void) //функция инициализации  UART2 интерфейса
{
  PORTC->FUNC |= ((3 << 13*2) | (3 << 14*2)); //режим работы порта
  PORTC->ANALOG |= ((1 << 13) | (1 << 14)); //цифровой
  PORTC->PWR |= ((3 << 13*2) | (3 << 14*2)); //максимально быcтрый
  RST_CLK->UART_CLOCK =
	(1<<25u)| //Uart 2 CLK ВКЛ
	(3<<8u);  // Uart2CLK=64МГц/8=8МГц	
  UART2->IBRD = Uart2Speed[operation_data->SpeedUart][0]; //установка скорости бит/с
  UART2->FBRD = Uart2Speed[operation_data->SpeedUart][1]; 
	UART2->LCR_H=
							(0<<0)|//открыть порт
	            (0<<1)|//включить проверку четности
							(0<<2)|
							(0<<3)|//один стоповый бит 
							(0<<4)|//выключить fifo приёмника/передатчика
							(3<<5)|//количество принимаемы/передоваемых бит 8
							(0<<7);
 UART2->IMSC&=0xF000;	
 UART2->IMSC|=0x0050;
 UART2->IFLS&=0xFFC0;	
 UART2->IFLS|=(4<<0)|(0<<3);
 UART2->CR|=0x0201;
 SET_IRQ(UART2_IRQn)
 SET_PRIORITET_UART2_IRQ(0)
}
