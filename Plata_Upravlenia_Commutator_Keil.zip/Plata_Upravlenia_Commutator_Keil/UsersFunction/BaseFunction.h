﻿#ifndef BASE_FUNCTION_H
#define BASE_FUNCTION_H

#include <stdio.h>
#include <stdint.h>

 //void Paste_stuct(void *a, unsigned char size_a,  void *b,  unsigned char size_b,  void *c, unsigned char size_c);//Функция склеивания структур
 //void Init_Struct(); // Инициализация рабочей струкуры из памяти
 //void fSendDataAplicateCommPAY(unsigned char read_type); //Функция формирования пакетов ответа
 //void TestSummDataFlash(unsigned char* a); //Функция проверки записи в памяти
 
 
 extern void Save_Struct(void); // Функция записи данных в память
 extern void test_fun(void);
 extern void InterprtataPack(uint8_t mode); // Функция расшифровки запроса от ПАУ
 extern void cControlSumIP(FILE *pStream); //функция подсчета контрольной суммы IP заголовка
 extern void ReadMessageInStruct(uint8_t *chBuffer);//функция заполнения структуры из принятого сообщения 
 extern void WriteMessageInBuffer(uint8_t *chBuffer);//функция заполнения сообщения из структуры
 
 
#endif /*BASE_FUNCTION_H*/
