
#include <stdint.h>
#pragma pack(1)


extern uint8_t    hdb;
extern uint8_t    last_hdb; 
extern uint8_t    indexBit;
extern uint8_t 		Addr1Wire[9][8];
extern uint8_t multirequest_micr_1wire;
extern uint8_t reqiest_data_micr_1wire;
extern uint8_t time_out_data_micr_1wire;
extern uint8_t  MassivDataUart2[20];
extern uint8_t kolvo_antenn;
extern uint16_t SummAdrr[16];
extern uint8_t massiv_vseh_termodannih_AFU_MRL[8];
extern uint8_t massiv_vseh_termodannih_AFU_BIS[5];
extern  uint8_t massiv_send_addrr[65];



extern uint8_t ComanndMode1Wire(void);
extern void SEND_IRQ_1WIRE(void);
extern uint8_t SendConfigDS240B(void);
extern uint8_t O1WIRE_BUS_RESET(void);
extern uint8_t CONFIG_DS2480B(void);
extern uint8_t O1WireReset(void);
extern void ClearBufferUart2(void);
extern uint8_t ReadSearchROMandStat(uint8_t *massiv_correct,uint8_t *addres_rom, uint8_t *massiv_correct_out);
extern uint8_t GetTemperAFU(void);
extern uint8_t convert_temperature(void);
extern  void  send_data_UART_2(uint8_t *buffer, uint32_t suze_buffer);
extern  void wait_150ns(uint32_t n);		
extern void Clearlewelwood1wire(void);
extern uint8_t serch_bit1wire(uint8_t *massiv_serch);
extern void set_bit1wire(uint8_t *massiv_resp, uint8_t *massiv_adrr, uint8_t posit_bit);
extern uint8_t get_temperature(void); 
