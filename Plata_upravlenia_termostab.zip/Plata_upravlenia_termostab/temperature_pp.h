#ifndef TEMPERATURE_PP_H
#define TEMPERATURE_PP_H

//CS-ы всех soft SPI-ев
#define SPI_T_MOTHER_CS1_ON  PORTB->SETTX|=(1U<<15U)//включается единицей, вход на микросхеме не инверсный!!!
#define SPI_T_MOTHER_CS2_ON  PORTB->SETTX|=(1U<<1U)
#define SPI_T_MOTHER_CS3_ON  PORTB->SETTX|=(1U<<3U)

#define KMV_GETER_T_CS1_ON   PORTB->SETTX|=(1U<<7U)
#define KMV_GETER_T_CS2_ON   PORTB->SETTX|=(1U<<9U)

#define RT5_RT10_SPI_CS1_ON  PORTC->SETTX|=(1U<<2U)
#define RT5_RT10_SPI_CS2_ON  PORTC->SETTX|=(1U<<1U)
#define RT5_RT10_SPI_CS3_ON  PORTB->SETTX|=(1U<<12U)
#define RT5_RT10_SPI_CS4_ON  PORTB->SETTX|=(1U<<13U)

#define RT4_RT9_SPI_CS1_ON   PORTF->SETTX|=(1U<<9U)
#define RT4_RT9_SPI_CS2_ON   PORTF->SETTX|=(1U<<8U)
#define RT4_RT9_SPI_CS3_ON   PORTC->SETTX|=(1U<<0U)
#define RT4_RT9_SPI_CS4_ON   PORTF->SETTX|=(1U<<12U)

#define RT3_RT8_SPI_CS1_ON   PORTD->SETTX|=(1U<<6U)
#define RT3_RT8_SPI_CS2_ON   PORTD->SETTX|=(1U<<5U)
#define RT3_RT8_SPI_CS3_ON   PORTF->SETTX|=(1U<<7U)
#define RT3_RT8_SPI_CS4_ON   PORTF->SETTX|=(1U<<6U)

#define RT2_RT7_SPI_CS1_ON   PORTD->SETTX|=(1U<<0U)
#define RT2_RT7_SPI_CS2_ON   PORTC->SETTX|=(1U<<15U)
#define RT2_RT7_SPI_CS3_ON   PORTD->SETTX|=(1U<<4U)
#define RT2_RT7_SPI_CS4_ON   PORTD->SETTX|=(1U<<3U)

#define RT1_RT6_SPI_CS1_ON   PORTF->SETTX|=(1U<<13U)
#define RT1_RT6_SPI_CS2_ON   PORTA->SETTX|=(1U<<15U)
#define RT1_RT6_SPI_CS3_ON 	 PORTC->SETTX|=(1U<<14U)
#define RT1_RT6_SPI_CS4_ON   PORTC->SETTX|=(1U<<13U)



#define SPI_T_MOTHER_CS1_OFF PORTB->CLRTX=(1U<<15U)
#define SPI_T_MOTHER_CS2_OFF PORTB->CLRTX=(1U<<1U)
#define SPI_T_MOTHER_CS3_OFF PORTB->CLRTX=(1U<<3U)

#define KMV_GETER_T_CS1_OFF  PORTB->CLRTX=(1U<<7U)
#define KMV_GETER_T_CS2_OFF  PORTB->CLRTX=(1U<<9U)

#define RT5_RT10_SPI_CS1_OFF PORTC->CLRTX=(1U<<2U)
#define RT5_RT10_SPI_CS2_OFF PORTC->CLRTX=(1U<<1U)
#define RT5_RT10_SPI_CS3_OFF PORTB->CLRTX=(1U<<12U)
#define RT5_RT10_SPI_CS4_OFF PORTB->CLRTX=(1U<<13U)

#define RT4_RT9_SPI_CS1_OFF  PORTF->CLRTX=(1U<<9U)
#define RT4_RT9_SPI_CS2_OFF  PORTF->CLRTX=(1U<<8U)
#define RT4_RT9_SPI_CS3_OFF  PORTC->CLRTX=(1U<<0U)
#define RT4_RT9_SPI_CS4_OFF  PORTF->CLRTX=(1U<<12U)

#define RT3_RT8_SPI_CS1_OFF  PORTD->CLRTX=(1U<<6U)
#define RT3_RT8_SPI_CS2_OFF  PORTD->CLRTX=(1U<<5U)
#define RT3_RT8_SPI_CS3_OFF  PORTF->CLRTX=(1U<<7U)
#define RT3_RT8_SPI_CS4_OFF  PORTF->CLRTX=(1U<<6U)

#define RT2_RT7_SPI_CS1_OFF  PORTD->CLRTX=(1U<<0U)
#define RT2_RT7_SPI_CS2_OFF  PORTC->CLRTX=(1U<<15U)
#define RT2_RT7_SPI_CS3_OFF  PORTD->CLRTX=(1U<<4U)
#define RT2_RT7_SPI_CS4_OFF  PORTD->CLRTX=(1U<<3U)

#define RT1_RT6_SPI_CS1_OFF  PORTF->CLRTX=(1U<<13U)
#define RT1_RT6_SPI_CS2_OFF  PORTA->CLRTX=(1U<<15U)
#define RT1_RT6_SPI_CS3_OFF  PORTC->CLRTX=(1U<<14U)
#define RT1_RT6_SPI_CS4_OFF  PORTC->CLRTX=(1U<<13U)
///////////////////////////////////////////////////

//константы
extern uint8_t tochka_razresheniya_raboti_ventilyatora;	//точка разрешения работы вентилятора, равна +31 С
extern uint8_t tochka_minimalnogo_peregreva;            //точка минимального перегрева, равна +30 С
extern uint8_t tochka_razresheniya_vklucheniya;        	//точка разрешения включения прибора, равна -35 С
extern uint8_t tochka_termostabilizacii_niz;            //нижняя достижения термостабилизации, равна +29 С
extern uint8_t tochka_termostabilizacii_verh;           //верхняя точка достижения термостабилизации, равна +33 С
//константы

extern uint8_t osnovnie_konstanti[5];
extern uint8_t buffer_osnovnie_konstanti[5];
extern uint8_t index_osnovnoy_konstanti;
extern uint8_t kontr_summa_buffer_osnovnie_konstanti;

extern uint8_t flag_ERROR;//1-есть ошибка, 0-нет ошибки

extern uint8_t  Tpp_min;
extern uint8_t  Tpp_max;
extern uint8_t  Tpp_average;

extern uint8_t  moschnost_raboti_ventilyatora;           // !не обнуляется!

extern uint8_t sostoyaniya_nog_nPRSNT[13]; // !не обнуляется!
extern uint8_t flag_konfiguracii_BPV;                                // !не обнуляется! 1-БИК СБИС-А, 0-ИК МРЛ-А
extern uint8_t flag_vklucheniya_BPV;                                 // !не обнуляется! 1-БПВ включен, 0-БПВ выключен
extern uint8_t flag_sostoyaniya_ventilyatora;                        //1-вентилятор включен, 0-вентилятор выключен
extern uint8_t flag_ventilyator_bil_v_rabote;                        // !не обнуляется! 1-вентилятор работал, 0-вентилятор отдыхал
extern uint8_t flag_razogreva[14];         //1-разогрев осуществляется, 0-разогрева нет
extern uint8_t flag_LED_RAZOGREV;         														//1-светодиод горит, 0-светодиод не горит
//
//  Для всех 13-разрядных массивов:
//  _name_[12]- плата ЦОС
//  _name_[11]- плата ГТ (XP6)
//  _name_[10]- плата МДМ-КМВ (XS15)
//  _name_[9]- плата БКС (XS11)
//  _name_[8]- плата РТ9 (XS10)
//  _name_[7]- плата РТ8 (XS9)
//  _name_[6]- плата РТ7 (XS8)
//  _name_[5]- плата РТ6 (XS7)
//  _name_[4]- плата РТ5 (XS6)
//  _name_[3]- плата РТ4 (XS5)
//  _name_[2]- плата РТ3 (XS4)
//  _name_[1]- плата РТ2 (XS3)
//  _name_[0]- плата РТ1 (XS2)

extern uint8_t massiv_vseh_termodannih_pp_MRL[25];
extern uint8_t massiv_vseh_status_termodannih_pp_MRL[25];
extern uint8_t massiv_vseh_termodannih_pp_MRL_CORECT[25];
//
//massiv_vseh_termodannih_pp[24]-ЦОС
//massiv_vseh_termodannih_pp[23]-ЦОС
//massiv_vseh_termodannih_pp[22]-ЦОС
//massiv_vseh_termodannih_pp[21]-ГТ
//massiv_vseh_termodannih_pp[20]-МДМ-КМВ
//massiv_vseh_termodannih_pp[19]-БКС
//massiv_vseh_termodannih_pp[18]-БКС
//massiv_vseh_termodannih_pp[17]-РТ9
//massiv_vseh_termodannih_pp[16]-РТ9
//massiv_vseh_termodannih_pp[15]-РТ8
//massiv_vseh_termodannih_pp[14]-РТ8
//massiv_vseh_termodannih_pp[13]-РТ7
//massiv_vseh_termodannih_pp[12]-РТ7
//massiv_vseh_termodannih_pp[11]-РТ6
//massiv_vseh_termodannih_pp[10]-РТ6
//massiv_vseh_termodannih_pp[9]-РТ5
//massiv_vseh_termodannih_pp[8]-РТ5
//massiv_vseh_termodannih_pp[7]-РТ4
//massiv_vseh_termodannih_pp[6]-РТ4
//massiv_vseh_termodannih_pp[5]-РТ3
//massiv_vseh_termodannih_pp[4]-РТ3
//massiv_vseh_termodannih_pp[3]-РТ2
//massiv_vseh_termodannih_pp[2]-РТ2
//massiv_vseh_termodannih_pp[1]-РТ1
//massiv_vseh_termodannih_pp[0]-РТ1

extern uint8_t massiv_vseh_termodannih_pp_BIS[17];
extern uint8_t massiv_vseh_status_termodannih_pp_BIS[17];
extern uint8_t massiv_vseh_termodannih_pp_BIS_CORECT[17];
//
//massiv_vseh_termodannih_pp[16]-ЦОС
//massiv_vseh_termodannih_pp[15]-ЦОС
//massiv_vseh_termodannih_pp[14]-ЦОС
//massiv_vseh_termodannih_pp[13]-ГТ
//massiv_vseh_termodannih_pp[12]-МДМ-КМВ
//massiv_vseh_termodannih_pp[11]-БКС
//massiv_vseh_termodannih_pp[10]-БКС
//massiv_vseh_termodannih_pp[9]-РТ5
//massiv_vseh_termodannih_pp[8]-РТ5
//massiv_vseh_termodannih_pp[7]-РТ4
//massiv_vseh_termodannih_pp[6]-РТ4
//massiv_vseh_termodannih_pp[5]-РТ3
//massiv_vseh_termodannih_pp[4]-РТ3
//massiv_vseh_termodannih_pp[3]-РТ2
//massiv_vseh_termodannih_pp[2]-РТ2
//massiv_vseh_termodannih_pp[1]-РТ1
//massiv_vseh_termodannih_pp[0]-РТ1

extern uint8_t temperatura_COS[6];
extern uint8_t temperatura_GT[2];
extern uint8_t temperatura_MDM_KMV[2];
extern uint8_t temperatura_RT_1[4];
extern uint8_t temperatura_RT_2[4];
extern uint8_t temperatura_RT_3[4];
extern uint8_t temperatura_RT_4[4];
extern uint8_t temperatura_RT_5[4];
extern uint8_t temperatura_RT_6[4];
extern uint8_t temperatura_RT_7[4];
extern uint8_t temperatura_RT_8[4];
extern uint8_t temperatura_RT_9[4];
extern uint8_t temperatura_BKS[4];



void uznat_konfiguraciyu_BPV(void);
uint8_t chtenie_razryada_porta(int8_t port, uint8_t razryad);
void obnulenie_peremennih(void);
void opros_termodatchikov_pp(void);
uint8_t two_int8_t_to_1_uint8_t(int8_t *massive);
void termodannie_pp_v_1_massiv_BIS(void);
void termodannie_pp_v_1_massiv_MRL(void);
uint8_t naiti_minimalnoe_znachenie_pp(uint8_t *massive, uint8_t *massive_st, uint8_t razmer);
uint8_t naiti_maximalnoe_znachenie_pp(uint8_t *massive, uint8_t *massive_st, uint8_t razmer);
uint8_t naiti_srednee_znachenie_pp(uint8_t *massive,uint8_t *massive_st, uint8_t razmer);
void vkluchit_BPV(void);
void vikluchit_BPV(void);
void vkluchit_razogrev_pp(void);
void vikluchit_razogrev_pp(void);
void vkluchit_ventilyator(void);
void vikluchit_ventilyator(void);

uint8_t SPI_read_temperature(uint8_t number_of_spi,uint8_t CS, int8_t *correct);

void wait_150ns(uint32_t n);

int8_t spi_1_read_temperature(int8_t spi_cs, int8_t *correct);

int8_t spi_1_read_temper(void);
int8_t spi_1_read_config(void);
void spi_1_send_cmd(uint8_t cmd);
int16_t spi_1_read_data(int8_t d);	
void spi_1_clk_low(void);
void spi_1_clk_high(void);

int8_t spi_2_read_temperature(int8_t spi_cs, int8_t *correct);
int8_t spi_2_read_temper(void);
int8_t spi_2_read_config(void);
void spi_2_send_cmd(uint8_t cmd);
int16_t spi_2_read_data(int8_t d);
void spi_2_clk_low(void);
void spi_2_clk_high(void);

int8_t spi_3_read_temperature(int8_t spi_cs, int8_t *correct);
int8_t spi_3_read_temper(void);
int8_t spi_3_read_config(void);
void spi_3_send_cmd(uint8_t cmd);	
int16_t spi_3_read_data(int8_t d);
void spi_3_clk_low(void);
void spi_3_clk_high(void);

int8_t spi_4_read_temperature(int8_t spi_cs, int8_t *correct);
int8_t spi_4_read_temper(void);
int8_t spi_4_read_config(void);
void spi_4_send_cmd(uint8_t cmd);
int16_t spi_4_read_data(int8_t d);
void spi_4_clk_low(void);
void spi_4_clk_high(void);

int8_t spi_5_read_temperature(int8_t spi_cs, int8_t *correct);
int8_t spi_5_read_temper(void);
int8_t spi_5_read_config(void);
void spi_5_send_cmd(uint8_t cmd);	
int16_t spi_5_read_data(int8_t d);
void spi_5_clk_low(void);
void spi_5_clk_high(void);

int8_t spi_6_read_temperature(int8_t spi_cs, int8_t *correct);
int8_t spi_6_read_temper(void);
int8_t spi_6_read_config(void);
void spi_6_send_cmd(uint8_t cmd);
int16_t spi_6_read_data(int8_t d);	
void spi_6_clk_low(void);
void spi_6_clk_high(void);

int8_t spi_7_read_temperature(int8_t spi_cs, int8_t *correct);
int8_t spi_7_read_temper(void);
int8_t spi_7_read_config(void);
void spi_7_send_cmd(uint8_t cmd);
int16_t spi_7_read_data(int8_t d);
void spi_7_clk_low(void);
void spi_7_clk_high(void);
void led_blink_gen(void);



#endif // TEMPERATURE_PP_H

