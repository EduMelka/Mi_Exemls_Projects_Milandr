#ifndef GENERAL_HEADER_H
#define GENERAL_HEADER_H

#include <opora.h>
#include <stdint.h>
#include <math.h>
#include <stdio.h>

/////#define SPI_T_MOTHER_CS1_OFF PORTB->RXTX&=(unsigned short)(~(1U<<15U)) //как выставить 0

#define ISER_REG    0xE000E100	//Регистр разрешения прерываний
#define ICER_REG    0xE000E180	//Регистр запрета прерывания
#define ICPR_REG    0xE000E200  //Регистр сброса состояния ожидания обслуживания
//////////////////////////////

#define DELAY_MKS(X) while(--(X*64)){__NOP;} 

//адреса регистра приоритета прерываний
#define PR_IRQ0_3   0xE000E400
#define PR_IRQ4_7   0xE000E404
#define PR_IRQ8_13  0xE000E408
#define PR_IRQ12_15 0xE000E40C
#define PR_IRQ16_19 0xE000E410
#define PR_IRQ20_23 0xE000E414
#define PR_IRQ24_27 0xE000E418
#define PR_IRQ28_31 0xE000E41C
//////////////////////////////

//дефайны для простоты работы с прерываниями
#define SET_IRQ(X)   *((uint32_t*)(ISER_REG))|=(1u<<X)
#define SET_PRIORITET_TIMER1_IRQ(X)   *((uint32_t*)(PR_IRQ12_15))|=(X<<22u) //IP_14
#define SET_PRIORITET_TIMER2_IRQ(X)   *((uint32_t*)(PR_IRQ12_15))|=(X<<30u) //IP_15
#define SET_PRIORITET_TIMER3_IRQ(X)   *((uint32_t*)(PR_IRQ16_19))|=(X<<6u)	//IP_16
#define SET_PRIORITET_TIMER4_IRQ(X)   *((uint32_t*)(PR_IRQ12_15))|=(X<<14u)	//IP_13
#define SET_PRIORITET_BKP_IRQ(X)			*((uint32_t*)(PR_IRQ24_27))|=(X<<30u)	//IP_27
#define SET_PRIORITET_UART1_IRQ(X)    *((uint32_t*)(PR_IRQ4_7))|=(X<<22u)  	//IP_6
#define SET_PRIORITET_UART2_IRQ(X)    *((uint32_t*)(PR_IRQ4_7))|=(X<<30u) 	//IP_7

#define SET_PRIORITET_WWDG_IRQ(X)			*((uint32_t*)(PR_IRQ24_27))|=(X<<6u)	//IP_12

#define CLEAR_OTHER_IRQ  *((uint32_t*)(ICER_REG))=0xF7FE0F3F // 0xFFFE0F3F = 1111 0111 1111 1110 0000 1111 0011 1111, разрешены прерывания № 27,16,15,14,13,12,7,6.
////////////////////////////////////////////////////////////

////////////////////////////////////////////////
#define BIT0(x,y)  (uint8_t)((x&(~0xFE))<<y)
#define BIT1(x,y)  (uint8_t)(((x&(~0xFD))>>1)<<y)
#define BIT2(x,y)  (uint8_t)(((x&(~0xFB))>>2)<<y)
#define BIT3(x,y)  (uint8_t)(((x&(~0xF7))>>3)<<y)
#define BIT4(x,y)  (uint8_t)(((x&(~0xEF))>>4)<<y)
#define BIT5(x,y)  (uint8_t)(((x&(~0xDF))>>5)<<y)
#define BIT6(x,y)  (uint8_t)(((x&(~0xBF))>>6)<<y)
#define BIT7(x,y)  (uint8_t)(((x&(~0x7F))>>7)<<y)
///////////////////////////////////////////////


//включение/выключение разогрева на платах
#define WARM_MOTHER_ON  PORTA->CLRTX=(1U<<14U)//включается единицей (SETTX)
#define WARM_MOTHER_ON1 PORTC->CLRTX=(1U<<8U)
#define WARM_GETER_ON   PORTB->SETTX|=(1U<<8U)
#define WARM_KMV_ON     PORTA->CLRTX=(1U<<11U)
#define WARM_RT10_ON    PORTE->SETTX|=(1U<<1U)
#define WARM_RT9_ON 	  PORTD->SETTX|=(1U<<15U)
#define WARM_RT8_ON 	  PORTC->SETTX|=(1U<<11U)
#define WARM_RT7_ON 	  PORTD->SETTX|=(1U<<11U)
#define WARM_RT6_ON 	  PORTD->SETTX|=(1U<<9U)
#define WARM_RT5_ON 	  PORTD->SETTX|=(1U<<7U)
#define WARM_RT4_ON 	  PORTE->SETTX|=(1U<<6U)
#define WARM_RT3_ON 	  PORTE->SETTX|=(1U<<15U)
#define WARM_RT2_ON 	  PORTE->SETTX|=(1U<<13U)
#define WARM_RT1_ON 	  PORTE->SETTX|=(1U<<11U)

#define WARM_MOTHER_OFF PORTA->SETTX|=(1U<<14U)//выключается единицей (CLRTX)
#define WARM_MOTHER_OFF1 PORTC->SETTX|=(1U<<8U)
#define WARM_GETER_OFF  PORTB->CLRTX=(1U<<8U)
#define WARM_KMV_OFF    PORTA->SETTX|=(1U<<11U)
#define WARM_RT10_OFF   PORTE->CLRTX=(1U<<1U)
#define WARM_RT9_OFF 	  PORTD->CLRTX=(1U<<15U)
#define WARM_RT8_OFF 	  PORTC->CLRTX=(1U<<11U)
#define WARM_RT7_OFF 	  PORTD->CLRTX=(1U<<11U)
#define WARM_RT6_OFF 	  PORTD->CLRTX=(1U<<9U)
#define WARM_RT5_OFF 	  PORTD->CLRTX=(1U<<7U)
#define WARM_RT4_OFF 	  PORTE->CLRTX=(1U<<6U)
#define WARM_RT3_OFF 	  PORTE->CLRTX=(1U<<15U)
#define WARM_RT2_OFF 	  PORTE->CLRTX=(1U<<13U)
#define WARM_RT1_OFF 	  PORTE->CLRTX=(1U<<11U)
///////////////////////////////////////////////

//индикация светодиодов перегрева
#define TEMP_ERROR_MOTHER_ON  PORTF->SETTX|=(1U<<3U)//включается единицей (SETTX)
#define TEMP_ERROR_GETER_ON   PORTA->SETTX|=(1U<<13U)
#define TEMP_ERROR_KMV_ON     PORTE->SETTX|=(1U<<2U)
#define TEMP_ERROR_RT10_ON    PORTE->SETTX|=(1U<<0U)
#define TEMP_ERROR_RT9_ON 	  PORTC->SETTX|=(1U<<12U)
#define TEMP_ERROR_RT8_ON 	  PORTD->SETTX|=(1U<<12U)
#define TEMP_ERROR_RT7_ON 	  PORTD->SETTX|=(1U<<10U)
#define TEMP_ERROR_RT6_ON 	  PORTD->SETTX|=(1U<<8U)
#define TEMP_ERROR_RT5_ON 	  PORTE->SETTX|=(1U<<7U)
#define TEMP_ERROR_RT4_ON 	  PORTF->SETTX|=(1U<<2U)
#define TEMP_ERROR_RT3_ON 	  PORTE->SETTX|=(1U<<14U)
#define TEMP_ERROR_RT2_ON 	  PORTE->SETTX|=(1U<<12U)
#define TEMP_ERROR_RT1_ON 	  PORTE->SETTX|=(1U<<10U)

#define TEMP_ERROR_MOTHER_OFF PORTF->CLRTX=(1U<<3U)//выключается единицей (CLRTX)
#define TEMP_ERROR_GETER_OFF  PORTA->CLRTX=(1U<<13U)
#define TEMP_ERROR_KMV_OFF    PORTE->CLRTX=(1U<<2U)
#define TEMP_ERROR_RT10_OFF   PORTE->CLRTX=(1U<<0U)
#define TEMP_ERROR_RT9_OFF 	  PORTC->CLRTX=(1U<<12U)
#define TEMP_ERROR_RT8_OFF 	  PORTD->CLRTX=(1U<<12U)
#define TEMP_ERROR_RT7_OFF 	  PORTD->CLRTX=(1U<<10U)
#define TEMP_ERROR_RT6_OFF 	  PORTD->CLRTX=(1U<<8U)
#define TEMP_ERROR_RT5_OFF 	  PORTE->CLRTX=(1U<<7U)
#define TEMP_ERROR_RT4_OFF 	  PORTF->CLRTX=(1U<<2U)
#define TEMP_ERROR_RT3_OFF 	  PORTE->CLRTX=(1U<<14U)
#define TEMP_ERROR_RT2_OFF 	  PORTE->CLRTX=(1U<<12U)
#define TEMP_ERROR_RT1_OFF 	  PORTE->CLRTX=(1U<<10U)
/////////////////////////////////////////////////////

//индикация светодиодом БПВ "РАЗОГРЕВ"
#define LED_RAZOGREV_ON  PORTB->SETTX|=(1U<<11U)//включается единицей
#define LED_RAZOGREV_OFF PORTB->CLRTX=(1U<<11U)
////////////////////////////////////////////////

//управление ногой включения БПВ
#define BPV_TURN_ON  PORTB->CLRTX=(1U<<10U)//включается прибор нулём
#define BPV_TURN_OFF PORTB->SETTX|=(1U<<10U)
////////////////////////////////////////////

//управление ногой включения вентилятора
#define FAN_GATE_ON  PORTE->SETTX|=(1U<<3U)//включается единицей
#define FAN_GATE_OFF PORTE->CLRTX=(1U<<3U)
///////////////////////////////////////////

//дефайны для управления UART_1
#define START_UART1   				UART1->CR|=0x0001	//Разрешение работы приемопередатчика.
#define STOP_UART1    				UART1->CR&=0xFFFE	//Запрет работы приемопередатчика.

#define TRANSMITER_UART1_ON   UART1->CR|=0x0100	//Разрешение передачи.
#define TRANSMITER_UART1_OFF  UART1->CR&=0xFEFF	//Запрет передачи.
#define RECIVER_UART1_ON     	UART1->CR|=0x0200	//Разрешение приема.
#define RECIVER_UART1_OFF    	UART1->CR&=0xFDFF	//Запрет приема.

#define FLAG_REGISTR_UART1 UART1->FR						//чтение регистра флагов
#define READ_FLAG_REGISTR_UART1 UART1->FR				//чтение регистра флагов
#define APPARATNII_BUFFER_UART1 UART1->DR				//аппаратный буфер (чтение/запись)
#define REGISTR_MASK_INTERRUPT_UART1 UART1->MIS	//Регистр маскированного состояния прерываний MIS

#define CLEAR_UART1_OEIM  		UART1->IMSC|=0x0400 //Установить маску прерывания по переполнению буфера UARTOEINTR
#define SET_UART1_OEIM  			UART1->IMSC&=0xFBFF	//Сбросить маску прерывания по переполнению буфера UARTOEINTR
#define CLEAR_UART1_RTIM 			UART1->IMSC|=0x0040	//Установить маску прерывания по таймауту приема данных UARTRTINTR.
#define SET_UART1_RTIM 				UART1->IMSC&=0xFFBF	//Сбросить маску прерывания по таймауту приема данных UARTRTINTR.


#define OERIS_IRQ_ON  				(((UART1->MIS)&0x0400)==0x0400)
#define RTMIS_IRQ_ON  				(((UART1->MIS)&0x0040)==0x0040)

#define OERIS_IRQ_CLEAR  			UART1->ICR|=0x0400
#define RTMIS_IRQ_CLEAR  			UART1->ICR|=0x0040
////////////////////////////////////////////////

//дефайны для управления UART_2
#define START_UART2   				UART2->CR|=0x0001	//Разрешение работы приемопередатчика.
#define STOP_UART2    				UART2->CR&=0xFFFE	//Запрет работы приемопередатчика.

#define TRANSMITER_UART2_ON   UART2->CR|=0x0100	//Разрешение передачи.
#define TRANSMITER_UART2_OFF  UART2->CR&=0xFEFF	//Запрет передачи.
#define RECIVER_UART2_ON     	UART2->CR|=0x0200	//Разрешение приема.
#define RECIVER_UART2_OFF    	UART2->CR&=0xFDFF	//Запрет приема.

#define FLAG_REGISTR_UART2 UART2->FR						//регистр флагов
#define READ_FLAG_REGISTR_UART2 UART2->FR				//чтение регистра флагов
#define APPARATNII_BUFFER_UART2 UART2->DR				//аппаратный буфер (чтение/запись)
#define REGISTR_MASK_INTERRUPT_UART2 UART2->MIS	//Регистр маскированного состояния прерываний MIS

#define CLEAR_UART2_OEIM  		UART2->IMSC|=0x0400 //Установить маску прерывания по переполнению буфера UARTOEINTR
#define SET_UART2_OEIM  			UART2->IMSC&=0xFBFF	//Сбросить маску прерывания по переполнению буфера UARTOEINTR
#define CLEAR_UART2_RTIM 			UART2->IMSC|=0x0040	//Установить маску прерывания по таймауту приема данных UARTRTINTR.
#define SET_UART2_RTIM 				UART2->IMSC&=0xFFBF	//Сбросить маску прерывания по таймауту приема данных UARTRTINTR.


#define OERIS_IRQ2_ON  				(((UART2->MIS)&0x0400)==0x0400)
#define RTMIS_IRQ2_ON  				(((UART2->MIS)&0x0040)==0x0040)

#define OERIS_IRQ2_CLEAR  			UART2->ICR|=0x0400
#define RTMIS_IRQ2_CLEAR  			UART2->ICR|=0x0040
////////////////////////////////////////////////


#define SIZE_SIGNAL_EN_DELAY 16 
#define SIGNAL_ON_WORK {1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0}
#define SIGNAL_ON_RAZOGREV {0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1}
#define SIGNAL_ON_WORK_RAZOGREV {0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1}
#define	SIGNAL_ON_WORK_FAN_ON {1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0}
#define SIGNAL_ERROR_NO_FOUND_ADRES_1WIRE {1,1,1,1,1,1,0,0,1,0,0,0,0,0,0,0}
#define SIGNAL_ERROR_BUS_1WIRE {1,1,1,1,1,1,0,0,1,0,1,0,0,0,0,0}
#define SIGNAL_ERROR_PLATS_BPV {1,1,1,1,1,1,0,0,1,0,0,0,0,1,0,0}



typedef struct 
{
		uint8_t Signal_ON_WORK[SIZE_SIGNAL_EN_DELAY];
		uint8_t Signal_ON_RAZOGREV[SIZE_SIGNAL_EN_DELAY];
	  uint8_t Signal_ON_RAZ_WORK[SIZE_SIGNAL_EN_DELAY];
		uint8_t Signal_ON_WORK_FAN_ON[SIZE_SIGNAL_EN_DELAY];
		uint8_t Signal_Error_NO_Found_Adres_1WIRE[SIZE_SIGNAL_EN_DELAY];
	  uint8_t Signal_Error_BUS_1WIRE[SIZE_SIGNAL_EN_DELAY];
	  uint8_t Signal_Error_PLATS_BPV[SIZE_SIGNAL_EN_DELAY];
	  uint8_t flag_signal_error;
	  uint8_t count_signal;
	  uint8_t NumerERROR; 
	  uint8_t Cod_Signal;
}Signals_Alarm;
////////////////////////////////////////////////
extern Signals_Alarm signals_alarm;


extern uint8_t Minutes;
extern uint8_t Hours;
extern uint16_t Days;
extern uint8_t Years;
extern uint8_t Tpvkl_COS;

extern uint8_t StatusWork; //1 bit RAZOGREV (greem 1)/(no greem 0) 2 bit COS (rab 1)/(ne rab 0) 3 bit ventelator (rab 1)/(ne rab 0)
#define RAZOGREV_ON StatusWork|=0x01;
#define REOGREV_OFF StatusWork&=0xFE;
#define COS_ON  StatusWork|=0x02;
#define COS_OFF StatusWork&=0xFD;
#define FAN_ON StatusWork|=0x04;
#define FAN_OFF StatusWork&=0xFB;

extern uint8_t pxt;

#define NOOL (uint8_t*)(&pxt)

extern uint8_t  Transmit_in_progress_Uart1;//флаг "идёт передача"
extern uint8_t  Transmit_in_progress_Uart2;//флаг "идёт передача"
extern uint8_t  IndexMassivDataUart1;		  //флаг "текущий разряд программного буфера UART1"
extern uint8_t  IndexMassivDataUart2;		  //флаг "текущий разряд программного буфера UART2"
extern uint8_t  SizeReadByteUart;				  //размерность массива принимаемых данных
extern uint8_t  LastByteUart1Write;		  //последний переданный байт по UART1
extern uint8_t  LastByteUart2Write;			  //последний переданный байт по UART2

extern uint8_t  flag_sechas_pridut_konstanti;;//флаг

extern uint8_t  flag_izmeneniya_dlya_WatchDog;//флаг для отслеживания таймером 2 выполнения основного цикла программы
extern uint8_t  flag_proshloe_znachenie_WatchDog;
extern uint8_t  reset_timer;

extern int8_t pervaya_stroka[];
extern int8_t kontrolnaya_summa_pervaya_stroka;
extern int8_t vtoraya_stroka[]; 
extern int8_t kontrolnaya_summa_vtoraya_stroka;
extern uint8_t flag_vinujdennoy_peredachi_NMEA;
extern uint8_t Flag_razreshenie_otpravki_status;
extern uint8_t Flag_zapros_info_zinq;

void	hardware_init(void);
void	init_clock(void);
void	init_PORTs(void);
void	init_TIMER1(void);
void	init_TIMER2(void);
void	init_TIMER3(void);
void	init_TIMER4(void);

void  BkpInit(void);
void  WWDGInit(void);

void  InitUART1Interface(void);
void  InitUART2Interface(void);
void  send_data_uart_1(uint8_t *buffer1, uint32_t size_buffer1, uint8_t *buffer2, uint32_t size_buffer2, uint8_t *buffer3, uint32_t size_buffer3);
void  send_data_uart_1_NMEA(int8_t *stroka1, uint32_t size_stroka1, int8_t *stroka2, uint32_t size_stroka2);
int8_t spi_1_read_config(void);
void  WatchDog_change_flag(void);
void Correct_masive_temper(uint8_t BPV);
void zapisat_temperaturu_v_stroku(uint8_t Tuint8, int8_t *stroka, uint32_t poziciya);
void podgotovit_stroki_k_otpravke(void);
void UART_1_send_message_to_ZYNQ(void);

void wait_200ns(void);

#endif // GENERAL_HEADER_H

