#include <stdint.h>
#include "general_header.h"
#include "O1WireInterface.h"
#include <stdlib.h>
#include "temperature_pp.h"

uint8_t    hdb = 0; 
uint8_t    last_hdb = 0; 
uint8_t    indexBit = 0;  


uint8_t multirequest_micr_1wire=0u;
uint8_t reqiest_data_micr_1wire=0u;
uint8_t time_out_data_micr_1wire=0u;
uint8_t  MassivDataUart2[20]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
uint8_t kolvo_antenn=0;
uint8_t Addr1Wire[9][8];
uint16_t SummAdrr[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
uint8_t massiv_vseh_termodannih_AFU_MRL[8]={0,0,0,0,0,0,0,0};
uint8_t massiv_vseh_termodannih_AFU_BIS[5]={0,0,0,0,0};
uint8_t massiv_send_addrr[65];


/*********************************************/
void send_data_UART_2(uint8_t *buffer, uint32_t size_buffer)						 
{
  uint8_t  i=0;
	for(i=0;i<size_buffer;i++)
	{
			APPARATNII_BUFFER_UART2=buffer[i];
		  TRANSMITER_UART2_ON;
		  while((((FLAG_REGISTR_UART2)&0x0008)==0x0008));
		  wait_150ns(2000);
	}
	TRANSMITER_UART2_OFF;
	Transmit_in_progress_Uart2=0;
}

void wait_150ns(uint32_t n)								
{
	uint32_t i=0;
	uint32_t t=0;
	for(i=0;i<7;i++)
	{
		t+=n;
	}
	for(i=0;i<t;i++)
	{
	  ;
	}
	i=0;
}

uint8_t ComanndMode1Wire(void)
{
	 uint8_t buffer;
	 multirequest_micr_1wire=0;
	 ClearBufferUart2();
	 buffer=0xE3;
	 send_data_UART_2(&buffer,1);
	 return 0;
}

void SEND_IRQ_1WIRE(void)
{
	 uint32_t xt;
	 uint32_t xt1;
	 uint16_t xt2;
	 xt=PORTD->FUNC;
	 xt1&=0xF3FFFFFF;
   PORTD->FUNC=xt1;
	 PORTD->CLRTX=(1<<13u);
	 wait_150ns(20000);
	 PORTD->FUNC=xt;
}


uint8_t SendConfigDS240B(void)
{
	uint8_t flag=0;
	uint8_t countItrr=0;
	uint8_t i=0;
	uint8_t buffer[5]={0x17,0x45,0x5B,0x0F,0x91};
	uint8_t request[5]={0x16,0x44,0x5A,0x00,0x93};
	multirequest_micr_1wire=1;
	ClearBufferUart2();
  while(((reqiest_data_micr_1wire==0)||(IndexMassivDataUart2<0x05))&&(countItrr<3))
	{		
			if(flag==0)
			{
						 flag=1;
						 send_data_UART_2(buffer,5);
				     wait_150ns(20000);
						 TIMER3->CNTRL = 1; 
			}
			if(time_out_data_micr_1wire==1)
			{
						 flag=0;
						 countItrr++;
						 ClearBufferUart2();
						 time_out_data_micr_1wire=0;					 
			}	
	}
	TIMER3->CNTRL = 0;
	TIMER3->CNT = 0x0000;	
	time_out_data_micr_1wire=0;
	reqiest_data_micr_1wire=0;
	for(i=0;i<5;i++)
	{
		if(MassivDataUart2[i]!=request[i])
		{
			return 1;
		}
	}
	return 0;
}

uint8_t O1WIRE_BUS_RESET(void)
{
	uint8_t i=0;
	uint8_t buffer1=0xC1;
	ClearBufferUart2();
	SEND_IRQ_1WIRE();
	wait_150ns(80000);
  for(i=0;i<10;i++)
  {
		send_data_UART_2(&buffer1,1);
  }	
	wait_150ns(20000); 
	if((MassivDataUart2[0]&0xC0)==0xC0)
	{
		if((MassivDataUart2[0]&0x03)==0x03)
		{
			return 1; 
		}
	}
	else
	{
		 return 1;
	}
	return 0;
}


uint8_t CONFIG_DS2480B(void)
{
	uint8_t flag=0;
	uint8_t countItrr=0;
	uint8_t buffer=0xC1;
	uint8_t i=0;
	uint8_t k=0;
	uint16_t n=0;
	//SEND_IRQ_1WIRE();
	//wait_150ns(20000); //2��
	for(i=0;i<10;i++)
  {
		send_data_UART_2(&buffer,1);
	}
	ClearBufferUart2();
	wait_150ns(20000); //2��
	return SendConfigDS240B(); //���������� DS2480B - �������� 
}
	
void ClearBufferUart2(void)
{
	uint8_t i=0;
	for(i=0;i<20;i++)
	{
		MassivDataUart2[i]=0x00;
	}
	IndexMassivDataUart2=0;
}

uint8_t ReadSearchROMandStat(uint8_t *massiv_correct,uint8_t *addres_rom, uint8_t *massiv_correct_out)
{
	uint8_t buffer[25]={0xE3,0xC5,0xE1,0xF0,0xE3,0xB5,0xE1,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xE3,0xA5};
  uint8_t flag=0;
	uint8_t countItrr=0;
	uint8_t i=0;	
  uint8_t k=0;
	uint8_t t=0;
	uint8_t p=0;	
	for(i=0;i<16;i++)
  {
		buffer[i+7u]=massiv_correct[i];
	}	
	multirequest_micr_1wire=1;
	ClearBufferUart2();
	while(((reqiest_data_micr_1wire==0)||(IndexMassivDataUart2<18u))&&(countItrr<3))
	{
		  if(flag==0)
			{
						 flag=1;
						 send_data_UART_2(buffer,25);
						 TIMER3->CNTRL = 1; 	 
			}
			if(time_out_data_micr_1wire==1)
			{
						 flag=0;
						 countItrr++;
						 ClearBufferUart2();
						 time_out_data_micr_1wire=0;					 
			}	
	}
	TIMER3->CNTRL = 0;
	TIMER3->CNT = 0x0000;	
	time_out_data_micr_1wire=0;
	reqiest_data_micr_1wire=0;
		if(MassivDataUart2[1]==0xF0)
		{
			for(i=0;i<16;i++)
			{
				massiv_correct_out[i]=MassivDataUart2[i+2];
				if((massiv_correct_out[i]==0xFF)||(massiv_correct_out[i]==0x00))
				{
					 p++;
				}
				if(k==0)
				{
					k=1;
				}
				else
				{
					k=0;
					addres_rom[t]=BIT1(massiv_correct_out[i-1],0)+BIT3(massiv_correct_out[i-1],1)+BIT5(massiv_correct_out[i-1],2)+BIT7(massiv_correct_out[i-1],3);
					addres_rom[t]=addres_rom[t]+BIT1(massiv_correct_out[i],4)+BIT3(massiv_correct_out[i],5)+BIT5(massiv_correct_out[i],6)+BIT7(massiv_correct_out[i],7);
					t++;
				}
			}
		}
		else
		{
			return 1;
		}
		if(p==16)
		{
			return 1;
		}	
	return 0;
}


uint8_t serch_bit1wire(uint8_t *massiv_serch)
{
	 uint8_t massiv_result=0xFF;
	 uint8_t i=0;
	 uint8_t p=0;
	 uint8_t k=0;
	 uint8_t ROM_bit[128];//���� ������/���� ����������
	 for(k=0;k<16;k++) //��������� ������ �� 16 �������� �� ����
	 {
			ROM_bit[i+0]=BIT0(massiv_serch[k],0);
			ROM_bit[i+1]=BIT1(massiv_serch[k],0);
			ROM_bit[i+2]=BIT2(massiv_serch[k],0);
			ROM_bit[i+3]=BIT3(massiv_serch[k],0);
			ROM_bit[i+4]=BIT4(massiv_serch[k],0);
			ROM_bit[i+5]=BIT5(massiv_serch[k],0);
			ROM_bit[i+6]=BIT6(massiv_serch[k],0);
			ROM_bit[i+7]=BIT7(massiv_serch[k],0);
			i=i+8;
		}
	  for(i=0;i<128;i++)
		{				 
				if(p==0)//������ �� ������ 
				{
						if((ROM_bit[i]==1)&(ROM_bit[i+1]==0))
						{
								massiv_result=i+1;//����� ���������� ����, ��� ��������� �������� 
						}
						p=1u;
				}
				else
				{
						p=0;
				}
		}
		return massiv_result;
}

void set_bit1wire(uint8_t *massiv_resp, uint8_t *massiv_adrr, uint8_t posit_bit)
{
   uint8_t i=0;
	 uint8_t n=0;
	 uint8_t t=0;
   int8_t k=0;
   uint8_t integer_byte; 
   uint8_t integer_bit;
   for(i=0;i<16;i++)
	 {
			massiv_resp[i]=0;
	 }
    integer_byte=(uint8_t)(div((uint16_t)(posit_bit),(uint16_t)(8)).quot);
    integer_bit=(posit_bit-(integer_byte<<3));
		k=0;
		n=0;
		for(i=0;i<16;i++)
		{
			if(i<=integer_byte)
			{
				if(k==0)
				{
					massiv_resp[i]=BIT0(massiv_adrr[n],1)|BIT1(massiv_adrr[n],3)|BIT2(massiv_adrr[n],5)|BIT3(massiv_adrr[n],7);
					k=1;
				}
				else
				{
					massiv_resp[i]=BIT4(massiv_adrr[n],1)|BIT1(massiv_adrr[n],3)|BIT2(massiv_adrr[n],5)|BIT3(massiv_adrr[n],7);
					k=1;
					n++;
					k=0;
				}
			}
			else
			{
				massiv_resp[i]=0;
			}
			
		}
		massiv_resp[integer_byte]|=(1u<<integer_bit);
		k=~(((1<<((uint16_t)(8-integer_bit)))-1)<<(integer_bit+1));
		massiv_resp[integer_byte]&=k;
}

uint8_t GetTemperAFU(void)
{
    uint8_t ROM[16]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
		uint16_t i=0;
		int8_t k=0;
		uint8_t n=0;
		uint8_t schetAdrr=0;		
		uint8_t pos_bit1;
		uint8_t kolvo_adress=0;
		uint8_t max_antenn=0;
		for(i=0;i<8;i++) //�������� ������ � �����������, �� ��������� ����������� ������� -128(�� ������)
		{
			for(n=0;n<8;n++)
			{
				Addr1Wire[i][n]=0x00;
			}
			massiv_vseh_termodannih_AFU_MRL[i]=0x80;
			if(i<5)
			{
				massiv_vseh_termodannih_AFU_BIS[i]=0x80;
			}
		}			
	  if(flag_konfiguracii_BPV==0)//������������ ���������� ������ 8-��� 5-���
		{
				max_antenn=7;
		}
		else
		{
				max_antenn=4;
		}
		if((O1WIRE_BUS_RESET()==0x01))//�������� � ���������������� ���������� DS2480B
    {
			 return 1;
		 // �������� ����������� -128 � ������
		}
		while(1)
		{
			//����� �������������
			if((ReadSearchROMandStat(ROM,&Addr1Wire[schetAdrr][0],ROM)==1u)) //������� ������ ����� (1-��������)
		  {
				  return 1;
					// �������� ����������� -128 
			}
			pos_bit1=serch_bit1wire(ROM);//����� ���a ��������a(�����)
    	if(pos_bit1==0xFF)
			{
				break;
			}
			set_bit1wire(ROM,Addr1Wire[schetAdrr],pos_bit1);
			schetAdrr++;			
		}				
    kolvo_antenn=schetAdrr+1; //��������� ������ ��� �������� �������� � ���
		massiv_send_addrr[0]=kolvo_antenn;
    for(i=0;i<kolvo_antenn;i++)
	  {
			for(n=0;n<8;n++)
			{
				massiv_send_addrr[k]=Addr1Wire[i][n];
				k++;
			}
		}
		//����������� �����������
		if((O1WIRE_BUS_RESET()==0x01))
		{
				return 1;
		}
  	if(convert_temperature()==1)
	  {
    		return 1;
		}	
    //������� �������� ���������� 
		if((O1WIRE_BUS_RESET()==0x01))
		{
				return 1;
		}
		if(get_temperature()==1)
	  {
    		return 1;
		}		
	return 0;
}


uint8_t get_temperature(void)                               
{
    uint8_t i=0;
	  uint8_t err=0;
	  uint8_t temperature=0;
	  uint8_t k=0;
    uint8_t buffer[20]={0xE1,0x55,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xBE,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
	  uint8_t flag=0;
	  uint8_t countItrr=0;
		multirequest_micr_1wire=1;
	  ClearBufferUart2();		
		for(i=0;i<kolvo_antenn;i++)
		{
			for(k=0;k<8;k++)
			{
				buffer[2+k]=Addr1Wire[i][k];
			}
			while(((reqiest_data_micr_1wire==0)||(IndexMassivDataUart2<19u))&&(countItrr<3))
			{
					if(flag==0)
					{
							 flag=1;
							 send_data_UART_2(buffer,20);
							 TIMER3->CNTRL = 1; 	 
					}
					if(time_out_data_micr_1wire==1)
					{
							 flag=0;
							 countItrr++;
							 ClearBufferUart2();
							 time_out_data_micr_1wire=0;					 
					}	
			}
			TIMER3->CNTRL = 0;
			TIMER3->CNT = 0x0000;	
			time_out_data_micr_1wire=0;
			reqiest_data_micr_1wire=0;	
			if(MassivDataUart2[9]==0xBE)
			{
				 err=0;
				 if(MassivDataUart2[11]>0)
				 {
					 temperature=(~MassivDataUart2[10])>>1;
				 }
				 else
				 {
					 temperature=(MassivDataUart2[10])>>1;
				 }
				 if(flag_konfiguracii_BPV==0)
				 {
						massiv_vseh_termodannih_AFU_MRL[i]=temperature;
				 }
				 else
				 {
					 massiv_vseh_termodannih_AFU_BIS[i]=temperature;
				 }
			}
			else
			{
				err++;
				i--;//����� 1 ���;
			}
			O1WIRE_BUS_RESET();
			flag=0;
			countItrr=0;
			ClearBufferUart2();
      if(err==5)
		  {
				return 1;
			}
		}
}




uint8_t convert_temperature(void)                                      
{
	  uint8_t i;
	  uint8_t buffer[3]={0xE1,0xCC,0x44};
		uint8_t flag=0;
	  uint8_t countItrr=0;
		multirequest_micr_1wire=1;
	  ClearBufferUart2();
	  while(((reqiest_data_micr_1wire==0)||(IndexMassivDataUart2<2u))&&(countItrr<3))
	  {
				if(flag==0)
				{
						 flag=1;
						 send_data_UART_2(buffer,3);
					   wait_150ns(3700000);
						 TIMER3->CNTRL = 1; 	 
				}
				if(time_out_data_micr_1wire==1)
				{
						 flag=0;
						 countItrr++;
						 ClearBufferUart2();
						 time_out_data_micr_1wire=0;					 
				}	
		}
		TIMER3->CNTRL = 0;
	  TIMER3->CNT = 0x0000;	
	  time_out_data_micr_1wire=0;
	  reqiest_data_micr_1wire=0;
		if(MassivDataUart2[0]==0xCC)
		{
			if(MassivDataUart2[1]==0x44)
			{
				return 0;
			}
			else
			{
				return 1;
			}
		}
		else
		{
			return 1;
		}
	return 0;
}



