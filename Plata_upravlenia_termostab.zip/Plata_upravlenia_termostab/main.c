#include "general_header.h"
#include "temperature_pp.h"
#include "O1WireInterface.h"

	int8_t DATE[] = __DATE__;
	int8_t TIME[] = __TIME__;
  
#include <stdint.h>
#include <stdlib.h>
uint8_t pxt=0;
uint8_t flag_vinujdennoy_peredachi_ADDR_AFU=0;
uint8_t Flag_razreshenie_otpravki_status=1;
uint8_t Flag_zapros_info_zinq=0;
Signals_Alarm signals_alarm={SIGNAL_ON_WORK,SIGNAL_ON_RAZOGREV,SIGNAL_ON_WORK_RAZOGREV,SIGNAL_ON_WORK_FAN_ON,SIGNAL_ERROR_NO_FOUND_ADRES_1WIRE,SIGNAL_ERROR_BUS_1WIRE,SIGNAL_ERROR_PLATS_BPV,0,0,0,0};
uint8_t temperatura_COS[6]={0,0,0,0,0,0};
uint8_t temperatura_GT[2]={0,0};
uint8_t temperatura_MDM_KMV[2]={0,0};
uint8_t temperatura_RT_1[4]={0,0,0,0};
uint8_t temperatura_RT_2[4]={0,0,0,0};
uint8_t temperatura_RT_3[4]={0,0,0,0};
uint8_t temperatura_RT_4[4]={0,0,0,0};
uint8_t temperatura_RT_5[4]={0,0,0,0};
uint8_t temperatura_RT_6[4]={0,0,0,0};
uint8_t temperatura_RT_7[4]={0,0,0,0};
uint8_t temperatura_RT_8[4]={0,0,0,0};
uint8_t temperatura_RT_9[4]={0,0,0,0};
uint8_t temperatura_BKS[4]={0,0,0,0};
uint8_t StatusWork=0;
uint8_t ferst_init=0;
uint8_t upravlenie_temp=0;
uint8_t Minutes=0;
uint8_t Hours=0;
uint16_t Days=0;
uint8_t Years=0;
uint8_t  Transmit_in_progress_Uart1=0;//флаг "идёт передача"
uint8_t  Transmit_in_progress_Uart2=0;//флаг "идёт передача"
uint8_t  IndexMassivDataUart1=0;		  //флаг "текущий разряд программного буфера UART1"
uint8_t  IndexMassivDataUart2=0;		  //флаг "текущий разряд программного буфера UART2"
uint8_t  SizeReadByteUart=0;				  //размерность массива принимаемых данных
uint8_t  LastByteUart1Write=0;			  //последний переданный байт по UART1
uint8_t  LastByteUart2Write=0;			  //последний переданный байт по UART2
uint8_t  flag_sechas_pridut_konstanti=0;//флаг
uint8_t  flag_izmeneniya_dlya_WatchDog=0;//флаг для отслеживания таймером 2 выполнения основного цикла программы
uint8_t  flag_proshloe_znachenie_WatchDog=0;
uint8_t  reset_timer=0;
int8_t pervaya_stroka[]="$DIAGN Apr 23 2018 13:06:40; WORKING TIME: 00 YEARS, 000 DAYS, 00 HOURS, 00 MINUTES; BPV FOR BIS; BPV _ON; FAN _ON; FAN POWER _80%; RAZRESHENIE RABOTI VENTILYATORA:+00; MINIMALNII PEREGREV:+00; TEMPR VKL:+00; TERMOSTABILIZACIYA NIZ:+00; TERMOSTABILIZACIYA VERH:+00*FF VER 20.01.20";
int8_t kontrolnaya_summa_pervaya_stroka=0;
int8_t vtoraya_stroka[]="$TEMPR AFU:+00,+00,+00,+00,+00,+00,+00,+00; RT1:+00,+00; RT2:+00,+00; RT3:+00,+00; RT4:+00,+00; RT5:+00,+00; RT6:+00,+00; RT7:+00,+00; RT8:+00,+00; RT9:+00,+00; BKS:+00,+00; KMV:+00; GET:+00; COS:+00,+00,+00*FF";
int8_t kontrolnaya_summa_vtoraya_stroka=0;
uint8_t flag_vinujdennoy_peredachi_NMEA=0;
uint8_t massiv_vseh_termodannih_pp_BIS[17]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
uint8_t massiv_vseh_status_termodannih_pp_BIS[17]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
uint8_t massiv_vseh_termodannih_pp_BIS_CORECT[17]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
uint8_t massiv_vseh_termodannih_pp_MRL[25]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
uint8_t massiv_vseh_status_termodannih_pp_MRL[25]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
uint8_t massiv_vseh_termodannih_pp_MRL_CORECT[25]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
//константы
uint8_t tochka_razresheniya_raboti_ventilyatora=0x1F;	//точка разрешения работы вентилятора, равна +31 С
uint8_t tochka_minimalnogo_peregreva=0x1E;            //точка минимального перегрева, равна +30 С
uint8_t tochka_razresheniya_vklucheniya=0xEC;        	//точка разрешения включения прибора, равна -20 С
uint8_t tochka_termostabilizacii_niz=0x1D;            //нижняя достижения термостабилизации, равна +29 С
uint8_t tochka_termostabilizacii_verh=0x32;           //верхняя точка достижения термостабилизации, равна +33 С
//константы

uint8_t osnovnie_konstanti[5]={0,0,0,0,0};
uint8_t buffer_osnovnie_konstanti[5]={0,0,0,0,0};
uint8_t index_osnovnoy_konstanti=0;
uint8_t kontr_summa_buffer_osnovnie_konstanti=0;

uint8_t flag_ERROR=0;//1-есть ошибка, 0-нет ошибки

uint8_t  Tpp_min=0;
uint8_t  Tpp_max=0;
uint8_t  Tpp_average=0;
uint8_t  Tpvkl_COS=0;


uint8_t  moschnost_raboti_ventilyatora=20;           // !не обнуляется!

uint8_t sostoyaniya_nog_nPRSNT[13]={0,0,0,0,0,0,0,0,0,0,0,0,0}; // !не обнуляется!
uint8_t flag_konfiguracii_BPV=0;                                // !не обнуляется! 1-БИК СБИС-А, 0-ИК МРЛ-А
uint8_t flag_vklucheniya_BPV=0;                                 // !не обнуляется! 1-БПВ включен, 0-БПВ выключен
uint8_t flag_sostoyaniya_ventilyatora=0;                        //1-вентилятор включен, 0-вентилятор выключен
uint8_t flag_ventilyator_bil_v_rabote=0;                        // !не обнуляется! 1-вентилятор работал, 0-вентилятор отдыхал
uint8_t flag_razogreva[14]={0,0,0,0,0,0,0,0,0,0,0,0,0,0};         //1-разогрев осуществляется, 0-разогрева нет
uint8_t flag_LED_RAZOGREV=0;         														//1-светодиод горит, 0-светодиод не горит


	
int q=0;
int main()
{
	uint32_t irq_enable=0;	
	uint32_t min_old=0;
  int i;
	uint8_t TCosON=0;
	hardware_init();
	TIMER4->CNTRL=1; 
	RAZOGREV_ON;
	uznat_konfiguraciyu_BPV();
	//ДЛЯ ОТЛАДКИ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	//flag_konfiguracii_BPV=1;//для отладки!
	//ДЛЯ ОТЛАДКИ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	
	//VKLUCIT PRED RAZOGREV
 //-----------------------------	
 		
	WARM_MOTHER_ON;  
  WARM_MOTHER_ON1;
  WARM_GETER_ON; 
  WARM_KMV_ON;
	if(flag_konfiguracii_BPV==0)//MRL  
	{
     WARM_RT9_ON; 	  
     WARM_RT8_ON; 	 
     WARM_RT7_ON; 	 	
     WARM_RT6_ON; 	  	
	} 
	WARM_RT10_ON;   
  WARM_RT5_ON; 	 
  WARM_RT4_ON; 	  
  WARM_RT3_ON; 	 
  WARM_RT2_ON; 	  
  WARM_RT1_ON;
	wait_150ns(20000);
	
	
 //-----------------------------	
	while(1)
	{
		//flag_konfiguracii_BPV=0;
		obnulenie_peremennih();

		//ДЛЯ ОТЛАДКИ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		//TEMP_ERROR_RT1_ON;
		//TEMP_ERROR_RT2_ON;
		//TEMP_ERROR_RT3_ON;
		//TEMP_ERROR_RT4_ON;
		//TEMP_ERROR_RT5_ON;
		//wait_150ns(1000000);
		//ДЛЯ ОТЛАДКИ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		
		
		osnovnie_konstanti[0]=tochka_razresheniya_raboti_ventilyatora;
		osnovnie_konstanti[1]=tochka_minimalnogo_peregreva;		
		osnovnie_konstanti[2]=tochka_razresheniya_vklucheniya;		
		osnovnie_konstanti[3]=tochka_termostabilizacii_niz;		
		osnovnie_konstanti[4]=tochka_termostabilizacii_verh;		
		
		//vkluchit_BPV();
		//irq_enable=*((uint32_t*)(0xE000E100));
		//*((uint32_t*)(0xE000E180))=irq_enable;
    opros_termodatchikov_pp();     //опрос всех термодатчиков на всех печатных платах и забивание данных в соответствующие массивы и переменные


    //*((uint32_t*)(0xE000E100))=irq_enable;
		//ДЛЯ ОТЛАДКИ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		//Tpp_min=0xE1;
		//ДЛЯ ОТЛАДКИ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		if(((int8_t)(Tpvkl_COS)>=(int8_t)(-30))&&(TCosON==0))
    {
			tochka_razresheniya_raboti_ventilyatora=0x33;	//точка разрешения работы вентилятора, равна +51 С
			tochka_minimalnogo_peregreva=0x32;            //точка минимального перегрева, равна +50 С
			tochka_razresheniya_vklucheniya=0xEC;        	//точка разрешения включения прибора, равна -10 С
			tochka_termostabilizacii_niz=0x31;            //нижняя достижения термостабилизации, равна +49 С
			tochka_termostabilizacii_verh=0x3C;           //верхняя точка достижения термостабилизации, равна +60 С
		}			
		TCosON=1;
		
		
		
    if((int8_t)(Tpvkl_COS)>=(int8_t)(tochka_razresheniya_vklucheniya))    //проверка: наименьшее полученное значение с термодатчиков больше или меньше точки разрешения включения
    {
        vkluchit_BPV();
			  COS_ON
    }
    /////////////После вывода этого сигнала на внешний разъём (по доработке), нельзя подавать на него 3.3 В.
		//else
    //{
    //    vikluchit_BPV();
    //}

    vkluchit_razogrev_pp();         //включение разогрева на тех платах, где это необходимо

	
		
    vikluchit_razogrev_pp();        //выключение разогрева на тех платах, где это необходимо
		
	
		if(((int8_t)Tpp_average)<((int8_t)tochka_razresheniya_raboti_ventilyatora))    //если максимальная температура на печатных платах меньше точки минимального перегрева, выключить вентилятор
    {
        vikluchit_ventilyator();
			  FAN_OFF
    }
		else
		{
				vkluchit_ventilyator();
			  FAN_ON
		}
		
		
	  switch(StatusWork)
		{
					case 1: //razogrev
						signals_alarm.Cod_Signal=2u;
						break;
					case 2: //palta cos rab
						signals_alarm.Cod_Signal=1u;
						break;
					case 6: //fan+cos
						signals_alarm.Cod_Signal=4u;
						break;
					case 3: //razogrev+cos
						signals_alarm.Cod_Signal=3u;
						break;
		}
		
    if(flag_vklucheniya_BPV==1) //если БПВ включился, работаем с термодатчиками в АФУ и вентилятором
    {
			RECIVER_UART1_OFF;
      GetTemperAFU(); //опрос всех термодатчиков в антеннах и забивание данных в соответствующие массивы и переменные
			RECIVER_UART1_ON;
		}
		else
		{
			Flag_razreshenie_otpravki_status=1;
		}
			
		if(Minutes>=1)
		{
			 upravlenie_temp=0x01;
		}
		
		
		if(Flag_zapros_info_zinq==1)
		{
			min_old=Minutes;
			Flag_zapros_info_zinq=0;
		}
		if(Minutes>=min_old)
		{
			 if((Minutes-min_old)>3)
			 {
				   Flag_razreshenie_otpravki_status=1;
			 }
		}
		else
		{
			 if(((60-min_old)+Minutes)>3)
			 {
				  Flag_razreshenie_otpravki_status=1;
			 }
		}
		if(Flag_razreshenie_otpravki_status==1)
		{
			RECIVER_UART1_OFF;
			if(ferst_init==0)
			{
				ferst_init=0x01;
				flag_vinujdennoy_peredachi_NMEA=0x01;
				UART_1_send_message_to_ZYNQ(); 
			}
			UART_1_send_message_to_ZYNQ(); //отправить отчёт о температуре на ногу разъёма
			RECIVER_UART1_ON;
		}
		//ДЛЯ ОТЛАДКИ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		//UART_1_send_message_to_ZYNQ(); //отправить отчёт о температуре на ногу разъёма		
		//ДЛЯ ОТЛАДКИ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		q++;
	}
}


void led_blink_gen(void)
{
	uint8_t *pSignal;
	if(signals_alarm.flag_signal_error==1)
	{
		 signals_alarm.Cod_Signal=signals_alarm.NumerERROR;
	}
	if(signals_alarm.Cod_Signal>9)
	{
			switch(signals_alarm.Cod_Signal)
			{	
				case 10:
						pSignal=(uint8_t*)(signals_alarm.Signal_Error_NO_Found_Adres_1WIRE);
						break;
				case 11:
						pSignal=(uint8_t*)(signals_alarm.Signal_Error_BUS_1WIRE);
						break;
				case 12:
						pSignal=(uint8_t*)(signals_alarm.Signal_Error_PLATS_BPV);
						break;
			}
			signals_alarm.flag_signal_error=1;
			signals_alarm.NumerERROR=signals_alarm.Cod_Signal;
	}
	else
	{		
			switch(signals_alarm.Cod_Signal)
			{	
				case 1:
						pSignal=(uint8_t*)(signals_alarm.Signal_ON_WORK);
						break;
				case 2:
						pSignal=(uint8_t*)(signals_alarm.Signal_ON_RAZOGREV);
						break;
				case 3:
						pSignal=(uint8_t*)(signals_alarm.Signal_ON_RAZ_WORK);
						break;
				case 4:
					  pSignal=(uint8_t*)(signals_alarm.Signal_ON_WORK_FAN_ON);
						break;
			}
	}
		if(pSignal[signals_alarm.count_signal]==1)
		{
				LED_RAZOGREV_ON;
		}
		else
		{
				LED_RAZOGREV_OFF;
		}
		signals_alarm.count_signal++;
		if(signals_alarm.count_signal==SIZE_SIGNAL_EN_DELAY)
		{
			signals_alarm.count_signal=0;
		}
}


void TIMER1_Handler(void)	//обработчик прерывания по таймеру 1 (ВЕНТИЛЯТОР)
{
	//
	
	if(flag_ventilyator_bil_v_rabote==0)//если был цикл отдыха, сейчас цикл работы, значит нужно выставить единицу (включить вентилятор)
	{
		TIMER1->CNTRL = 0;//выключить таймер
		TIMER1->CNT = 0x0000;//начало счёта
		TIMER1->STATUS &= ~(1 << 1);//обнулить флаг совпадения CNT и ARR

		switch(moschnost_raboti_ventilyatora)
		{
			case 20:
				TIMER1->ARR = 0x30D4;//конец счёта, 0.2 сек
				break;
			case 40:
				TIMER1->ARR = 0x61A8;//конец счёта, 0.4 сек
				break;			
			case 60:
				TIMER1->ARR = 0x927C;//конец счёта, 0.6 сек
				break;			
			case 80:
				TIMER1->ARR = 0xC350;//конец счёта, 0.8 сек
				break;
			case 100:
				TIMER1->ARR = 0xF424;//конец счёта, 1 сек
				break;
		}
		flag_ventilyator_bil_v_rabote=1;
		FAN_GATE_ON;
		TIMER1->CNTRL=1;//включить таймер
		NVIC_ClearPendingIRQ(TIMER1_IRQn);//Clear pending interrupt
	}
	else																//если был цикл работы, сейчас цикл отдыха, значит нужно выставить ноль (выключить вентилятор)
	{
		TIMER1->CNTRL = 0;//выключить таймер
		TIMER1->CNT = 0x0000;//начало счёта
		TIMER1->STATUS &= ~(1 << 1);//обнулить флаг совпадения CNT и ARR

		switch(moschnost_raboti_ventilyatora)
		{
			case 20:
				TIMER1->ARR = 0xC350;//конец счёта, 0.8 сек	
				break;
			case 40:
				TIMER1->ARR = 0x927C;//конец счёта, 0.6 сек
				break;			
			case 60:
				TIMER1->ARR = 0x61A8;//конец счёта, 0.4 сек
				break;
			case 80:
				TIMER1->ARR = 0x30D4;//конец счёта, 0.2 сек
				break;
			case 100:
				TIMER1->ARR = 0xF424;//конец счёта, 1 сек
				break;
		}
		if(moschnost_raboti_ventilyatora!=100)
		{
			flag_ventilyator_bil_v_rabote=0;
			FAN_GATE_OFF;
			TIMER1->CNTRL=1;//включить таймер	
		}
		else
		{
			flag_ventilyator_bil_v_rabote=0;
			TIMER1->CNTRL=1;//включить таймер	
		}
		NVIC_ClearPendingIRQ(TIMER1_IRQn);//Clear pending interrupt
	}

}

void TIMER2_Handler(void)	//обработчик прерывания по таймеру 2 (проверка флага корректной работы)
{
	TIMER2->CNTRL = 0;//выключить таймер
	TIMER2->CNT = 0x0000;//начало счёта
	TIMER2->STATUS &= ~(1 << 1);//обнулить флаг совпадения CNT и ARR
	TIMER2->ARR = 0x7A12;//конец счёта, 0.5 сек

	//reset_timer++;//нужно удалить, вызывает интеррапт от ватчдога
	
	if(flag_izmeneniya_dlya_WatchDog==flag_proshloe_znachenie_WatchDog)
	{
		reset_timer++;
	}
	
	else
	{
		reset_timer=0;
	}

	if(reset_timer>0x3C)//таймер 2 заходит в обработчик каждые 0.5 сек, значит значение 120 (0x3C) в этом условии означает перезагрузку ватчдогом через 60 секунд бездействия
	{
		WWDG->CR |= (1 << 7); //Запустить сторожевой таймер и не сбрасывать его, таким образом РЕСЕТНУТЬ СИСТЕМУ С ПОМОЩЬЮ WWDG
	}
	
	if(flag_izmeneniya_dlya_WatchDog==0)//запишем текущее значение флага отслеживания в переменную, предназначенную для запоминания прошлого значения
	{
		flag_proshloe_znachenie_WatchDog=0;
	}
	else
	{
		flag_proshloe_znachenie_WatchDog=1;
	}
	TIMER2->CNTRL = 1;//включить таймер
	NVIC_ClearPendingIRQ(TIMER2_IRQn);//Clear pending interrupt
}


void init_TIMER3(void)		//таймер не привязанный аппаратно
{
	RST_CLK->TIM_CLOCK |= (6 << 16)|(1 << 26); //HCLK=64МГц, делим на 2^6 , итоговая частота 1 МГц; есть частота
	TIMER3->PSG = 0x2710;		//значение предделителя тактовой /0.0042 сек
	TIMER3->CNT = 0x0063;		//начало счёта
	TIMER3->ARR = 0x0001;		//конец счёта
  TIMER3->IE = (1 << 1);  //разрешение прерывания по событию совпадения CNT и ARR
  TIMER3->CNTRL = 0; 			//таймер выключен
	SET_PRIORITET_TIMER3_IRQ(2U);
	SET_IRQ(TIMER3_IRQn);
}

void TIMER3_Handler(void)	//обработчик прерывания по таймеру 
{
		TIMER3->CNTRL = 0;//выключить таймер
		TIMER3->CNT = 0x0000;//начало счёта
		TIMER3->STATUS &= ~(1 << 1);//обнулить флаг совпадения CNT и ARR
		NVIC_ClearPendingIRQ(TIMER3_IRQn);
	  time_out_data_micr_1wire=1;
}

void UART2_Handler(void)	//обработчик прерывания для UART2(работа с драйвером 1-WIRE) //раньше UART_2 отвечал за ZYNQ
{
	uint16_t data=0; 
	SizeReadByteUart=0;////
	if(((REGISTR_MASK_INTERRUPT_UART2)&0x0010)==0x0010) //если прерывание возникло по переполнению приёмника
	{
		data=APPARATNII_BUFFER_UART2;
		data&=0xFF;
    if(((data&0xF00)>>8)==0)//если пришёл 1 байт
 		{	 
			 
			 if(multirequest_micr_1wire==0)//однобайтный ответ
			 {
						switch(data)
						{
							case 0xCD://корректный ответ на RESET
								reqiest_data_micr_1wire=1;
								break;							
							case 0xED://корректный ответ на RESET
								 reqiest_data_micr_1wire=1;						
								break;
							case 0xF0://корректный ответ на SEARCH ROM
								reqiest_data_micr_1wire=1;
								break;
							case 0xCC://корректный ответ на SKIP ROM
								reqiest_data_micr_1wire=1;
								break;	
							case 0x44://корректный ответ на CONVERT TEMPERATURE
								reqiest_data_micr_1wire=1;
								break;		
							case 0x55://корректный ответ на MATCH ROM
								reqiest_data_micr_1wire=1;
								break;
							case 0x33://корректный ответ на READ ROM
							  reqiest_data_micr_1wire=1;
								break;	
							case 0xBE://корректный ответ на READ SCRATCHPAD
								reqiest_data_micr_1wire=1;
								break;
						}
						MassivDataUart2[IndexMassivDataUart2]=data;
						IndexMassivDataUart2++;
		   }
			 else //многобайтный ответ
			 {
				 MassivDataUart2[IndexMassivDataUart2]=data;
				 IndexMassivDataUart2++;
				 reqiest_data_micr_1wire=1;
			 }
		}
	}
	if((((REGISTR_MASK_INTERRUPT_UART2)&0x0040)==0x0040)) //прерывание по таймауту от приема
	{
		data=APPARATNII_BUFFER_UART2;
		IndexMassivDataUart2=0;
	}
  UART2->ICR|=0x07ff;	//сбросить все прерывания
  NVIC_ClearPendingIRQ(UART2_IRQn);//Clear pending interrupt
}

void InitUART2Interface(void) //функция инициализации интерфейса UART_2 (работа с драйвером 1-WIRE) //раньше UART_2 отвечал за ZYNQ
{
	RST_CLK->UART_CLOCK|=(1U<<25U);
		
	UART2->IBRD = 0x01A0; //установка скорости 9600 бит/с//416 целое
  UART2->FBRD = 0x002B; //установка скорости 9600 бит/с//43	дробное
	//416+(43/64)=416,672; 64000000/(416,672*16)=9599,88 бит/с
	UART2->LCR_H=
	(0<<0)|//открыть порт
	(0<<1)|//включить проверку четности
	(0<<2)|//бит четности дополняет количество единиц в информационной части кадра до нечетного, но НЕВАЖНО Т.К. бит чётности ОТКЛЮЧЕН!
	(0<<3)|//один стоповый бит
	(0<<4)|//выключить fifo приёмника/передатчика
	(3<<5)|//количество принимаемых/передоваемых бит 8
	(0<<7);//Передача бита четности с фиксированным значением запрещена
	UART2->IMSC&=0xF000;				//обнуление маской регистра установки сброса маски прерывания
	UART2->IMSC|=0x0050;				//Маска прерывания от передатчика UARTTXINTR
	UART2->IFLS&=0xFFC0;				//обнуление маской регистра порога прерывания по заполнению буфера FIFO
	UART2->IFLS|=(4<<0)|(0<<3);	//Порог прерывания по заполнению буфера передатчика: b100 = Буфер заполнен на 7/8; Порог прерывания по заполнению буфера приемника: b000 = Буфер заполнен на 1/8
	TRANSMITER_UART2_OFF;
	RECIVER_UART2_ON;	
	START_UART2;
	SET_IRQ(UART2_IRQn);
	SET_PRIORITET_UART2_IRQ(1U);
}

void TIMER4_Handler(void)
{
	  TIMER4->CNTRL = 0;//выключить таймер
		TIMER4->CNT = 0x0000;//начало счёта
		TIMER4->STATUS &= ~(1 << 1);//обнулить флаг совпадения CNT и ARR
		TIMER4->ARR = 0x3D09;//конец счёта, 0.5 сек	
		TIMER4->CNTRL=1;//включить таймер
		NVIC_ClearPendingIRQ(TIMER4_IRQn);//Clear pending interrupt
	  if(signals_alarm.Cod_Signal!=0)
		{
			led_blink_gen();
		}
}
void UART1_Handler(void)	//обработчик прерывания для UART1(работа с ZYNQ) //раньше UART_1 отвечал за 1-WIRE
{	
	uint16_t data=0; 

	if(((REGISTR_MASK_INTERRUPT_UART1)&0x0010)==0x0010) //если прерывание возникло по переполнению приёмника
	{
		data=APPARATNII_BUFFER_UART1; 
    if(((data&0xF00)>>8)==0)
 		{	
			switch(IndexMassivDataUart1)
			{
				case 0:
					if(data==0xFE)
					{
						IndexMassivDataUart1++;
					}
					else
					{
						if(flag_sechas_pridut_konstanti==0)//если не ждём констант
						{
							IndexMassivDataUart1=0;
						}
						else//алгоритм забивания констант, принятых от ZYNQа
						{
							if(index_osnovnoy_konstanti<5)//если пришли ещё не все константы
							{
								buffer_osnovnie_konstanti[index_osnovnoy_konstanti]=data;
								index_osnovnoy_konstanti++;
							}
							else//когда пришли все константы, надо проверить контрольную сумму
							{
								flag_sechas_pridut_konstanti=0;
								index_osnovnoy_konstanti=0;
								kontr_summa_buffer_osnovnie_konstanti=buffer_osnovnie_konstanti[0]^buffer_osnovnie_konstanti[1]^buffer_osnovnie_konstanti[2]^buffer_osnovnie_konstanti[3]^buffer_osnovnie_konstanti[4];
								if(data==kontr_summa_buffer_osnovnie_konstanti)//если сошлась контрольная сумма буфера констант, пишем их в нужные переменные
								{
									tochka_razresheniya_raboti_ventilyatora=buffer_osnovnie_konstanti[0];
									tochka_minimalnogo_peregreva=buffer_osnovnie_konstanti[1];
									tochka_razresheniya_vklucheniya=buffer_osnovnie_konstanti[2];
									tochka_termostabilizacii_niz=buffer_osnovnie_konstanti[3];
									tochka_termostabilizacii_verh=buffer_osnovnie_konstanti[4];
								} 
								else
								{
									;//не делаем ничего, т.к. контрольная сумма не совпала
								}
							}
						}
					}
					break;
				case 1:
					if(data==0x7F)
					{
						IndexMassivDataUart1++;
					}
					else
					{
						IndexMassivDataUart1=0;
					}
					break;
				case 2:	
					switch(data)
					{
						case 0x00://всё хорошо
							Flag_razreshenie_otpravki_status=0;
						  Flag_zapros_info_zinq=1;
							break;
						case 0x0F://нужна повторная посылка
							UART_1_send_message_to_ZYNQ();
						  Flag_razreshenie_otpravki_status=0;
						  Flag_zapros_info_zinq=1;
							break;
						case 0xF0://контрольная сумма не совпала
							UART_1_send_message_to_ZYNQ();
						  Flag_razreshenie_otpravki_status=0;
						  Flag_zapros_info_zinq=1;
							break;
						case 0xFF://нужна повторная посылка и контрольная сумма не совпала
							UART_1_send_message_to_ZYNQ();
						  Flag_razreshenie_otpravki_status=0;
							Flag_zapros_info_zinq=1;
							break;
						case 0x55://Команда на ресет системы (включая плату управления)
							WWDG->CR |= (1 << 7); //Запустить сторожевой таймер и не сбрасывать его, таким образом РЕСЕТНУТЬ СИСТЕМУ С ПОМОЩЬЮ WWDG
						  break;						
						case 0xAA://команда на переназначение основных констант
							flag_sechas_pridut_konstanti=1;
						  Flag_zapros_info_zinq=1;
							break;
						case 0x4F:
							flag_sechas_pridut_konstanti=0;
						  Flag_zapros_info_zinq=1;
						  flag_vinujdennoy_peredachi_ADDR_AFU=1;
						  UART_1_send_message_to_ZYNQ();
						  flag_vinujdennoy_peredachi_ADDR_AFU=0;
							break;
						case 0xBB://команда на отправку NMEA строки
							flag_vinujdennoy_peredachi_NMEA=1;
							UART_1_send_message_to_ZYNQ();
						  flag_sechas_pridut_konstanti=0;
						  Flag_zapros_info_zinq=1;
							break;
					}
					IndexMassivDataUart1=0;
					break;
				default:
					IndexMassivDataUart1=0;
					break;	
			}
		}	
	}
	if((((REGISTR_MASK_INTERRUPT_UART1)&0x0040)==0x0040)) //прерывание по таймауту от приема
	{
		data=APPARATNII_BUFFER_UART1;
		IndexMassivDataUart1=0;
	}
  UART1->ICR|=0x07ff;	//сбросить все прерывания
  NVIC_ClearPendingIRQ(UART1_IRQn);//Clear pending interrupt
}



void BKP_Handler(void)		//обработчик прерывания для часов реального времени
{
	BKP->RTC_CS &= ~(1 << 2);//обнулить флаг совпадения CNT и RTC_ALRM
	while((BKP->RTC_CS&(1<<6)) != 0);		//wait until write data in RTC
	BKP->RTC_CS &= ~(1 << 5);//обнулить флаг разрешения совпадения CNT и RTC_ALRM
	while((BKP->RTC_CS&(1<<6)) != 0);		//wait until write data in RTC
	
	Minutes++;
	if(Minutes>=60)
	{
		Minutes=0;
		Hours++;
	}
	if(Hours>=24)
	{
		Hours=0;
		Days++;
	}
	if(Days>=365)
	{
		Days=0;
		Years++;
	}

	BKP->RTC_CNT=0x00000000;//обнулить значение основного счетчика часов реального времени
	while((BKP->RTC_CS&(1<<6)) != 0);		//wait until write data in RTC
	
	BKP->RTC_CS |= (1 << 5);//разрешить прерывание по совпадению CNT и RTC_ALRM
	while((BKP->RTC_CS&(1<<6)) != 0);		//wait until write data in RTC	
	
	NVIC_ClearPendingIRQ(BKP_IRQn);//Clear pending interrupt
}

void WWDG_Handler(void)		//обработчик прерывания для оконного WatchDog
{
	q++;//
}

void hardware_init(void)	//функция полной инициализации МК 1986ВЕ1Т
{
	init_clock();
	
	CLEAR_OTHER_IRQ;
	
	init_PORTs();
	
	init_TIMER1();
	
//	init_TIMER2();
	
	init_TIMER3();
	
	init_TIMER4();
	
	InitUART1Interface();

	InitUART2Interface();
	
	BkpInit();
	
	WWDGInit();
	
}

void init_clock(void)		  //функция инициализации тактирования МК и его переферии
{
	uint32_t temp;
	
	RST_CLK->PER_CLOCK |= (1U << 27U);	//включить тактирование блока BKP (регистры блока батарейного домена)
	temp = BKP->REG_0E;	//скопировать текущее значение
	temp &= 0xFFFFFFC0;	//наложить маску, выставив в младших битах 5:0 нули
	BKP->REG_0E = temp | (6U << 3U) | (6U << 0U);  // тактовая до 80 МГц
	RST_CLK->HS_CONTROL=0x00000005;  // НSE вкл, НSE2 вкл
	while((RST_CLK->CLOCK_STATUS&0x0C)!=0x0C); // дождаться выхода осиляторов НSE и НSE2 в рабочий режим (осциллятор запущен и стабилен)
	RST_CLK->CPU_CLOCK=0x00000002; //описание:	источник для HCLK(частота процессора) - HSI (8 МГц); делитель для CPU_C3 - CPU_C2; источник для CPU_C2 - CPU_C1; источник для CPU_C1 - HSE (8 МГц).
	RST_CLK->PLL_CONTROL=(7<<8)|(1<<2); //(7<<8) - PLLCPUo=CPU_C1*8=64 МГц, PLL_CPU вкл
	while((RST_CLK->CLOCK_STATUS&0x02)!=0x02); //дождаться выхода Фапч в работу
	RST_CLK->PER_CLOCK|=0x08; // вкл  тактову на EEPROM_CNTRL
	EEPROM->CMD=3<<3; // // задержка три цикла
	RST_CLK->PER_CLOCK&=(~0x08);// отключить тактовую на EEPROM_CNTRL
	RST_CLK->CPU_CLOCK|=0x00000106; //описание:	источник для HCLK(частота процессора) - CPU_C3 (64 МГц); делитель для CPU_C3 - CPU_C2; источник для CPU_C2 - PLLCPUo; источник для CPU_C1 - HSE (8 МГц).
	
	
	RST_CLK->PER_CLOCK |=(1U<<6U);	//разрешено тактирование UART_1		
	RST_CLK->PER_CLOCK |=(1U<<7U);	//разрешено тактирование UART_2
	RST_CLK->PER_CLOCK |=(1U<<14U);	//разрешено тактирование TIMER1
	RST_CLK->PER_CLOCK |=(1U<<15U);	//разрешено тактирование TIMER2	
	RST_CLK->PER_CLOCK |=(1U<<16U);	//разрешено тактирование TIMER3	
	RST_CLK->PER_CLOCK |=(1U<<19U);	//разрешено тактирование TIMER4
	RST_CLK->PER_CLOCK |=(1U<<21U);	//разрешено тактирование PORTA
	RST_CLK->PER_CLOCK |=(1U<<22U);	//разрешено тактирование PORTB
	RST_CLK->PER_CLOCK |=(1U<<23U);	//разрешено тактирование PORTC
	RST_CLK->PER_CLOCK |=(1U<<24U);	//разрешено тактирование PORTD
	RST_CLK->PER_CLOCK |=(1U<<25U);	//разрешено тактирование PORTE
	RST_CLK->PER_CLOCK |=(1U<<29U);	//разрешено тактирование PORTF
	RST_CLK->PER_CLOCK |=(1U<<27U);	//разрешено тактирование BKP
	
	RST_CLK->PER_CLOCK |=(1U<<12U);	//разрешено тактирование WWDT

}

void BkpInit(void)				//функция инициализации блока батарейного домена и часов реального времени
{
		BKP->REG_0F |= 0x801E8000;				//Reset RTC, select LSI for clocking RTC, LSI TRIM=31, LSI On
		BKP->REG_0F &= 0x7FFFFFFF;				//Сброс часов реального времени, 0 – часы не сбрасываются

		while((BKP->REG_0F&(1<<21)) != (1<<21));	//wait until LSI not ready

		while((BKP->RTC_CS&(1<<6)) != 0);	//wait until write data in RTC
		BKP->RTC_PRL = 0x00008000;				//RTC div - 32768
		
		while((BKP->RTC_CS&(1<<6)) != 0);	//wait until write data in RTC
		BKP->REG_0F |= 0x00000010;				//RTC enable

		while((BKP->RTC_CS&(1<<6)) != 0);	//wait until write data in RTC
		BKP->RTC_ALRM = 0x0000003C;				//

		while((BKP->RTC_CS&(1<<6)) != 0);	//wait until write data in RTC
		BKP->RTC_CS = 0x00000020;					//interrupt enable
	
	
	SET_PRIORITET_BKP_IRQ(3U);
	SET_IRQ(BKP_IRQn);
}

void WWDGInit(void)				//функция инициализации 
{
	//WWDG->CR &=(unsigned short)(~(1U<<7U));	//сторожевой таймер отключен
	WWDG->CR |= 0x7F;												//значение 7-разрядного счётчика (127)
	WWDG->CFR |= (1 << 7)|(1 << 8);					//делитель частоты сторожевого таймера=(64МГц/4096)/8=1,953 кГц
	WWDG->CFR |= 0x7F;											//значение 7-разрядного окна (127)
	
}
void init_PORTs(void)		  //Функция инициализация портов ввода/вывода для конфигурации МК
{	 	
//Описание регистров портов ввода/вывода
//_RXTX - Данные для выдачи на выводы порта и для чтения. Фактически если нога на выход, логическая единица - 1, логический ноль - 0.
//_OE - Направление передачи данных на выводах порта. 1 – выход, 0 – вход
//_ANALOG - Режим работы выводов порта (аналоговый/цифровой). 0 – аналоговый, 1 – цифровой.
//_FUNC - Режим работы вывода порта. 00 – порт, 01 – основная функция, 10 – альтернативная функция, 11 – переопределенная функция. Подробнее в таблице 2 в даташите.
//_PWR - Режим мощности передатчика. 00 – зарезервировано, 01 – медленный фронт, 10 – быстрый фронт, 11 – максимально быстрый фронт
//_PULL - Разрешение подтяжки вверх/вниз. 0 – подтяжки нет, 1 – подтяжка есть.

//PORT_A
	PORTA->OE=0xFD40;				//всё на выход, кроме разрядов 9,7,5,4,3,2,1,0
	PORTA->ANALOG=0xFFFF;		//все цифровые
	PORTA->PWR=0xFFFFFFFF;	//максимально быстрый фронт
	PORTA->FUNC=0x00000000;	//все как порты
	PORTA->RXTX=0x1540;			//все нули, кроме разрядов 6,8,10,12 (CLK SPI)

	PORTA->PULL=0x000002B8;
//PORT_B	
	PORTB->OE=0xFFFF;				//всё на выход, но есть разряды, которые потом будут работать как bidirectional (14,5,0)
	PORTB->ANALOG=0xFFFF;		//все цифровые
	PORTB->PWR=0xFFFFFFFF;	//максимально быстрый фронт
	PORTB->FUNC=0x00000000;	//все как порты
	PORTB->RXTX=0x0454;			//все нули, кроме разряда 10, который отвечает за включение/выключение БПВ (1-сток-истоковый переход открыт, значит источник выключен) и разрядов 2,4,6 (CLK SPI)
	
	PORTB->PULL=0x00004021;	
//PORT_C	
  PORTC->OE=0xFD0F;				//всё на выход, кроме разрядов 9,8,7,6,5,4
	PORTC->ANALOG=0xFFFF;		//все цифровые
	PORTC->PWR=0xFFFFFFFF;	//максимально быстрый фронт
	PORTC->FUNC=0x00000140;	//все как порты, кроме разрядов 4,3. Эти разряды будут работать как UART1
	PORTC->RXTX=0x0000;			//все нули. разряд 10 служит ключом для цепи 1-WIRE. опторелле нормальнозамкнуто, значит 0 означает прохождение сигнала 1-WIRE
	
	PORTC->PULL=0x000003E0;		
//PORT_D
	PORTD->OE=0xBFFD;				//всё на выход, кроме разрядов 14,1. Разряд 2 будет работать как bidirectional
	PORTD->ANALOG=0xFFFF;		//все цифровые
	PORTD->PWR=0xFFFFFFFF;	//максимально быстрый фронт
	PORTD->FUNC=0x14000000;	//все как порты, кроме разрядов 14,13. Эти разряды будут работать как UART2
	PORTD->RXTX=0x0000;			//все нули
	
	PORTD->PULL=0x00004006;		
//PORT_E
	PORTE->OE=0xFCCF;				//всё на выход, кроме разрядов 9,8,5,4.
	PORTE->ANALOG=0xFFFF;		//все цифровые
	PORTE->PWR=0xFFFFFFFF;	//максимально быстрый фронт
	PORTE->FUNC=0x00000000;	//все как порты
	PORTE->RXTX=0x0000;			//все нули, 3-ий разряд управляет вентилятором
	
	PORTE->PULL=0x00000330;	
//PORT_F
	PORTF->OE=0xBBEE;				//всё на выход, кроме разрядов 14,10,4,0. 0 разряд аналоговый OSC_25_IN. Разряды 15,11,5 будут работать как bidirectional
	PORTF->ANALOG=0xFFFC;		//все цифровые, кроме 1 и 0 разрядов. OSC_OUT25 и OSC_IN25 соответственно
	PORTF->PWR=0xFFFFFFFF;	//максимально быстрый фронт
	PORTF->FUNC=0x00000000; //все как порты		!!!НЕ ЗНАЮ ЧТО СЛУЧИТСЯ С OSC_OUT25 и OSC_IN25!!!
	PORTF->RXTX=0x0000;			//все нули
	
	PORTF->PULL=0x0000CC31;		
	
}

void init_TIMER1(void)		//таймер для псевдоШИМ
{
	RST_CLK->TIM_CLOCK |= (0U << 0)|(1 << 24); //HCLK=64МГц, делим на 2^8 , итоговая частота 250 КГц; есть частота
	TIMER1->PSG = 0x00FF;		//значение предделителя тактовой (255+1)
	TIMER1->CNT = 0x0000;		//начало счёта
	TIMER1->ARR = 0x30D4;		//конец счёта (эквивалент 0.2 сек или 20% мощности)
	//20%=0x30D4
	//40%=0x61A8
	//60%=0x927C
	//80%=0xC350
	//100%=0xF424	
  TIMER1->IE = (1 << 1);  //разрешение прерывания по событию совпадения CNT и ARR
  TIMER1->CNTRL = 0; 			//таймер выключен
	SET_PRIORITET_TIMER1_IRQ(2U);
	SET_IRQ(TIMER1_IRQn);
}

void init_TIMER2(void)		//таймер для проверки флага корректной работы. сопряжён в работе с WatchDog'ом
{
	RST_CLK->TIM_CLOCK |= (0U << 8)|(1 << 25); 
	//HCLK=64МГц, делим на 2^10 , итоговая частота 62,5 КГц; есть частота
	TIMER2->PSG = 0x03FF;		//значение предделителя тактовой (1023+1)
	TIMER2->CNT = 0x0000;		//начало счёта
	TIMER2->ARR = 0x7A12;		//конец счёта (31250 - эквивалентно 0.5 сек при тактовой 62500 Гц)
  TIMER2->IE = (1 << 1);  //разрешение прерывания по событию совпадения CNT и ARR
  TIMER2->CNTRL = 0; 			//таймер выключен
	SET_PRIORITET_TIMER2_IRQ(2U);
	SET_IRQ(TIMER2_IRQn);
}


void init_TIMER4(void)		//таймер для светодиода "разогрев"
{
	RST_CLK->UART_CLOCK |= (0U << 16)|(1 << 26);
	//HCLK=64МГц, делим на 2^10 , итоговая частота 62,5 КГц; есть частота
	TIMER4->PSG = 0x03FF;		//значение предделителя тактовой (1023+1)
	TIMER4->CNT = 0x0000;		//начало счёта
	TIMER4->ARR = 0x7A12;		//конец счёта
  TIMER4->IE = (1 << 1);  //разрешение прерывания по событию совпадения CNT и ARR
  TIMER4->CNTRL = 0; 			//таймер выключен
	SET_PRIORITET_TIMER4_IRQ(2U);	
	SET_IRQ(TIMER4_IRQn);
}

void InitUART1Interface(void) //функция инициализации интерфейса UART_1(работа с ZYNQ) //раньше UART_1 отвечал за 1-WIRE
{
  RST_CLK->UART_CLOCK|=(1U<<24U);
	
	UART1->IBRD = 0x00D0; //установка скорости 19200 бит/с//208 целое
  UART1->FBRD = 0x0015; //установка скорости 19200 бит/с//21	дробное
	//208+(21/64)=208,328; 64000000/(208,328125*16)=19200,48 бит/с
	UART1->LCR_H=
	(0<<0)|//открыть порт
	(0<<1)|//включить проверку четности
	(0<<2)|//бит четности дополняет количество единиц в информационной части кадра до нечетного, но НЕВАЖНО Т.К. бит чётности ОТКЛЮЧЕН!
	(0<<3)|//один стоповый бит
	(0<<4)|//выключить fifo приёмника/передатчика
	(1<<5)|//количество принимаемых/передоваемых бит 8
	(1<<6)|//количество принимаемых/передоваемых бит 8	
	(0<<7);//Передача бита четности с фиксированным значением запрещена
	UART1->IMSC&=0xF000;				//обнуление маской регистра установки сброса маски прерывания
	UART1->IMSC|=0x0050;				//Маска прерывания от передатчика UARTTXINTR
	UART1->IFLS&=0xFFC0;				//обнуление маской регистра порога прерывания по заполнению буфера FIFO
	UART1->IFLS|=(4<<0)|(0<<3);	//Порог прерывания по заполнению буфера передатчика: b100 = Буфер заполнен на 7/8; Порог прерывания по заполнению буфера приемника: b000 = Буфер заполнен на 1/8
	//UART1->CR|=0x0201;//разрешить работу приемопередатчика (UARTEN) и разрешить прием (RXE).		
	SET_IRQ(UART1_IRQn);
	SET_PRIORITET_UART1_IRQ(0U);
	TRANSMITER_UART1_OFF;
	RECIVER_UART1_ON;
	START_UART1;
}

void send_data_UART_1(uint8_t *buffer1, uint32_t size_buffer1, uint8_t *buffer2, uint32_t size_buffer2, uint8_t *buffer3, uint32_t size_buffer3)//функция отправки данных по UART_1 (работа с ZYNQ)
{
															//WatchDog_change_flag();
	LastByteUart1Write=buffer2[size_buffer2-1]; //записать последний переданый байт в переменную
  //uint16_t  status;	
  uint32_t  i;
	int8_t kontrolnaya_summa=0;
	
	//вычисление контрольной суммы (XOR)
	for(i=0;i<size_buffer1;i++)
	{
		if(i==0)
		{
			kontrolnaya_summa=buffer1[i];
		}
		else
		{
			kontrolnaya_summa=kontrolnaya_summa^buffer1[i];
		}
	}
	for(i=0;i<size_buffer2;i++)
	{
		kontrolnaya_summa=kontrolnaya_summa^buffer2[i];
	}
	for(i=0;i<size_buffer3;i++)
	{
		kontrolnaya_summa=kontrolnaya_summa^buffer3[i];
	}
	//вычисление контрольной суммы (XOR) закончено


	Transmit_in_progress_Uart1=1;//флаг работы передатчика

	APPARATNII_BUFFER_UART1=0xFE;//старт байт
	TRANSMITER_UART1_ON;
	while(((FLAG_REGISTR_UART1)&0x0008)==0x0008);//ожидание освобождения линии; проверка на флаг BUSY
	TRANSMITER_UART1_OFF;
	APPARATNII_BUFFER_UART1=0x7F;//признак старт байта (чтобы не перепутать)
  TRANSMITER_UART1_ON;
	while(((FLAG_REGISTR_UART1)&0x0008)==0x0008);//ожидание освобождения линии; проверка на флаг BUSY
	TRANSMITER_UART1_OFF;
	for(i=0;i<size_buffer1;i++)
	{
		APPARATNII_BUFFER_UART1=buffer1[i];//отправляем побайтно начиная с младшего
		TRANSMITER_UART1_ON;
		while(((FLAG_REGISTR_UART1)&0x0008)==0x0008);//ожидание освобождения линии; проверка на флаг BUSY
		TRANSMITER_UART1_OFF;
	}
	for(i=0;i<size_buffer2;i++)
	{
		APPARATNII_BUFFER_UART1=buffer2[i];//отправляем побайтно начиная с младшего
		TRANSMITER_UART1_ON;
		while(((FLAG_REGISTR_UART1)&0x0008)==0x0008);//ожидание освобождения линии; проверка на флаг BUSY
		TRANSMITER_UART1_OFF;
	}
	for(i=0;i<size_buffer3;i++)
	{
		APPARATNII_BUFFER_UART1=buffer3[i];//отправляем побайтно начиная с младшего
		TRANSMITER_UART1_ON;
		while(((FLAG_REGISTR_UART1)&0x0008)==0x0008);//ожидание освобождения линии; проверка на флаг BUSY
		TRANSMITER_UART1_OFF;
	}	
	APPARATNII_BUFFER_UART1=kontrolnaya_summa;
	TRANSMITER_UART1_ON;
	while(((FLAG_REGISTR_UART1)&0x0008)==0x0008);//ожидание освобождения линии; проверка на флаг BUSY
  TRANSMITER_UART1_OFF;
	Transmit_in_progress_Uart1=0;//флаг работы передатчика
	//WatchDog_change_flag();
}

void send_data_UART_1_NMEA(int8_t *stroka1, uint32_t size_stroka1, int8_t *stroka2, uint32_t size_stroka2)//функция отправки данных по UART_1 (работа с ZYNQ) в формате NMEA строки
{
															//WatchDog_change_flag();
	LastByteUart1Write=stroka2[size_stroka2-1]; //записать последний переданый байт в переменную
  //uint16_t  status;	
  uint32_t  i;
	Transmit_in_progress_Uart1=1;//флаг работы передатчика
	for(i=0;i<size_stroka1;i++)
	{
		APPARATNII_BUFFER_UART1=stroka1[i];//отправляем побайтно начиная с младшего
    TRANSMITER_UART1_ON;
		while(((FLAG_REGISTR_UART1)&0x0008)==0x0008);//ожидание освобождения линии; проверка на флаг BUSY
		TRANSMITER_UART1_OFF;
	}	
	APPARATNII_BUFFER_UART1=0x0A;//отправляем побайтно начиная с младшего
	TRANSMITER_UART1_ON;
	while(((FLAG_REGISTR_UART1)&0x0008)==0x0008);//ожидание освобождения линии; проверка на флаг BUSY	
	TRANSMITER_UART1_OFF;
	for(i=0;i<size_stroka2;i++)
	{
		APPARATNII_BUFFER_UART1=stroka2[i];//отправляем побайтно начиная с младшего
		TRANSMITER_UART1_ON;
		while(((FLAG_REGISTR_UART1)&0x0008)==0x0008);//ожидание освобождения линии; проверка на флаг BUSY
		TRANSMITER_UART1_OFF;
	}

	APPARATNII_BUFFER_UART1=0x0A;//отправляем побайтно начиная с младшего
	TRANSMITER_UART1_ON;
	while(((FLAG_REGISTR_UART1)&0x0008)==0x0008);//ожидание освобождения линии; проверка на флаг BUSY	
	TRANSMITER_UART1_OFF;
	Transmit_in_progress_Uart1=0;//флаг работы передатчика	
	//WatchDog_change_flag();
}

void uznat_konfiguraciyu_BPV(void)      														 //функция опроса ног _nPRSNT для определения конфигурации прибора БПВ (БИК СБИС-А или ИК МРЛ-А)
{
															//WatchDog_change_flag();
	
	uint8_t proverka=0;
	
		//0 означает ниличие платы на проверяемой ноге
    sostoyaniya_nog_nPRSNT[12]=chtenie_razryada_porta('E',9);  //плата ЦОС
    sostoyaniya_nog_nPRSNT[11]=chtenie_razryada_porta('A',7);  //плата ГТ (XP6)
    sostoyaniya_nog_nPRSNT[10]=chtenie_razryada_porta('A',9);  //плата МДМ-КМВ (XS15)
    sostoyaniya_nog_nPRSNT[9]=chtenie_razryada_porta('A',5);   //плата БКС (XS11)
    sostoyaniya_nog_nPRSNT[8]=chtenie_razryada_porta('A',3);   //плата РТ9 (XS10)
    sostoyaniya_nog_nPRSNT[7]=chtenie_razryada_porta('F',14);  //плата РТ8 (XS9)
    sostoyaniya_nog_nPRSNT[6]=chtenie_razryada_porta('F',4);   //плата РТ7 (XS8)
    sostoyaniya_nog_nPRSNT[5]=chtenie_razryada_porta('E',5);   //плата РТ6 (XS7)
    sostoyaniya_nog_nPRSNT[4]=chtenie_razryada_porta('A',4);   //плата РТ5 (XS6)
    sostoyaniya_nog_nPRSNT[3]=chtenie_razryada_porta('D',1);   //плата РТ4 (XS5)
    sostoyaniya_nog_nPRSNT[2]=chtenie_razryada_porta('F',10);  //плата РТ3 (XS4)
    sostoyaniya_nog_nPRSNT[1]=chtenie_razryada_porta('E',4);   //плата РТ2 (XS3)
    sostoyaniya_nog_nPRSNT[0]=chtenie_razryada_porta('E',8);   //плата РТ1 (XS2)

    if((sostoyaniya_nog_nPRSNT[6]==0)&&(sostoyaniya_nog_nPRSNT[5]==0))
    {
            flag_konfiguracii_BPV=0;        //это МРЛ
    }
    else
    {
			      flag_konfiguracii_BPV=1;        //это БИС
			
			//лучше конечно вообще вырубить неиспоьзуемые SPI-ноги (перевести в Z-состояние, но я этого не умею)
						RT1_RT6_SPI_CS3_OFF;
						RT1_RT6_SPI_CS4_OFF;
						RT2_RT7_SPI_CS3_OFF;
						RT2_RT7_SPI_CS4_OFF;
						RT3_RT8_SPI_CS3_OFF;
						RT3_RT8_SPI_CS4_OFF;
						RT4_RT9_SPI_CS3_OFF;
						RT4_RT9_SPI_CS4_OFF;

    }
		
		//проверим не отвалилась ли одна из плат
		if(flag_konfiguracii_BPV==0)
		{
			for(uint8_t i=0;i<13;i++)
			{
				proverka=proverka+sostoyaniya_nog_nPRSNT[i];
			}
			if (proverka>0)//если хоть на 1 ноге nPRSNT есть состояние логиечской 1, значит какая-то плата отвалилась и БПВ не будет работать корректно
			{
				 signals_alarm.Cod_Signal=12;
			}
			proverka=0;
		}
		else
		{
			proverka=sostoyaniya_nog_nPRSNT[0]+sostoyaniya_nog_nPRSNT[1]+sostoyaniya_nog_nPRSNT[2]+sostoyaniya_nog_nPRSNT[3]+sostoyaniya_nog_nPRSNT[4];//радиотракты
			proverka=proverka+sostoyaniya_nog_nPRSNT[9]+sostoyaniya_nog_nPRSNT[10]+sostoyaniya_nog_nPRSNT[11]+sostoyaniya_nog_nPRSNT[12];//ЦОС, КМВ, ГЕТЕРОДИН, БКС
			if (proverka>0)//если на одной из ног nPRSNT конфигурации БИС есть состояние логиечской 1, значит какая-то плата отвалилась и БПВ не будет работать корректно
			{
			  signals_alarm.Cod_Signal=12;
			}
			proverka=0;
		}
															//WatchDog_change_flag();
}

uint8_t chtenie_razryada_porta(int8_t port, uint8_t razryad) 					 //функция чтения конкретного разряда конкретного порта
{
    uint32_t bufer_sostoyaniya_porta=0;
		uint8_t result=0;
    switch(port)
    {
        case 'A':
				//bufer_sostoyaniya_porta=(PORTA->RXTX >> razryad)&1;
        bufer_sostoyaniya_porta=PORTA->RXTX;
        bufer_sostoyaniya_porta=(bufer_sostoyaniya_porta >> razryad)&1;
        break;
        case 'B':
				//bufer_sostoyaniya_porta=(PORTB->RXTX >> razryad)&1;
        bufer_sostoyaniya_porta=PORTB->RXTX;
        bufer_sostoyaniya_porta=(bufer_sostoyaniya_porta >> razryad)&1;
        break;
        case 'C':
				//bufer_sostoyaniya_porta=(PORTC->RXTX >> razryad)&1;
        bufer_sostoyaniya_porta=PORTC->RXTX;
        bufer_sostoyaniya_porta=(bufer_sostoyaniya_porta >> razryad)&1;
        break;
        case 'D':
				//bufer_sostoyaniya_porta=(PORTD->RXTX >> razryad)&1;
        bufer_sostoyaniya_porta=PORTD->RXTX;
        bufer_sostoyaniya_porta=(bufer_sostoyaniya_porta >> razryad)&1;
        break;
        case 'E':
				//bufer_sostoyaniya_porta=(PORTE->RXTX >> razryad)&1;
        bufer_sostoyaniya_porta=PORTE->RXTX;
        bufer_sostoyaniya_porta=(bufer_sostoyaniya_porta >> razryad)&1;
        break;
        case 'F':
				//bufer_sostoyaniya_porta=(PORTF->RXTX >> razryad)&1;
        bufer_sostoyaniya_porta=PORTF->RXTX;
        bufer_sostoyaniya_porta=(bufer_sostoyaniya_porta >> razryad)&1;
        break;
    }
		result=bufer_sostoyaniya_porta;
    return result;
}

void obnulenie_peremennih(void)																			 //функция обнуления переменных в теле бесконечного цикла
{
	  Tpp_min=0;
    Tpp_max=0;
    Tpp_average=0;
		/*******************/
    temperatura_COS[0]=0;
    temperatura_COS[1]=0;
    temperatura_COS[2]=0;
	  temperatura_COS[3]=0;
    temperatura_COS[4]=0;
    temperatura_COS[5]=0;
	  /*******************/
    temperatura_GT[0]=0;
	  temperatura_GT[1]=0;
	 /*******************/
	  temperatura_MDM_KMV[0]=0;
	  temperatura_MDM_KMV[1]=0;
	 /*******************/
    temperatura_RT_1[0]=0;
    temperatura_RT_1[1]=0;
	  temperatura_RT_1[2]=0;
    temperatura_RT_1[3]=0;
	 /*******************/	
    temperatura_RT_2[0]=0;
    temperatura_RT_2[1]=0;
		temperatura_RT_2[2]=0;
    temperatura_RT_2[3]=0;
	 /*******************/			
    temperatura_RT_3[0]=0;
    temperatura_RT_3[1]=0;
		temperatura_RT_3[2]=0;
    temperatura_RT_3[3]=0;
		/*******************/	
    temperatura_RT_4[0]=0;
    temperatura_RT_4[1]=0;
		temperatura_RT_4[2]=0;
    temperatura_RT_4[3]=0;
		/*******************/	
    temperatura_RT_5[0]=0;
    temperatura_RT_5[1]=0;
		temperatura_RT_5[2]=0;
    temperatura_RT_5[3]=0;
		/*******************/	
    temperatura_RT_6[0]=0;
    temperatura_RT_6[1]=0;
		temperatura_RT_6[2]=0;
    temperatura_RT_6[3]=0;
		/*******************/		
    temperatura_RT_7[0]=0;
    temperatura_RT_7[1]=0;
		temperatura_RT_7[2]=0;
    temperatura_RT_7[3]=0;
		/*******************/
    temperatura_RT_8[0]=0;
    temperatura_RT_8[1]=0;
		temperatura_RT_8[2]=0;
    temperatura_RT_8[3]=0;
		/*******************/	
    temperatura_RT_9[0]=0;
    temperatura_RT_9[1]=0;
		temperatura_RT_9[2]=0;
    temperatura_RT_9[3]=0;
		/*******************/	
    temperatura_BKS[0]=0;
    temperatura_BKS[1]=0;
		temperatura_BKS[2]=0;
    temperatura_BKS[3]=0;
}
 
void opros_termodatchikov_pp(void)     															 //функция последовательного чтения данных с температурных датчиков на печатных платах, анализ полученных данных
{
	int i=0;
	int8_t correct;
	if(flag_konfiguracii_BPV==0)        //МРЛ
    {
															
			temperatura_RT_1[0]=SPI_read_temperature(1,1,&correct);
			temperatura_RT_1[2]=(uint8_t)(correct);
			temperatura_RT_1[1]=SPI_read_temperature(1,2,&correct);
			temperatura_RT_1[3]=(uint8_t)(correct);
      /**************************************/		
			temperatura_RT_6[0]=SPI_read_temperature(1,3,&correct);
			temperatura_RT_6[2]=(uint8_t)(correct);
      temperatura_RT_6[1]=SPI_read_temperature(1,4,&correct);
			temperatura_RT_6[3]=(uint8_t)(correct);
			/**************************************/	
      temperatura_RT_2[0]=SPI_read_temperature(2,1,&correct);
			temperatura_RT_2[2]=(uint8_t)(correct);
      temperatura_RT_2[1]=SPI_read_temperature(2,2,&correct);
			temperatura_RT_2[3]=(uint8_t)(correct);
			/**************************************/	
      temperatura_RT_7[0]=SPI_read_temperature(2,3,&correct);
			temperatura_RT_7[2]=(uint8_t)(correct);
      temperatura_RT_7[1]=SPI_read_temperature(2,4,&correct);
			temperatura_RT_7[3]=(uint8_t)(correct);
			/**************************************/												
      temperatura_RT_3[0]=SPI_read_temperature(3,1,&correct);
			temperatura_RT_3[2]=(uint8_t)(correct);
      temperatura_RT_3[1]=SPI_read_temperature(3,2,&correct);
			temperatura_RT_3[3]=(uint8_t)(correct);
			/**************************************/		
      temperatura_RT_8[0]=SPI_read_temperature(3,3,&correct);
			temperatura_RT_8[2]=(uint8_t)(correct);
      temperatura_RT_8[1]=SPI_read_temperature(3,4,&correct);
			temperatura_RT_8[3]=(uint8_t)(correct);
			/**************************************/
      temperatura_RT_4[0]=SPI_read_temperature(4,1,&correct);
			temperatura_RT_4[2]=(uint8_t)(correct);
      temperatura_RT_4[1]=SPI_read_temperature(4,2,&correct);
			temperatura_RT_4[3]=(uint8_t)(correct);
			/**************************************/
      temperatura_RT_9[0]=SPI_read_temperature(4,3,&correct);
			temperatura_RT_9[2]=(uint8_t)(correct);
      temperatura_RT_9[1]=SPI_read_temperature(4,4,&correct);
			temperatura_RT_9[3]=(uint8_t)(correct);	
			/**************************************/
      temperatura_RT_5[0]=SPI_read_temperature(5,1,&correct);
			temperatura_RT_5[2]=(uint8_t)(correct);
			temperatura_RT_5[1]=SPI_read_temperature(5,2,&correct);
			temperatura_RT_5[3]=(uint8_t)(correct);
			/**************************************/
      temperatura_BKS[0]=SPI_read_temperature(5,3,&correct);
			temperatura_BKS[2]=(uint8_t)(correct);
      temperatura_BKS[1]=SPI_read_temperature(5,4,&correct);
			temperatura_BKS[3]=(uint8_t)(correct);
			/**************************************/
      temperatura_MDM_KMV[0]=SPI_read_temperature(6,1,&correct);
			temperatura_MDM_KMV[1]=(uint8_t)(correct);
			/**************************************/
      temperatura_GT[0]=SPI_read_temperature(6,2,&correct);
			temperatura_GT[1]=(uint8_t)(correct);
			/**************************************/										
      temperatura_COS[0]=SPI_read_temperature(7,1,&correct);
			temperatura_COS[3]=(uint8_t)(correct);
      temperatura_COS[1]=SPI_read_temperature(7,2,&correct);
			temperatura_COS[4]=(uint8_t)(correct);
			temperatura_COS[2]=SPI_read_temperature(7,3,&correct);
			temperatura_COS[5]=(uint8_t)(correct);
      termodannie_pp_v_1_massiv_MRL();    //перегнать все данные в 1 массив massiv_vseh_termodannih_pp_MRL	
      Tpp_min=naiti_minimalnoe_znachenie_pp(massiv_vseh_termodannih_pp_MRL,massiv_vseh_status_termodannih_pp_MRL,18U);
      Tpp_max=naiti_maximalnoe_znachenie_pp(massiv_vseh_termodannih_pp_MRL,massiv_vseh_status_termodannih_pp_MRL,18U);
      Tpp_average=naiti_srednee_znachenie_pp(massiv_vseh_termodannih_pp_MRL,massiv_vseh_status_termodannih_pp_MRL,18U);
			Tpvkl_COS=naiti_minimalnoe_znachenie_pp(massiv_vseh_termodannih_pp_MRL,massiv_vseh_status_termodannih_pp_MRL,25U);
			Correct_masive_temper(0x01);
    } 
    else                                                  //БИС
    {	
			/**************************************/	
			temperatura_RT_1[0]=SPI_read_temperature(1,1,&correct);
			temperatura_RT_1[2]=(uint8_t)(correct);
			temperatura_RT_1[1]=SPI_read_temperature(1,2,&correct);
			temperatura_RT_1[3]=(uint8_t)(correct);
			/**************************************/
      temperatura_RT_2[0]=SPI_read_temperature(2,1,&correct);
			temperatura_RT_2[2]=(uint8_t)(correct);
      temperatura_RT_2[1]=SPI_read_temperature(2,2,&correct);
			temperatura_RT_2[3]=(uint8_t)(correct);
			/**************************************/		
      temperatura_RT_3[0]=SPI_read_temperature(3,1,&correct);
			temperatura_RT_3[2]=(uint8_t)(correct);
      temperatura_RT_3[1]=SPI_read_temperature(3,2,&correct);
			temperatura_RT_3[3]=(uint8_t)(correct);
			/**************************************/
      temperatura_RT_4[0]=SPI_read_temperature(4,1,&correct);
			temperatura_RT_4[2]=(uint8_t)(correct);
      temperatura_RT_4[1]=SPI_read_temperature(4,2,&correct);
			temperatura_RT_4[3]=(uint8_t)(correct);
			/**************************************/
      temperatura_RT_5[0]=SPI_read_temperature(5,1,&correct);
			temperatura_RT_5[2]=(uint8_t)(correct);
			temperatura_RT_5[1]=SPI_read_temperature(5,2,&correct);
			temperatura_RT_5[3]=(uint8_t)(correct);
			/**************************************/
      temperatura_BKS[0]=SPI_read_temperature(5,3,&correct);
			temperatura_BKS[2]=(uint8_t)(correct);
      temperatura_BKS[1]=SPI_read_temperature(5,4,&correct);
			temperatura_BKS[3]=(uint8_t)(correct);
			/**************************************/
      temperatura_MDM_KMV[0]=SPI_read_temperature(6,1,&correct);
			temperatura_MDM_KMV[1]=(uint8_t)(correct);
      temperatura_GT[0]=SPI_read_temperature(6,2,&correct);
			temperatura_GT[1]=(uint8_t)(correct);
      temperatura_COS[0]=SPI_read_temperature(7,1,&correct);
			temperatura_COS[3]=(uint8_t)(correct);
      temperatura_COS[1]=SPI_read_temperature(7,2,&correct);
			temperatura_COS[4]=(uint8_t)(correct);
			temperatura_COS[2]=SPI_read_temperature(7,3,&correct);
			temperatura_COS[5]=(uint8_t)(correct);
      termodannie_pp_v_1_massiv_BIS();    //перегнать все данные в 1 массив massiv_vseh_termodannih_pp_BIS
		/*	massiv_vseh_termodannih_pp_BIS[0]=-2;
			massiv_vseh_termodannih_pp_BIS[1]=-3;
			massiv_vseh_termodannih_pp_BIS[2]=3;
			massiv_vseh_termodannih_pp_BIS[3]=4;
			massiv_vseh_termodannih_pp_BIS[4]=5;
			massiv_vseh_termodannih_pp_BIS[5]=-5;
			massiv_vseh_termodannih_pp_BIS[6]=-6;
			massiv_vseh_termodannih_pp_BIS[7]=7;
			massiv_vseh_termodannih_pp_BIS[8]=2;
			massiv_vseh_termodannih_pp_BIS[9]=3;*/
      Tpp_min=naiti_minimalnoe_znachenie_pp(massiv_vseh_termodannih_pp_BIS,massiv_vseh_status_termodannih_pp_BIS,10);
      Tpp_max=naiti_maximalnoe_znachenie_pp(massiv_vseh_termodannih_pp_BIS,massiv_vseh_status_termodannih_pp_BIS,10);
      Tpp_average=naiti_srednee_znachenie_pp(massiv_vseh_termodannih_pp_BIS,massiv_vseh_status_termodannih_pp_BIS,10);
			Tpvkl_COS=naiti_minimalnoe_znachenie_pp(massiv_vseh_termodannih_pp_BIS,massiv_vseh_status_termodannih_pp_BIS,17U);
      Correct_masive_temper(0x00);
    }
}

void Correct_masive_temper(uint8_t BPV)
{
	uint8_t i=0;
	if(BPV==0)  //BIS
	{
		for(i=0;i<sizeof(massiv_vseh_termodannih_pp_BIS);i++)
		{
			if(massiv_vseh_status_termodannih_pp_BIS[i]==0)
			{
				massiv_vseh_termodannih_pp_BIS_CORECT[i]=Tpp_average;
			}
			else
			{
				massiv_vseh_termodannih_pp_BIS_CORECT[i]=massiv_vseh_termodannih_pp_BIS[i];
			}
		}
	}
	else
	{
		for(i=0;i<sizeof(massiv_vseh_termodannih_pp_MRL);i++)
		{
			if(massiv_vseh_status_termodannih_pp_MRL[i]==0)
			{
				massiv_vseh_termodannih_pp_MRL_CORECT[i]=Tpp_average;
			}
			else
			{
				massiv_vseh_termodannih_pp_MRL_CORECT[i]=massiv_vseh_termodannih_pp_MRL[i];
			}
		}
	}
	
}

uint8_t SPI_read_temperature(uint8_t number_of_spi,uint8_t CS, int8_t *correct)			 //ИТОГОВАЯ функция чтения температуры с термодатчиков на печатных платах (5019ЧТ1Т)
{
	int8_t temp=0;
	uint8_t result=0;

													
	switch(number_of_spi)
	{	
		case 1:
			temp=spi_1_read_temperature(CS,correct);
			break;
		case 2:
			temp=spi_2_read_temperature(CS,correct);
			break;
		case 3:
			temp=spi_3_read_temperature(CS,correct);
			break;
		case 4:
			temp=spi_4_read_temperature(CS,correct);
			break;
		case 5:
			temp=spi_5_read_temperature(CS,correct);
			break;
		case 6:
			temp=spi_6_read_temperature(CS,correct);
			break;
		case 7:
			temp=spi_7_read_temperature(CS,correct);
			break;
		default:
			break;
	}
  //b=two_int8_t_to_1_uint8_t(a);
															////WatchDog_change_flag();
	result=(uint8_t)temp;
  return result;
}

int8_t spi_1_read_temperature(int8_t spi_cs, int8_t *correct)//функция чтения температуры с 4 микросхем 5019ЧТ1Т (РТ1, РТ6)
{
	int8_t out=0;
	int8_t status=0; 
	spi_1_clk_high();						// установил clk_high
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT1_RT6_SPI_CS1_ON;
			break;
		case 2:
			RT1_RT6_SPI_CS2_ON;
			break;
		case 3:
			RT1_RT6_SPI_CS3_ON;
			break;
		case 4:
			RT1_RT6_SPI_CS4_ON;
			break;		
	}
	spi_1_send_cmd(0xEE);		// отправляем команду начала преобразования температура->код
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT1_RT6_SPI_CS1_OFF;
			break;
		case 2:
			RT1_RT6_SPI_CS2_OFF;
			break;
		case 3:
			RT1_RT6_SPI_CS3_OFF;
			break;
		case 4:
			RT1_RT6_SPI_CS4_OFF;
			break;
	}
	wait_150ns(1000000);		// ждем	завершения преобразования температура->код (750 мсек)	
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT1_RT6_SPI_CS1_ON;
			break;
		case 2:
			RT1_RT6_SPI_CS2_ON;
			break;
		case 3:
			RT1_RT6_SPI_CS3_ON;
			break;
		case 4:
			RT1_RT6_SPI_CS4_ON;
			break;		
	}
	out=(int8_t)spi_1_read_temper();// читаем код температуры
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT1_RT6_SPI_CS1_OFF;
			break;
		case 2:
			RT1_RT6_SPI_CS2_OFF;
			break;
		case 3:
			RT1_RT6_SPI_CS3_OFF;
			break;
		case 4:
			RT1_RT6_SPI_CS4_OFF;
			break;
	}
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT1_RT6_SPI_CS1_ON;
			break;
		case 2:
			RT1_RT6_SPI_CS2_ON;
			break;
		case 3:
			RT1_RT6_SPI_CS3_ON;
			break;
		case 4:
			RT1_RT6_SPI_CS4_ON;
			break;		
	}
	status=spi_1_read_config();
	if(((((uint8_t)(status))&(~0xF3))>>2U)!=0x02)
	{
		 out=0x80; //-128 significo the Temperatura error 
		 *correct=0;
	}
	else
	{
		 *correct=1u;
	}
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT1_RT6_SPI_CS1_OFF;
			break;
		case 2:
			RT1_RT6_SPI_CS2_OFF;
			break;
		case 3:
			RT1_RT6_SPI_CS3_OFF;
			break;
		case 4:
			RT1_RT6_SPI_CS4_OFF;
			break;
	}
	return out;
}

int8_t spi_1_read_temper(void)						//функция чтения байта температуры
{
	spi_1_send_cmd(0xAA);
	return spi_1_read_data(1);	// температура с точностью 1 градус
}


int8_t spi_1_read_config(void)						//функция чтения байта конфигурации
{
	spi_1_send_cmd(0xAC);
	return spi_1_read_data(0);	// конфигурация
}		

void spi_1_send_cmd(uint8_t cmd)						//функция отправки комманды микросхеме
{
	uint8_t i;									// i - смещение по байту (разряд)
	PORTF->OE|=(uint16_t)(1<<15);			// output (DQ_write)//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	for(i=0;i<8;i++)				// цикл побитовой отправки команды первый бит - младший разряд, последний - старший
	{
		spi_1_clk_low();			// CLK вниз
		wait_200ns();					// ждем 200 нс
    if ((cmd&(1<<i)))			// если i-тый бит команды не нулевой, то 
		{
			PORTF->RXTX|=(uint16_t)(1<<15);// устанавливаем DQ=1//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		}
		spi_1_clk_high();			// CLK вверх
		wait_200ns();					// ждем 200 нс
		PORTF->CLRTX=(uint16_t)(1U<<15U);// сбрасываем DQ (DQ=0)//!!!!!!!!!!!!!!!!!!!!!!!!!!!
	}
	PORTF->OE&=~((uint16_t)(1<<15));		// input (DQ_read)
}

int16_t spi_1_read_data(int8_t d)						//функция чтения байта данных
{
	// чтение данных: температуры (9бит, d=1) или конфигурации* (8бит, d=0)
	uint8_t i=0;
	uint8_t N=0;
	uint16_t out_dat=0;
	uint8_t integer_temp=0;
	uint8_t frac_temp=0;
	N=8+d;// i - смещение по байту (разряд)
	PORTF->OE&=~((uint16_t)(1<<15));		// input (DQ_read)
	for(i=0;i<N;i++)				// цикл побитового чтения данных (9бит-темпер, 8бит-конфиг) первый бит - младший разряд, последний - старший
	{
		spi_1_clk_low();													// CLK вниз
		wait_200ns();															// ждем 200 нс
		out_dat|=(((PORTF->RXTX&(1<<15))>>15)<<i);// DQ - n разряд PORTA, смещаем его в нулевой, затем на i-тый разряд влево.
		spi_1_clk_high();													// CLK вверх
		wait_200ns();															// ждем 200 нс
	}
	if(d==1)
	{
			//out_dat=out_dat>>1;// если d=1, смещением отрезаем младший бит кода температуры, если нет - читаем конфиг как есть
		  integer_temp=(uint8_t)(out_dat>>1);
		  frac_temp=(uint8_t)(out_dat-integer_temp);
		  return integer_temp;
	}
	else
	{
		 out_dat&=0xFF;
		 return out_dat;
	}	
}	

void spi_1_clk_low(void)								//тактовая вниз
{
	//PORTA->RXTX&=~(1<<12);
	PORTA->CLRTX=(1U<<12U);
}		

void spi_1_clk_high(void)								//тактовая вверх
{
	//PORTA->RXTX|=(1<<12);
	PORTA->SETTX|=(1U<<12U);
}		


int8_t spi_2_read_temperature(int8_t spi_cs, int8_t *correct)//функция чтения температуры с 4 микросхем 5019ЧТ1Т (РТ2, РТ7)
{
	int8_t out=0;
	int8_t status=0;
	spi_2_clk_high();						// установил clk_high
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT2_RT7_SPI_CS1_ON;
			break;
		case 2:
			RT2_RT7_SPI_CS2_ON;
			break;
		case 3:
			RT2_RT7_SPI_CS3_ON;
			break;
		case 4:
			RT2_RT7_SPI_CS4_ON;
			break;		
	}
	spi_2_send_cmd(0xEE);		// отправляем команду начала преобразования температура->код
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT2_RT7_SPI_CS1_OFF;
			break;
		case 2:
			RT2_RT7_SPI_CS2_OFF;
			break;
		case 3:
			RT2_RT7_SPI_CS3_OFF;
			break;
		case 4:
			RT2_RT7_SPI_CS4_OFF;
			break;
	}	
	wait_150ns(1000000);		// ждем	завершения преобразования температура->код (750 мсек)	
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT2_RT7_SPI_CS1_ON;
			break;
		case 2:
			RT2_RT7_SPI_CS2_ON;
			break;
		case 3:
			RT2_RT7_SPI_CS3_ON;
			break;
		case 4:
			RT2_RT7_SPI_CS4_ON;
			break;		
	}
	out=(int8_t)spi_2_read_temper();// читаем код температуры
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT2_RT7_SPI_CS1_OFF;
			break;
		case 2:
			RT2_RT7_SPI_CS2_OFF;
			break;
		case 3:
			RT2_RT7_SPI_CS3_OFF;
			break;
		case 4:
			RT2_RT7_SPI_CS4_OFF;
			break;
	}
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT2_RT7_SPI_CS1_ON;
			break;
		case 2:
			RT2_RT7_SPI_CS2_ON;
			break;
		case 3:
			RT2_RT7_SPI_CS3_ON;
			break;
		case 4:
			RT2_RT7_SPI_CS4_ON;
			break;		
	}
	status=spi_2_read_config();
	if(((((uint8_t)(status))&(~0xF3))>>2U)!=0x02)
	{
		 out=0x80; //-128 significo the Temperatura error 
		 *correct=0;
	}
	else
	{
		 *correct=1u;
	}
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT2_RT7_SPI_CS1_OFF;
			break;
		case 2:
			RT2_RT7_SPI_CS2_OFF;
			break;
		case 3:
			RT2_RT7_SPI_CS3_OFF;
			break;
		case 4:
			RT2_RT7_SPI_CS4_OFF;
			break;
	}
	return out;
}

int8_t spi_2_read_temper(void)						//функция чтения температуры
{
	spi_2_send_cmd(0xAA);
	return spi_2_read_data(1);	// температура с точностью 1 градус
}

int8_t spi_2_read_config(void)						//функция чтения байта конфигурации
{
	spi_2_send_cmd(0xAC);
	return spi_2_read_data(0);	// конфигурация
}

void spi_2_send_cmd(uint8_t cmd)						//функция отправки комманды микросхеме
{
	uint8_t i;									// i - смещение по байту (разряд)
	PORTD->OE|=(uint16_t)(1<<2);			// output (DQ_write)//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	for(i=0;i<8;i++)				// цикл побитовой отправки команды первый бит - младший разряд, последний - старший
	{
		spi_2_clk_low();			// CLK вниз
		wait_200ns();					// ждем 200 нс
    if ((cmd&(1<<i)))			// если i-тый бит команды не нулевой, то 
		{
			PORTD->RXTX|=(uint16_t)(1<<2);// устанавливаем DQ=1//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		}
		spi_2_clk_high();			// CLK вверх
		wait_200ns();					// ждем 200 нс
		PORTD->CLRTX=(uint16_t)(1U<<2U);	// сбрасываем DQ (DQ=0)//!!!!!!!!!!!!!!!!!!!!!!!!!!!
	}
	PORTD->OE&=~((uint16_t)(1<<2));			// input (DQ_read)
}	

int16_t spi_2_read_data(int8_t d)						//функция чтения байта данных
{
	// чтение данных: температуры (9бит, d=1) или конфигурации* (8бит, d=0)
	uint8_t i=0;
	uint8_t N=0;
	uint8_t integer_temp=0;
	uint8_t frac_temp=0;
	uint16_t out_dat=0;
	N=8+d;// i - смещение по байту (разряд)
	PORTD->OE&=~((uint16_t)(1<<2));			// input (DQ_read)
	for(i=0;i<N;i++)				// цикл побитового чтения данных (9бит-темпер, 8бит-конфиг) первый бит - младший разряд, последний - старший
	{
		spi_2_clk_low();													// CLK вниз
		wait_200ns();															// ждем 200 нс
		out_dat|=(((PORTD->RXTX&(1<<2))>>2)<<i);	// DQ - n разряд PORTA, смещаем его в нулевой, затем на i-тый разряд влево.
		spi_2_clk_high();													// CLK вверх
		wait_200ns();															// ждем 200 нс
	}
	if(d==1)
	{
		  integer_temp=(uint8_t)(out_dat>>1);// если d=1, смещением отрезаем младший бит кода температуры, если нет - читаем конфиг как есть
		  frac_temp=(uint8_t)(out_dat-integer_temp);
		  return integer_temp;
	}
	else
	{
		 out_dat&=0xFF;
		 return out_dat;
	}
}	

void spi_2_clk_low(void)								//тактовая вниз
{
	//PORTA->RXTX&=~(1<<10);
	PORTA->CLRTX=(1U<<10U);
}

void spi_2_clk_high(void)								//тактовая вверх
{
	//PORTA->RXTX|=(1<<10);
	PORTA->SETTX|=(1U<<10U);
}		

int8_t spi_3_read_temperature(int8_t spi_cs, int8_t *correct)//функция чтения температуры с 4 микросхем 5019ЧТ1Т (РТ3, РТ8)
{
	int8_t out=0;
	int8_t status=0;
	spi_3_clk_high();						// установил clk_high
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT3_RT8_SPI_CS1_ON;
			break;
		case 2:
			RT3_RT8_SPI_CS2_ON;
			break;
		case 3:
			RT3_RT8_SPI_CS3_ON;
			break;
		case 4:
			RT3_RT8_SPI_CS4_ON;
			break;		
	}
	spi_3_send_cmd(0xEE);		// отправляем команду начала преобразования температура->код
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT3_RT8_SPI_CS1_OFF;
			break;
		case 2:
			RT3_RT8_SPI_CS2_OFF;
			break;
		case 3:
			RT3_RT8_SPI_CS3_OFF;
			break;
		case 4:
			RT3_RT8_SPI_CS4_OFF;
			break;
	}
	wait_150ns(1000000);		// ждем	завершения преобразования температура->код (750 мсек)	
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT3_RT8_SPI_CS1_ON;
			break;
		case 2:
			RT3_RT8_SPI_CS2_ON;
			break;
		case 3:
			RT3_RT8_SPI_CS3_ON;
			break;
		case 4:
			RT3_RT8_SPI_CS4_ON;
			break;		
	}
	out=(int8_t)(spi_3_read_temper());// читаем код температуры
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT3_RT8_SPI_CS1_OFF;
			break;
		case 2:
			RT3_RT8_SPI_CS2_OFF;
			break;
		case 3:
			RT3_RT8_SPI_CS3_OFF;
			break;
		case 4:
			RT3_RT8_SPI_CS4_OFF;
			break;
	}
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT3_RT8_SPI_CS1_ON;
			break;
		case 2:
			RT3_RT8_SPI_CS2_ON;
			break;
		case 3:
			RT3_RT8_SPI_CS3_ON;
			break;
		case 4:
			RT3_RT8_SPI_CS4_ON;
			break;		
	}
	status=spi_3_read_config();
  if(((((uint8_t)(status))&(~0xF3))>>2U)!=0x02)
	{
	   out=0x80; //-128 significo the Temperatura error 
		 *correct=0;
	}
	else
	{
		 *correct=1u;
	}
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT3_RT8_SPI_CS1_OFF;
			break;
		case 2:
			RT3_RT8_SPI_CS2_OFF;
			break;
		case 3:
			RT3_RT8_SPI_CS3_OFF;
			break;
		case 4:
			RT3_RT8_SPI_CS4_OFF;
			break;
	}
	return out;
}

int8_t spi_3_read_temper(void)						//функция чтения температуры
{
	spi_3_send_cmd(0xAA);
	return spi_3_read_data(1);	// температура с точностью 1 градус
}

int8_t spi_3_read_config(void)						//функция чтения байта конфигурации
{
	spi_3_send_cmd(0xAC);
	return spi_3_read_data(0);	// конфигурация
}	

void spi_3_send_cmd(uint8_t cmd)						//функция отправки комманды микросхеме
{
	uint8_t i=0;								// i - смещение по байту (разряд)
	PORTF->OE|=(uint16_t)(1<<5);			// output (DQ_write)//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	for(i=0;i<8;i++)				// цикл побитовой отправки команды первый бит - младший разряд, последний - старший
	{
		spi_3_clk_low();			// CLK вниз
		wait_200ns();					// ждем 200 нс
    if ((cmd&(1<<i)))			// если i-тый бит команды не нулевой, то 
		{
			PORTF->RXTX|=(uint16_t)(1u<<5u);// устанавливаем DQ=1//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		}
		spi_3_clk_high();			// CLK вверх
		wait_200ns();					// ждем 200 нс
		PORTF->CLRTX=(uint16_t)(1U<<5U);	// сбрасываем DQ (DQ=0)//!!!!!!!!!!!!!!!!!!!!!!!!!!!
	}
	PORTF->OE&=~((uint16_t)(1<<5));			// input (DQ_read)
}	

int16_t spi_3_read_data(int8_t d)						//функция чтения байта данных
{
	// чтение данных: температуры (9бит, d=1) или конфигурации* (8бит, d=0)
	uint8_t i=0;
	uint8_t N=0;
	uint8_t integer_temp=0;
	uint8_t frac_temp=0;
	uint16_t out_dat=0;
	N=8+d;// i - смещение по байту (разряд)
	PORTF->OE&=(~((uint16_t)(1<<5U)));		// input (DQ_read)
	for(i=0;i<N;i++)				// цикл побитового чтения данных (9бит-темпер, 8бит-конфиг) первый бит - младший разряд, последний - старший
	{
		spi_3_clk_low();													// CLK вниз
		wait_200ns();															// ждем 200 нс
		out_dat|=(((PORTF->RXTX&(1<<5))>>5)<<i);	// DQ - n разряд PORTA, смещаем его в нулевой, затем на i-тый разряд влево.
		spi_3_clk_high();													// CLK вверх
		wait_200ns();															// ждем 200 нс
	}
	if(d==1)
	{
			integer_temp=(uint8_t)(out_dat>>1);// если d=1, смещением отрезаем младший бит кода температуры, если нет - читаем конфиг как есть
		  frac_temp=(uint8_t)(out_dat-integer_temp);
		  return integer_temp;
	}
	else
	{
		 out_dat&=0xFF;
		 return out_dat;
	}
}	

void spi_3_clk_low(void)								//тактовая вниз
{
	//PORTA->RXTX&=~(1<<8);
	PORTA->CLRTX=(1U<<8U);
}

void spi_3_clk_high(void)								//тактовая вверх
{
	//PORTA->RXTX|=(1<<8);
	PORTA->SETTX|=(1U<<8U);
}		

int8_t spi_4_read_temperature(int8_t spi_cs, int8_t *correct)//функция чтения температуры с 4 микросхем 5019ЧТ1Т (РТ4, РТ9)
{
	int8_t out=0;
	int8_t status=0;
	spi_4_clk_high();						// установил clk_high
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT4_RT9_SPI_CS1_ON;
			break;
		case 2:
			RT4_RT9_SPI_CS2_ON;
			break;
		case 3:
			RT4_RT9_SPI_CS3_ON;
			break;
		case 4:
			RT4_RT9_SPI_CS4_ON;
			break;		
	}
	spi_4_send_cmd(0xEE);		// отправляем команду начала преобразования температура->код
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT4_RT9_SPI_CS1_OFF;
			break;
		case 2:
			RT4_RT9_SPI_CS2_OFF;
			break;
		case 3:
			RT4_RT9_SPI_CS3_OFF;
			break;
		case 4:
			RT4_RT9_SPI_CS4_OFF;
			break;
	}	
	wait_150ns(1000000);		// ждем	завершения преобразования температура->код (750 мсек)	
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT4_RT9_SPI_CS1_ON;
			break;
		case 2:
			RT4_RT9_SPI_CS2_ON;
			break;
		case 3:
			RT4_RT9_SPI_CS3_ON;
			break;
		case 4:
			RT4_RT9_SPI_CS4_ON;
			break;		
	}
	out=(int8_t)(spi_4_read_temper());// читаем код температуры
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT4_RT9_SPI_CS1_OFF;
			break;
		case 2:
			RT4_RT9_SPI_CS2_OFF;
			break;
		case 3:
			RT4_RT9_SPI_CS3_OFF;
			break;
		case 4:
			RT4_RT9_SPI_CS4_OFF;
			break;
	}
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT4_RT9_SPI_CS1_ON;
			break;
		case 2:
			RT4_RT9_SPI_CS2_ON;
			break;
		case 3:
			RT4_RT9_SPI_CS3_ON;
			break;
		case 4:
			RT4_RT9_SPI_CS4_ON;
			break;		
	}
	status=spi_4_read_config();
  if(((((uint8_t)(status))&(~0xF3))>>2U)!=0x02)
	{
		 out=0x80; //-128 significo the Temperatura error 
		 *correct=0;
	}
	else
	{
		 *correct=1u;
	}
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT4_RT9_SPI_CS1_OFF;
			break;
		case 2:
			RT4_RT9_SPI_CS2_OFF;
			break;
		case 3:
			RT4_RT9_SPI_CS3_OFF;
			break;
		case 4:
			RT4_RT9_SPI_CS4_OFF;
			break;
	}
	return out;
}	

int8_t spi_4_read_temper(void)						//функция чтения температуры
{
	spi_4_send_cmd(0xAA);
	return spi_4_read_data(1);	// температура с точностью 1 градус
}

int8_t spi_4_read_config(void)						//функция чтения байта конфигурации
{
	spi_4_send_cmd(0xAC);
	return spi_4_read_data(0);	// конфигурация
}	

void spi_4_send_cmd(uint8_t cmd)						//функция отправки комманды микросхеме
{
	uint8_t i;									// i - смещение по байту (разряд)
	PORTF->OE|=(uint16_t)(1<<11);			// output (DQ_write)//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	for(i=0;i<8;i++)				// цикл побитовой отправки команды первый бит - младший разряд, последний - старший
	{
		spi_4_clk_low();			// CLK вниз
		wait_200ns();					// ждем 200 нс
    if ((cmd&(1<<i)))			// если i-тый бит команды не нулевой, то 
		{
			PORTF->RXTX|=(uint16_t)(1<<11);// устанавливаем DQ=1//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		}
		spi_4_clk_high();			// CLK вверх
		wait_200ns();					// ждем 200 нс
		PORTF->CLRTX=(uint16_t)(1U<<11U);// сбрасываем DQ (DQ=0)//!!!!!!!!!!!!!!!!!!!!!!!!!!!
	}
	PORTF->OE&=~((uint16_t)(1<<11));		// input (DQ_read)
}		

int16_t spi_4_read_data(int8_t d)						//функция чтения байта данных
{
	// чтение данных: температуры (9бит, d=1) или конфигурации* (8бит, d=0)
	uint8_t i=0;
	uint8_t N=0;
	uint16_t out_dat=0;
	uint8_t integer_temp=0;
	uint8_t frac_temp=0;
	N=8+d;// i - смещение по байту (разряд)
	PORTF->OE&=~((uint16_t)(1<<11));			// input (DQ_read)
	for(i=0;i<N;i++)				// цикл побитового чтения данных (9бит-темпер, 8бит-конфиг) первый бит - младший разряд, последний - старший
	{
		spi_4_clk_low();													// CLK вниз
		wait_200ns();															// ждем 200 нс
		out_dat|=(((PORTF->RXTX&(1<<11))>>11)<<i);// DQ - n разряд PORTA, смещаем его в нулевой, затем на i-тый разряд влево.
		spi_4_clk_high();													// CLK вверх
		wait_200ns();															// ждем 200 нс
	}
	if(d==1)
	{ 
			integer_temp=(uint8_t)(out_dat>>1);// если d=1, смещением отрезаем младший бит кода температуры, если нет - читаем конфиг как есть
		  frac_temp=(uint8_t)(out_dat-integer_temp);
		  return integer_temp;
	}
	else
	{
		 out_dat&=0xFF;
		 return out_dat;
	}
}	

void spi_4_clk_low(void)								//тактовая вниз
{
	//PORTA->RXTX&=~(1<<6);
	PORTA->CLRTX=(1U<<6U);
}

void spi_4_clk_high(void)								//тактовая вверх
{
	//PORTA->RXTX|=(1<<6);
	PORTA->SETTX|=(1U<<6U);
}	

int8_t spi_5_read_temperature(int8_t spi_cs, int8_t *correct)//функция чтения температуры с 4 микросхем 5019ЧТ1Т (РТ5, БКС)
{
	int8_t out=0;
	int8_t status=0;
	spi_5_clk_high();						// установил clk_high
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT5_RT10_SPI_CS1_ON;
			break;
		case 2:
			RT5_RT10_SPI_CS2_ON;
			break;
		case 3:
			RT5_RT10_SPI_CS3_ON;
			break;
		case 4:
			RT5_RT10_SPI_CS4_ON;
			break;		
	}
	spi_5_send_cmd(0xEE);		// отправляем команду начала преобразования температура->код
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT5_RT10_SPI_CS1_OFF;
			break;
		case 2:
			RT5_RT10_SPI_CS2_OFF;
			break;
		case 3:
			RT5_RT10_SPI_CS3_OFF;
			break;
		case 4:
			RT5_RT10_SPI_CS4_OFF;
			break;
	}
	wait_150ns(1000000);		// ждем	завершения преобразования температура->код (750 мсек)	
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT5_RT10_SPI_CS1_ON;
			break;
		case 2:
			RT5_RT10_SPI_CS2_ON;
			break;
		case 3:
			RT5_RT10_SPI_CS3_ON;
			break;
		case 4:
			RT5_RT10_SPI_CS4_ON;
			break;		
	}
	out=(int8_t)(spi_5_read_temper());// читаем код температуры
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT5_RT10_SPI_CS1_OFF;
			break;
		case 2:
			RT5_RT10_SPI_CS2_OFF;
			break;
		case 3:
			RT5_RT10_SPI_CS3_OFF;
			break;
		case 4:
			RT5_RT10_SPI_CS4_OFF;
			break;
	}
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			RT5_RT10_SPI_CS1_ON;
			break;
		case 2:
			RT5_RT10_SPI_CS2_ON;
			break;
		case 3:
			RT5_RT10_SPI_CS3_ON;
			break;
		case 4:
			RT5_RT10_SPI_CS4_ON;
			break;		
	}
	status=spi_5_read_config();
	if(((((uint8_t)(status))&(~0xF3))>>2U)!=0x02)
	{
		 out=0x80; //-128 significo the Temperatura error 
		 *correct=0;
	}
	else
	{
		 *correct=1u;
	}
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			RT5_RT10_SPI_CS1_OFF;
			break;
		case 2:
			RT5_RT10_SPI_CS2_OFF;
			break;
		case 3:
			RT5_RT10_SPI_CS3_OFF;
			break;
		case 4:
			RT5_RT10_SPI_CS4_OFF;
			break;
	}
	return out;
}	

int8_t spi_5_read_temper(void)						//функция чтения температуры
{
	spi_5_send_cmd(0xAA);
	return spi_5_read_data(1);	// температура с точностью 1 градус
}

int8_t spi_5_read_config(void)						//функция чтения байта конфигурации
{
	spi_5_send_cmd(0xAC);
	return spi_5_read_data(0);	// конфигурация
}	

void spi_5_send_cmd(uint8_t cmd)						//функция отправки комманды микросхеме
{
	uint8_t i;									// i - смещение по байту (разряд)
	PORTB->OE|=(uint16_t)(1<<14);			// output (DQ_write)//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	for(i=0;i<8;i++)				// цикл побитовой отправки команды первый бит - младший разряд, последний - старший
	{
		spi_5_clk_low();			// CLK вниз
		wait_200ns();					// ждем 200 нс
    if ((cmd&(1<<i)))			// если i-тый бит команды не нулевой, то 
		{
			PORTB->RXTX|=(uint16_t)(1<<14);// устанавливаем DQ=1//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		}
		spi_5_clk_high();			// CLK вверх
		wait_200ns();					// ждем 200 нс
		PORTB->CLRTX=(uint16_t)(1U<<14U);// сбрасываем DQ (DQ=0)//!!!!!!!!!!!!!!!!!!!!!!!!!!!
	}
	PORTB->OE&=~((uint16_t)(1<<14));		// input (DQ_read)
}

int16_t spi_5_read_data(int8_t d)						//функция чтения байта данных
{
	// чтение данных: температуры (9бит, d=1) или конфигурации* (8бит, d=0)
  uint8_t i=0;
	uint8_t N=0;
	uint8_t integer_temp=0;
	uint8_t frac_temp=0;
	uint16_t out_dat=0;
	N=8+d;// i - смещение по байту (разряд)
	PORTB->OE&=~((uint16_t)(1<<14));			// input (DQ_read)
	for(i=0;i<N;i++)				// цикл побитового чтения данных (9бит-темпер, 8бит-конфиг) первый бит - младший разряд, последний - старший
	{
		spi_5_clk_low();													// CLK вниз
		wait_200ns();															// ждем 200 нс
		out_dat|=(((PORTB->RXTX&(1<<14))>>14)<<i);// DQ - n разряд PORTA, смещаем его в нулевой, затем на i-тый разряд влево.
		spi_5_clk_high();													// CLK вверх
		wait_200ns();															// ждем 200 нс
	}
	if(d==1)
	{
		  integer_temp=(uint8_t)(out_dat>>1);// если d=1, смещением отрезаем младший бит кода температуры, если нет - читаем конфиг как есть
		  frac_temp=(uint8_t)(out_dat-integer_temp);
		  return integer_temp;
	}
	else
	{
		 out_dat&=0xFF;
		 return out_dat;
	}						
}	

void spi_5_clk_low(void)								//тактовая вниз
{
	//PORTB->RXTX&=~(1<<6);
	PORTB->CLRTX=(1U<<6U);
}

void spi_5_clk_high(void)								//тактовая вверх
{
	//PORTB->RXTX|=(1<<6);
	PORTB->SETTX|=(1U<<6U);
}		

int8_t spi_6_read_temperature(int8_t spi_cs, int8_t *correct)//функция чтения температуры с 2 микросхем 5019ЧТ1Т (КМВ, ГЕТ)
{
	int8_t out=0;
	int8_t status=0;
	spi_6_clk_high();						// установил clk_high
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			KMV_GETER_T_CS1_ON;
			break;
		case 2:
			KMV_GETER_T_CS2_ON;
			break;	
	}
	spi_6_send_cmd(0xEE);		// отправляем команду начала преобразования температура->код
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			KMV_GETER_T_CS1_OFF;
			break;
		case 2:
			KMV_GETER_T_CS2_OFF;
			break;
	}
	wait_150ns(1000000);		// ждем	завершения преобразования температура->код (750 мсек)	
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			KMV_GETER_T_CS1_ON;
			break;
		case 2:
			KMV_GETER_T_CS2_ON;
			break;	
	}
	out=(int8_t)spi_6_read_temper();// читаем код температуры
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			KMV_GETER_T_CS1_OFF;
			break;
		case 2:
			KMV_GETER_T_CS2_OFF;
			break;
	}
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			KMV_GETER_T_CS1_ON;
			break;
		case 2:
			KMV_GETER_T_CS2_ON;
			break;	
	}
	status=spi_6_read_config();
	if(((((uint8_t)(status))&(~0xF3))>>2U)!=0x02)
	{
		 out=0x80; //-128 significo the Temperatura error 
		 *correct=0;
	}
	else
	{
		 *correct=1u;
	}
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			KMV_GETER_T_CS1_OFF;
			break;
		case 2:
			KMV_GETER_T_CS2_OFF;
			break;
	}
	return out;
}

int8_t spi_6_read_temper(void)						//функция чтения температуры
{
	spi_6_send_cmd(0xAA);
	return spi_6_read_data(1);	// температура с точностью 1 градус
}

int8_t spi_6_read_config(void)						//функция чтения байта конфигурации
{
	spi_6_send_cmd(0xAC);
	return spi_6_read_data(0);	// конфигурация
}	

void spi_6_send_cmd(uint8_t cmd)						//функция отправки комманды микросхеме
{
	uint8_t i;									// i - смещение по байту (разряд)
	PORTB->OE|=(uint16_t)(1<<5);			// output (DQ_write)//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	for(i=0;i<8;i++)				// цикл побитовой отправки команды первый бит - младший разряд, последний - старший
	{
		spi_6_clk_low();			// CLK вниз
		wait_200ns();					// ждем 200 нс
    if ((cmd&(1<<i)))			// если i-тый бит команды не нулевой, то 
		{
			PORTB->RXTX|=(uint16_t)(1<<5);// устанавливаем DQ=1//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		}
		spi_6_clk_high();			// CLK вверх
		wait_200ns();					// ждем 200 нс
		PORTB->CLRTX=(uint16_t)(1U<<5U);// сбрасываем DQ (DQ=0)//!!!!!!!!!!!!!!!!!!!!!!!!!!!
	}
	PORTB->OE&=~((uint16_t)(1<<5));			// input (DQ_read)
}	

int16_t spi_6_read_data(int8_t d)						//функция чтения байта данных
{
	// чтение данных: температуры (9бит, d=1) или конфигурации* (8бит, d=0)
  uint8_t i=0;
	uint8_t N=0;
	uint16_t out_dat=0;	
	uint8_t integer_temp=0;
	uint8_t frac_temp=0;
	N=8+d;// i - смещение по байту (разряд)
	PORTB->OE&=~((uint16_t)(1<<5));			// input (DQ_read)
	for(i=0;i<N;i++)				// цикл побитового чтения данных (9бит-темпер, 8бит-конфиг) первый бит - младший разряд, последний - старший
	{
		spi_6_clk_low();													// CLK вниз
		wait_200ns();															// ждем 200 нс
		out_dat|=(((PORTB->RXTX&(1<<5))>>5)<<i);	// DQ - n разряд PORTA, смещаем его в нулевой, затем на i-тый разряд влево.
		spi_6_clk_high();													// CLK вверх
		wait_200ns();															// ждем 200 нс
	}
	if(d==1)
	{
			integer_temp=(uint8_t)(out_dat>>1);// если d=1, смещением отрезаем младший бит кода температуры, если нет - читаем конфиг как есть
		  frac_temp=(uint8_t)(out_dat-integer_temp);
		  return integer_temp;
	}
	else
	{
		 out_dat&=0xFF;
		 return out_dat;
	}					
}	

void spi_6_clk_low(void)								//тактовая вниз
{
	//PORTB->RXTX&=~(1<<2);
	PORTB->CLRTX=(1U<<2U);
}

void spi_6_clk_high(void)								//тактовая вверх
{
	//PORTB->RXTX|=(1<<2);
	PORTB->SETTX|=(1U<<2U);
}		

int8_t spi_7_read_temperature(int8_t spi_cs, int8_t *correct)//функция чтения температуры с 3 микросхем 5019ЧТ1Т (ЦОС)
{
	int8_t out=0;
	int8_t status=0;
	spi_7_clk_high();						// установил clk_high
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			SPI_T_MOTHER_CS1_ON;
			break;
		case 2:
			SPI_T_MOTHER_CS2_ON;
			break;
		case 3:
			SPI_T_MOTHER_CS3_ON;
			break;
	}
	spi_7_send_cmd(0xEE);		// отправляем команду начала преобразования температура->код
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			SPI_T_MOTHER_CS1_OFF;
			break;
		case 2:
			SPI_T_MOTHER_CS2_OFF;
			break;
		case 3:
			SPI_T_MOTHER_CS3_OFF;
			break;
	}	
	wait_150ns(1000000);		// ждем	завершения преобразования температура->код (750 мсек)
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			SPI_T_MOTHER_CS1_ON;
			break;
		case 2:
			SPI_T_MOTHER_CS2_ON;
			break;
		case 3:
			SPI_T_MOTHER_CS3_ON;
			break;
	}
	out=(int8_t)(spi_7_read_temper());// читаем код температуры 
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			SPI_T_MOTHER_CS1_OFF;
			break;
		case 2:
			SPI_T_MOTHER_CS2_OFF;
			break;
		case 3:
			SPI_T_MOTHER_CS3_OFF;
			break;
	}
	switch (spi_cs)//разрешаем передачу данных по нужному CSу
	{
		case 1:
			SPI_T_MOTHER_CS1_ON;
			break;
		case 2:
			SPI_T_MOTHER_CS2_ON;
			break;
		case 3:
			SPI_T_MOTHER_CS3_ON;
			break;
	}
	status=spi_7_read_config();
	if(((((uint8_t)(status))&(~0xF3))>>2U)!=0x02)
	{
		 out=0x80; //-128 significo the Temperatura error 
		 *correct=0;
	}
	else
	{
		 *correct=1u;
	}
	switch (spi_cs)//запрещаем передачу данных по нужному CSу
	{
		case 1:
			SPI_T_MOTHER_CS1_OFF;
			break;
		case 2:
			SPI_T_MOTHER_CS2_OFF;
			break;
		case 3:
			SPI_T_MOTHER_CS3_OFF;
			break;
	}
	return out;
}	

int8_t spi_7_read_temper(void)						//функция чтения температуры
{
	spi_7_send_cmd(0xAA);
	return spi_7_read_data(1);	// температура с точностью 1 градус
}

int8_t spi_7_read_config(void)						//функция чтения байта конфигурации
{
	spi_7_send_cmd(0xAC);
	return spi_7_read_data(0);	// конфигурация
}		

void spi_7_send_cmd(uint8_t cmd)						//функция отправки комманды микросхеме
{
	uint8_t i;									// i - смещение по байту (разряд)
	PORTB->OE|=(uint16_t)(1<<0);			// output (DQ_write)//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	for(i=0;i<8;i++)				// цикл побитовой отправки команды первый бит - младший разряд, последний - старший
	{
		spi_7_clk_low();			// CLK вниз
		wait_200ns();					// ждем 200 нс
    if ((cmd&(1<<i)))			// если i-тый бит команды не нулевой, то 
		{
			PORTB->RXTX|=(uint16_t)(1<<0);// устанавливаем DQ=1//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		}
		spi_7_clk_high();			// CLK вверх
		wait_200ns();					// ждем 200 нс
		PORTB->CLRTX=(uint16_t)(1U<<0U);// сбрасываем DQ (DQ=0)//!!!!!!!!!!!!!!!!!!!!!!!!!!!
	}
	PORTB->OE&=(~(uint16_t)(1<<0));			// input (DQ_read)	
}

int16_t spi_7_read_data(int8_t d)						//функция чтения байта данных
{
	// чтение данных: температуры (9бит, d=1) или конфигурации* (8бит, d=0)
	uint8_t i=0;
	uint8_t N=0;
	uint16_t out_dat=0;
  uint8_t integer_temp=0;
	uint8_t frac_temp=0;
	N=8+d;// i - смещение по байту (разряд)
	PORTB->OE&=~(uint16_t)(1<<0);			// input (DQ_read)
	for(i=0;i<N;i++)				// цикл побитового чтения данных (9бит-темпер, 8бит-конфиг) первый бит - младший разряд, последний - старший
	{
		spi_7_clk_low();													// CLK вниз
		wait_200ns();															// ждем 200 нс
		out_dat|=(((PORTB->RXTX&(1<<0))>>0)<<i);	// DQ - n разряд PORTA, смещаем его в нулевой, затем на i-тый разряд влево.
		spi_7_clk_high();													// CLK вверх
		wait_200ns();															// ждем 200 нс
	}
	if(d==1)
	{
		  integer_temp=(uint8_t)(out_dat>>1);// если d=1, смещением отрезаем младший бит кода температуры, если нет - читаем конфиг как есть
		  frac_temp=(uint8_t)(out_dat-integer_temp);
		  return integer_temp;
	}
	else
	{
		 out_dat&=0xFF;
		 return out_dat;
	}				
}	

void spi_7_clk_low(void)								//тактовая вниз
{
	//PORTB->RXTX&=~(1<<4);
	PORTB->CLRTX=(1U<<4U);
}

void spi_7_clk_high(void)								//тактовая вверх
{
	//PORTB->RXTX|=(1<<4);
	PORTB->SETTX|=(1U<<4U);
}		

void wait_200ns(void)										//200 нс тратится на вызов самой функции
{
	__NOP;
}


void termodannie_pp_v_1_massiv_BIS(void)    												 //функция для перегонки всех термоданных с печатных плат в 1 массив massiv_vseh_termodannih_pp_BIS
{												
	  massiv_vseh_termodannih_pp_BIS[16]=temperatura_COS[2];
    massiv_vseh_termodannih_pp_BIS[15]=temperatura_COS[1];
    massiv_vseh_termodannih_pp_BIS[14]=temperatura_COS[0];
    massiv_vseh_termodannih_pp_BIS[13]=temperatura_GT[0];
    massiv_vseh_termodannih_pp_BIS[12]=temperatura_MDM_KMV[0];
    massiv_vseh_termodannih_pp_BIS[11]=temperatura_BKS[1];
    massiv_vseh_termodannih_pp_BIS[10]=temperatura_BKS[0];
    massiv_vseh_termodannih_pp_BIS[9]=temperatura_RT_5[1];
    massiv_vseh_termodannih_pp_BIS[8]=temperatura_RT_5[0];
    massiv_vseh_termodannih_pp_BIS[7]=temperatura_RT_4[1];
    massiv_vseh_termodannih_pp_BIS[6]=temperatura_RT_4[0];
    massiv_vseh_termodannih_pp_BIS[5]=temperatura_RT_3[1];
    massiv_vseh_termodannih_pp_BIS[4]=temperatura_RT_3[0];
    massiv_vseh_termodannih_pp_BIS[3]=temperatura_RT_2[1];
    massiv_vseh_termodannih_pp_BIS[2]=temperatura_RT_2[0];
    massiv_vseh_termodannih_pp_BIS[1]=temperatura_RT_1[1];
    massiv_vseh_termodannih_pp_BIS[0]=temperatura_RT_1[0];
	  massiv_vseh_status_termodannih_pp_BIS[0]=temperatura_RT_1[2];
	  massiv_vseh_status_termodannih_pp_BIS[1]=temperatura_RT_1[3];
		massiv_vseh_status_termodannih_pp_BIS[2]=temperatura_RT_2[2];
	  massiv_vseh_status_termodannih_pp_BIS[3]=temperatura_RT_2[3];
		massiv_vseh_status_termodannih_pp_BIS[4]=temperatura_RT_3[2];
		massiv_vseh_status_termodannih_pp_BIS[5]=temperatura_RT_3[3];
		massiv_vseh_status_termodannih_pp_BIS[6]=temperatura_RT_4[2];
		massiv_vseh_status_termodannih_pp_BIS[7]=temperatura_RT_4[3];
		massiv_vseh_status_termodannih_pp_BIS[8]=temperatura_RT_5[2];
		massiv_vseh_status_termodannih_pp_BIS[9]=temperatura_RT_5[3];
		massiv_vseh_status_termodannih_pp_BIS[10]=temperatura_BKS[2];
		massiv_vseh_status_termodannih_pp_BIS[11]=temperatura_BKS[3];
		massiv_vseh_status_termodannih_pp_BIS[12]=temperatura_MDM_KMV[1];
		massiv_vseh_status_termodannih_pp_BIS[13]=temperatura_GT[1];
		massiv_vseh_status_termodannih_pp_BIS[14]=temperatura_COS[3];
	  massiv_vseh_status_termodannih_pp_BIS[15]=temperatura_COS[4];
		massiv_vseh_status_termodannih_pp_BIS[16]=temperatura_COS[5];
}

void termodannie_pp_v_1_massiv_MRL(void)    												 //функция для перегонки всех термоданных с печатных плат в 1 массив massiv_vseh_termodannih_pp_MRL
{
	  massiv_vseh_termodannih_pp_MRL[24]=temperatura_COS[2];
    massiv_vseh_termodannih_pp_MRL[23]=temperatura_COS[1];
    massiv_vseh_termodannih_pp_MRL[22]=temperatura_COS[0];
    massiv_vseh_termodannih_pp_MRL[21]=temperatura_GT[0];
    massiv_vseh_termodannih_pp_MRL[20]=temperatura_MDM_KMV[0];
    massiv_vseh_termodannih_pp_MRL[19]=temperatura_BKS[1];
    massiv_vseh_termodannih_pp_MRL[18]=temperatura_BKS[0];
    massiv_vseh_termodannih_pp_MRL[17]=temperatura_RT_9[1];
    massiv_vseh_termodannih_pp_MRL[16]=temperatura_RT_9[0];
    massiv_vseh_termodannih_pp_MRL[15]=temperatura_RT_8[1];
    massiv_vseh_termodannih_pp_MRL[14]=temperatura_RT_8[0];
    massiv_vseh_termodannih_pp_MRL[13]=temperatura_RT_7[1];
    massiv_vseh_termodannih_pp_MRL[12]=temperatura_RT_7[0];
    massiv_vseh_termodannih_pp_MRL[11]=temperatura_RT_6[1];
    massiv_vseh_termodannih_pp_MRL[10]=temperatura_RT_6[0];
    massiv_vseh_termodannih_pp_MRL[9]=temperatura_RT_5[1];
    massiv_vseh_termodannih_pp_MRL[8]=temperatura_RT_5[0];
    massiv_vseh_termodannih_pp_MRL[7]=temperatura_RT_4[1];
    massiv_vseh_termodannih_pp_MRL[6]=temperatura_RT_4[0];
    massiv_vseh_termodannih_pp_MRL[5]=temperatura_RT_3[1];
    massiv_vseh_termodannih_pp_MRL[4]=temperatura_RT_3[0];
    massiv_vseh_termodannih_pp_MRL[3]=temperatura_RT_2[1];
    massiv_vseh_termodannih_pp_MRL[2]=temperatura_RT_2[0];
    massiv_vseh_termodannih_pp_MRL[1]=temperatura_RT_1[1];
    massiv_vseh_termodannih_pp_MRL[0]=temperatura_RT_1[0];
		massiv_vseh_status_termodannih_pp_MRL[0]=temperatura_RT_1[2];
		massiv_vseh_status_termodannih_pp_MRL[1]=temperatura_RT_1[3];
		massiv_vseh_status_termodannih_pp_MRL[2]=temperatura_RT_2[2];
		massiv_vseh_status_termodannih_pp_MRL[3]=temperatura_RT_2[3];
		massiv_vseh_status_termodannih_pp_MRL[4]=temperatura_RT_3[2];
		massiv_vseh_status_termodannih_pp_MRL[5]=temperatura_RT_3[3];
		massiv_vseh_status_termodannih_pp_MRL[6]=temperatura_RT_4[2];
		massiv_vseh_status_termodannih_pp_MRL[7]=temperatura_RT_4[3];
		massiv_vseh_status_termodannih_pp_MRL[8]=temperatura_RT_5[2];
		massiv_vseh_status_termodannih_pp_MRL[9]=temperatura_RT_5[3];
		massiv_vseh_status_termodannih_pp_MRL[10]=temperatura_RT_6[2];
		massiv_vseh_status_termodannih_pp_MRL[11]=temperatura_RT_6[3];
		massiv_vseh_status_termodannih_pp_MRL[12]=temperatura_RT_7[2];
		massiv_vseh_status_termodannih_pp_MRL[13]=temperatura_RT_7[3];
		massiv_vseh_status_termodannih_pp_MRL[14]=temperatura_RT_8[2];
		massiv_vseh_status_termodannih_pp_MRL[15]=temperatura_RT_8[3];
		massiv_vseh_status_termodannih_pp_MRL[16]=temperatura_RT_9[2];
		massiv_vseh_status_termodannih_pp_MRL[17]=temperatura_RT_9[3];
		massiv_vseh_status_termodannih_pp_MRL[18]=temperatura_BKS[2];
		massiv_vseh_status_termodannih_pp_MRL[19]=temperatura_BKS[3];
		massiv_vseh_status_termodannih_pp_MRL[20]=temperatura_MDM_KMV[1];
		massiv_vseh_status_termodannih_pp_MRL[21]=temperatura_GT[1];
		massiv_vseh_status_termodannih_pp_MRL[22]=temperatura_COS[3];
		massiv_vseh_status_termodannih_pp_MRL[23]=temperatura_COS[4];
		massiv_vseh_status_termodannih_pp_MRL[24]=temperatura_COS[5];	
}

uint8_t naiti_minimalnoe_znachenie_pp(uint8_t *massive,uint8_t *massive_st, uint8_t razmer)//функция поиска минимального значения из массивов данных о температуре на печатных платах
{
   uint8_t result=0;
   int8_t a=0;
	 uint8_t i = 0;
	 uint8_t k = 0;
   int8_t min=0;
	 for(i=0;i<razmer;i++)
	 {
		 if(massive_st[i]==1)
		 {
			 if(k==0)
			 {
				 min=(int8_t)massive[i];
				 k=1u;
			 }
			 else
			 {
				  a=(int8_t)massive[i];
					min=fmin(a,min);
			 }
			 
		 }
	 }
   result=(uint8_t)min;
   return result;
}

uint8_t naiti_maximalnoe_znachenie_pp(uint8_t *massive, uint8_t *massive_st, uint8_t razmer)//функция поиска максимального значения из массивов данных о температуре на печатных платах
{
   uint8_t result=0;
   int8_t a=0;
	 uint8_t i = 0;
	 uint8_t k = 0;
   int8_t max=0;
	 for(i=0;i<razmer;i++)
	 {
		 if(massive_st[i]==1)
		 {
			 if(k==0)
			 {
				 max=(int8_t)massive[i];
				 k=1u;
			 }
			 else
			 {
				  a=(int8_t)massive[i];
					max=fmax(a,max);
			 }
			 
		 }
	 }
    result=(uint8_t)max;
    return result;
}

uint8_t naiti_srednee_znachenie_pp(uint8_t *massive, uint8_t *massive_st, uint8_t razmer) //функция расчёта среднего значения из массивов данных о температуре на печатных платах
{
    uint8_t result=0;
    int16_t b=0;
	  uint8_t i = 0;
	  uint16_t k = 0;
    for (i=0; i<razmer; i++)
    {
			 if(massive_st[i]==1)
		   {
					b=b+(int8_t)massive[i];
				  k++;
			 }
    }
    b=div(b,k).quot;
    result=(uint8_t)b;
    return result;
}

void vkluchit_BPV(void)     																				 //функция включения БПВ
{ 
  if(flag_vklucheniya_BPV!=1)
	{
		PORTB->OE|=0x0400;//сконфигурировать вывод ON/OFF на выход
		BPV_TURN_ON;
	}
  flag_vklucheniya_BPV=1;
}

void vikluchit_BPV(void)     																				 //функция выключения БПВ
{
	PORTB->OE&=(unsigned short)(~(1U<<10U));//сконфигурировать вывод ON/OFF на вход, таким образом заработает подтяжка от 24В (на делителе 3.33), значит транзистор откроется и выводы источника замкнутся между собой, значит источник ВЫКЛЮЧИТСЯ.
	//BPV_TURN_OFF;
	flag_vklucheniya_BPV=0;
	//LED_RAZOGREV_ON;
	flag_LED_RAZOGREV=1;
}

void vkluchit_razogrev_pp(void)     																 //функция принятия решения о включении разогрева для каждой из плат (нахождения минимального показания термодатчика из массива термоданных для каждой платы, сравнения минимального значения с нижней точкой достижения термостабилизации)
{
    int8_t Tmin=0;
		int8_t dfhdfgdfg=0;
    if(flag_konfiguracii_BPV==0)        //МРЛ
    {
       // Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[24],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[23]);
       // Tmin=fmin(Tmin,(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[22]);
       // if(Tmin<=((int8_t)tochka_termostabilizacii_niz))
       // {
       //     WARM_MOTHER_ON;
			//			wait_150ns(20000);
      //       TEMP_ERROR_MOTHER_OFF;
      //      flag_razogreva[12]=1;
      //  }
        if(((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[21])<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_GETER_ON;
						wait_150ns(20000);
            TEMP_ERROR_GETER_OFF;
            flag_razogreva[11]=1;
        }
        if(((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[20])<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_KMV_ON;
						wait_150ns(20000);
            TEMP_ERROR_KMV_OFF;
            flag_razogreva[10]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[19],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[18]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT10_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT10_OFF;
            flag_razogreva[9]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[17],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[16]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT9_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT9_OFF;
            flag_razogreva[8]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[15],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[14]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT8_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT8_OFF;
            flag_razogreva[7]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[13],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[12]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT7_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT7_OFF;
            flag_razogreva[6]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[11],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[10]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT6_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT6_OFF;
            flag_razogreva[5]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[9],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[8]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT5_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT5_OFF;
            flag_razogreva[4]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[7],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[6]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT4_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT4_OFF;
            flag_razogreva[3]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[5],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[4]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT3_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT3_OFF;
            flag_razogreva[2]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[3],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[2]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT2_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT2_OFF;
            flag_razogreva[1]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[1],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[0]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT1_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT1_OFF;
            flag_razogreva[0]=1;
        }
				if((int8_t)Tpp_average<=(int8_t)tochka_minimalnogo_peregreva)
				{
					 WARM_MOTHER_ON1;
					 WARM_MOTHER_ON;
					 wait_150ns(20000);
					 flag_razogreva[13]=1;
				}
															//WatchDog_change_flag();
    }
    else
    {
        //Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[16],(int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[15]);
        //Tmin=fmin(Tmin,(int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[14]);
        //if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        //{
        //    WARM_MOTHER_ON;
				//		wait_150ns(20000);
        // TEMP_ERROR_MOTHER_OFF;
        //    flag_razogreva[12]=1;
        //}
        if(((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[13])<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_GETER_ON;
						wait_150ns(20000);
            TEMP_ERROR_GETER_OFF;
            flag_razogreva[11]=1;
        }
        if(((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[12])<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_KMV_ON;
						wait_150ns(20000);
            TEMP_ERROR_KMV_OFF;
            flag_razogreva[10]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[11],(int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[10]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT10_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT10_OFF;
            flag_razogreva[9]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[9],(int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[8]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT5_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT5_OFF;
            flag_razogreva[4]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[7],(int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[6]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT4_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT4_OFF;
            flag_razogreva[3]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[5],(int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[4]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT3_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT3_OFF;
            flag_razogreva[2]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[3],(int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[2]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT2_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT2_OFF;
            flag_razogreva[1]=1;
        }
        Tmin=fmin((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[1],(int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[0]);
        if(Tmin<=(int8_t)tochka_termostabilizacii_niz)
        {
            WARM_RT1_ON;
						wait_150ns(20000);
            TEMP_ERROR_RT1_OFF;
            flag_razogreva[0]=1;
        }		
				if((int8_t)Tpp_average<=(int8_t)tochka_minimalnogo_peregreva)
				{
					 WARM_MOTHER_ON1;
					 WARM_MOTHER_ON;
					 wait_150ns(20000);
					 flag_razogreva[13]=1;
				}
    }
		
		for (uint8_t i=0; i<14; i++)
		{
			dfhdfgdfg=dfhdfgdfg+flag_razogreva[i];
		}
		if (dfhdfgdfg>0)
		{
				RAZOGREV_ON;
		}
}

void vikluchit_razogrev_pp(void)    																 //функция принятия решения о выключении разогрева для каждой из плат (нахождения максимального показания термодатчика из массива термоданных для каждой платы, сравнения максимального значения с верхней точкой достижения термостабилизации)
{
    int8_t Tmax=0;
		uint8_t dfhdfgdfg=0;
    if(flag_konfiguracii_BPV==0)        //МРЛ
    {
        //***********
  			Tmax=fmax((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[24],(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[23]);
        Tmax=fmax(Tmax,(int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[22]);
        if(Tmax>=(int8_t)(tochka_termostabilizacii_verh))
				{
						if(upravlenie_temp==0x01)
						{
									WARM_MOTHER_OFF1;	
							    WARM_MOTHER_OFF;	
									wait_150ns(20000);
						}
				}
				flag_razogreva[0]=0;	
			  //***********
        if(((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[21])>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
								WARM_GETER_OFF;
								wait_150ns(20000);
						 }
					  TEMP_ERROR_GETER_ON; 
						flag_razogreva[1]=0; 
        }
				else
				{
					flag_razogreva[1]=1u;
				}
			//***********	
        if(((int8_t)massiv_vseh_termodannih_pp_MRL_CORECT[20])>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
								WARM_KMV_OFF;
								wait_150ns(20000);
						 }		
					TEMP_ERROR_KMV_ON;
          flag_razogreva[2]=0;
        }
				else
				{
					flag_razogreva[2]=1u;
				}				
			//***********				
				Tmax=(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[19])+(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[18]);
        Tmax=(int8_t)div(Tmax,2).quot;
        if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
								WARM_RT10_OFF;
								wait_150ns(20000);
						 }					
					TEMP_ERROR_RT10_ON;
          flag_razogreva[3]=0;
        }
				else
				{
					flag_razogreva[3]=1u;
				}
			//***********	
				Tmax=(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[17])+(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[16]);
        Tmax=(int8_t)div(Tmax,2).quot;
        if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
								WARM_RT9_OFF;
								wait_150ns(20000);
						 }
						TEMP_ERROR_RT9_ON;  
						flag_razogreva[4]=0;						 
        }
				else
				{
					flag_razogreva[4]=1u;
				}
				Tmax=(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[15])+(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[14]);
        Tmax=(int8_t)div(Tmax,2).quot; 
			//***********
        if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {	
						 if(upravlenie_temp==0x01)
						 {
								WARM_RT8_OFF;
								wait_150ns(20000);
						 }
						TEMP_ERROR_RT8_ON;
						flag_razogreva[5]=0;	 
        }
				else
				{
					flag_razogreva[5]=1u;
				}
				//***********
				Tmax=(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[13])+(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[12]);
        Tmax=(int8_t)div(Tmax,2).quot; 
        if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
							if(upravlenie_temp==0x01)
						  {
								WARM_RT7_OFF;
								wait_150ns(20000);
						 }	
					  TEMP_ERROR_RT7_ON; 
						flag_razogreva[6]=0;
        }
				else
				{
					flag_razogreva[6]=1u;
				}
				//***********
        Tmax=(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[11])+(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[10]);
        Tmax=(int8_t)div(Tmax,2).quot; 
        if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
						  if(upravlenie_temp==0x01)
							{		
								WARM_RT6_OFF;
								wait_150ns(20000);
							}
						TEMP_ERROR_RT6_ON;
						flag_razogreva[7]=0;
        }
				else
				{
					flag_razogreva[7]=1u;
				}
				Tmax=(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[9])+(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[8]);
        Tmax=(int8_t)div(Tmax,2).quot; 
        //***********
				if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
							if(upravlenie_temp==0x01)
						  {
								WARM_RT5_OFF;
								wait_150ns(20000);
						  }
					  TEMP_ERROR_RT5_ON;
						flag_razogreva[8]=0;
        }
				else
				{
					flag_razogreva[8]=1u;
				}
				//***********
				Tmax=(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[7])+(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[6]);
        Tmax=(int8_t)div(Tmax,2).quot; 
        if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
				{
							if(upravlenie_temp==0x01)
						  {
								WARM_RT4_OFF;
								wait_150ns(20000);
							}
						TEMP_ERROR_RT4_ON;
						flag_razogreva[9]=0;
        }
				else
				{
					flag_razogreva[9]=1u;
				}				
				//***********
				Tmax=(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[5])+(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[4]);
        Tmax=(int8_t)div(Tmax,2).quot; 
				if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
								WARM_RT3_OFF;
								wait_150ns(20000);
						 }
						TEMP_ERROR_RT3_ON;
						flag_razogreva[10]=0; 
        }
				else
				{
					flag_razogreva[10]=1u;
				}
				//***********
        Tmax=(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[3])+(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[2]);
        Tmax=(int8_t)div(Tmax,2).quot;
				if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
								WARM_RT2_OFF;
								wait_150ns(20000);
						 }			
            TEMP_ERROR_RT2_ON;
						flag_razogreva[11]=0;
        }
				else
				{
					flag_razogreva[11]=1u;
				}
				//***********
				Tmax=(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[1])+(int8_t)(massiv_vseh_termodannih_pp_MRL_CORECT[0]);
        Tmax=(int8_t)div(Tmax,2).quot;
				if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
								WARM_RT1_OFF;
								wait_150ns(20000);
						 }
            TEMP_ERROR_RT1_ON;
						flag_razogreva[12]=0;
        }
				else
				{
					flag_razogreva[12]=1u;
				}
				if((int8_t)(Tpp_average)>=(int8_t)tochka_minimalnogo_peregreva)
				{
							if(upravlenie_temp==0x01)
							{
								WARM_MOTHER_OFF1;
								WARM_MOTHER_OFF;
								wait_150ns(20000);
								//TEMP_ERROR_MOTHER_ON; 
							}
							flag_razogreva[13]=0;
			  }
				else
				{
					flag_razogreva[13]=1u;
				}				
				//***********
    }
    else
    {
        Tmax=fmax((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[16],(int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[15]);
        Tmax=fmax(Tmax,(int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[14]);
        if(Tmax>=(int8_t)(tochka_termostabilizacii_verh))
				{ 
						 if(upravlenie_temp==0x01)
						 {
								WARM_MOTHER_OFF1;
							  WARM_MOTHER_OFF;
								wait_150ns(20000);
						 }
				}
        
				flag_razogreva[0]=0;	
				//***********
        if(((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[13])>=(int8_t)tochka_minimalnogo_peregreva)
        {
							if(upravlenie_temp==0x01)
						  {
								WARM_GETER_OFF;
								wait_150ns(20000);
							}
            TEMP_ERROR_GETER_ON;
						flag_razogreva[1]=0;	
        }	
				else
				{
					flag_razogreva[1]=1u;	
				}
				//***********
        if(((int8_t)massiv_vseh_termodannih_pp_BIS_CORECT[12])>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
							WARM_KMV_OFF;
							wait_150ns(20000);
						 }			
             TEMP_ERROR_KMV_ON;
						 flag_razogreva[2]=0;
        }
				else
				{
					flag_razogreva[2]=1u;	
				}
				//***********
       	Tmax=(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[11])+(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[10]);
        Tmax=(int8_t)div(Tmax,2).quot;
				if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
							WARM_RT10_OFF;
							wait_150ns(20000);
						 }
            TEMP_ERROR_RT10_ON;
						flag_razogreva[3]=0;		 
        }
				else
				{
					flag_razogreva[3]=1u;	
				}
				//***********
				flag_razogreva[4]=0;
				flag_razogreva[5]=0;
				flag_razogreva[6]=0;
				flag_razogreva[7]=0;
				Tmax=(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[9])+(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[8]);
        Tmax=(int8_t)div(Tmax,2).quot;
				if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
								WARM_RT5_OFF;
								wait_150ns(20000);
						 }
					 TEMP_ERROR_RT5_ON;
					 flag_razogreva[8]=0;			
        }
				else
				{
					flag_razogreva[8]=1u;	
				}
       	Tmax=(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[7])+(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[6]);
        Tmax=(int8_t)div(Tmax,2).quot;
				if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
							if(upravlenie_temp==0x01)
						  {
								WARM_RT4_OFF;
								wait_150ns(20000);
							}
						TEMP_ERROR_RT4_ON;
						flag_razogreva[9]=0;	
        }
				else
				{
					flag_razogreva[9]=1u;	
				}
				//***********
        Tmax=(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[5])+(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[4]);
        Tmax=(int8_t)div(Tmax,2).quot;
				if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
								WARM_RT3_OFF;
								wait_150ns(20000);
						 }
						 TEMP_ERROR_RT3_ON;
						 flag_razogreva[10]=0;
        }
				else
				{
					flag_razogreva[10]=1u;	
				}
				//***********
        Tmax=(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[3])+(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[2]);
        Tmax=(int8_t)div(Tmax,2).quot;
				if((int8_t)(Tmax)>=(int8_t)tochka_minimalnogo_peregreva)
        {
					 if(upravlenie_temp==0x01)
					 {
								WARM_RT2_OFF;
								wait_150ns(20000);
						}
            TEMP_ERROR_RT2_ON;
						flag_razogreva[11]=0;
        }
				else
				{
					flag_razogreva[11]=1u;	
				}
				//***********
        Tmax=(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[1])+(int8_t)(massiv_vseh_termodannih_pp_BIS_CORECT[0]);
        Tmax=(int8_t)div(Tmax,2).quot;
        if(Tmax>=(int8_t)tochka_minimalnogo_peregreva)
        {
						 if(upravlenie_temp==0x01)
						 {
							WARM_RT1_OFF;
							wait_150ns(20000);
						 }
            TEMP_ERROR_RT1_ON;
						flag_razogreva[12]=0;
        }
				else
				{
					flag_razogreva[12]=1u;	
				}
				if((int8_t)(Tpp_average)>=(int8_t)tochka_minimalnogo_peregreva)
				{
						 if(upravlenie_temp==0x01)
						 {
							WARM_MOTHER_OFF1;
							WARM_MOTHER_OFF;
							wait_150ns(20000);
							//TEMP_ERROR_MOTHER_ON; 
						 }
					 flag_razogreva[13]=0;
				}
				else
				{
					flag_razogreva[13]=1u;	
				}				
				//***********
    }
		for (uint8_t i=0; i<14; i++)
		{
			dfhdfgdfg=dfhdfgdfg+flag_razogreva[i];
		}
		if ((dfhdfgdfg==0)&&(upravlenie_temp==0x01))
		{
			REOGREV_OFF;
		}
}

void vkluchit_ventilyator(void)     																 //функция установки необходимой мощности и включения таймера вентилятора для его работы в отдельном потоке
{
	  if(((((int8_t)Tpp_average)-((int8_t)tochka_razresheniya_raboti_ventilyatora))>=0) && ((((int8_t)Tpp_average)-((int8_t)tochka_razresheniya_raboti_ventilyatora))<=1))
    {
        moschnost_raboti_ventilyatora=40;
    }
    if(((((int8_t)Tpp_average)-((int8_t)tochka_razresheniya_raboti_ventilyatora))>1) && ((((int8_t)Tpp_average)-((int8_t)tochka_razresheniya_raboti_ventilyatora))<=2))
    {
        moschnost_raboti_ventilyatora=80;
    }
    if((((int8_t)Tpp_average)-((int8_t)tochka_razresheniya_raboti_ventilyatora))>2u)
    {
        moschnost_raboti_ventilyatora=100;
    }	
	/*													
	if(((((int8_t)Tpp_average)-((int8_t)tochka_minimalnogo_peregreva))>0) && ((((int8_t)Tpp_average)-((int8_t)tochka_minimalnogo_peregreva))<=5))
    {
        moschnost_raboti_ventilyatora=20;
    }
    if(((((int8_t)Tpp_average)-((int8_t)tochka_minimalnogo_peregreva))>5) && ((((int8_t)Tpp_average)-((int8_t)tochka_minimalnogo_peregreva))<=10))
    {
        moschnost_raboti_ventilyatora=40;
    }
    if(((((int8_t)Tpp_average)-((int8_t)tochka_minimalnogo_peregreva))>10) && ((((int8_t)Tpp_average)-((int8_t)tochka_minimalnogo_peregreva))<=15))
    {
        moschnost_raboti_ventilyatora=60;
    }
    if(((((int8_t)Tpp_average)-((int8_t)tochka_minimalnogo_peregreva))>15) && ((((int8_t)Tpp_average)-((int8_t)tochka_minimalnogo_peregreva))<=20))
    {
        moschnost_raboti_ventilyatora=80;
    }
    if((((int8_t)Tpp_average)-((int8_t)tochka_minimalnogo_peregreva))>20)
    {
        moschnost_raboti_ventilyatora=100;
    }*/
    TIMER1->CNTRL=1;//включить таймер 1
    flag_sostoyaniya_ventilyatora=1;
}

void vikluchit_ventilyator(void)    																 //функция выключения вентилятора
{
															//WatchDog_change_flag();
	  TIMER1->CNTRL=0;//включить таймер 1
    FAN_GATE_OFF;
    flag_sostoyaniya_ventilyatora=0;
}

void UART_1_send_message_to_ZYNQ(void)    													 //функция отправки отчёта ZYNQу
{
		if(flag_vinujdennoy_peredachi_NMEA==1)
		{
			podgotovit_stroki_k_otpravke();
			send_data_UART_1_NMEA(pervaya_stroka, sizeof(pervaya_stroka), vtoraya_stroka, sizeof(vtoraya_stroka));
			flag_vinujdennoy_peredachi_NMEA=0;
		}
		else
		{
			if(flag_konfiguracii_BPV==0)        //МРЛ
			{
				if(flag_vinujdennoy_peredachi_ADDR_AFU==0)
				{
					send_data_UART_1(massiv_vseh_termodannih_AFU_MRL,sizeof(massiv_vseh_termodannih_AFU_MRL),massiv_vseh_termodannih_pp_MRL,sizeof(massiv_vseh_termodannih_pp_MRL),osnovnie_konstanti,sizeof(osnovnie_konstanti));	
				}
				else
				{
					send_data_UART_1(massiv_send_addrr,sizeof(massiv_send_addrr),NOOL,0,NOOL,0);	
				}
			}
			else
			{
				if(flag_vinujdennoy_peredachi_ADDR_AFU==0)
				{
						send_data_UART_1(massiv_vseh_termodannih_AFU_BIS,sizeof(massiv_vseh_termodannih_AFU_BIS),massiv_vseh_termodannih_pp_BIS,sizeof(massiv_vseh_termodannih_pp_BIS),osnovnie_konstanti,sizeof(osnovnie_konstanti));	
				}
				else
				{
					send_data_UART_1(massiv_send_addrr,sizeof(massiv_send_addrr),NOOL,0,NOOL,0);	
				}
			}
	   }
} 

void podgotovit_stroki_k_otpravke(void)															 //функция забивания массивов pervaya_stroka и vtoraya_stroka для последующей отправки по UART'у
{
															//WatchDog_change_flag();
int8_t temp[4]={0,0,0,0};
    int8_t abc=0;
    int days_for_func=0;

    for (uint8_t i = 0; i<11; i++)//записываем дату компиляции
  {
    pervaya_stroka[i+7]=DATE[i];
    }
    for (uint8_t i = 0; i<8; i++)//записываем время компиляции
  {
    pervaya_stroka[i+19]=TIME[i];
    }
    if(Years<10)//записываем количество лет
    {
        pervaya_stroka[43]=' ';
        abc=(int)Years;
        sprintf(temp, "%d", abc);
        pervaya_stroka[44]=temp[0];

        //////////////////////////////////////
        temp[0]=0;//обнулиться
        temp[1]=0;
        abc=0;
    }
    else
    {
        abc=(int)Years;
        sprintf(temp, "%d", abc);
        pervaya_stroka[43]=temp[0];
        pervaya_stroka[44]=temp[1];

        //////////////////////////////////////
        temp[0]=0;//обнулиться
        temp[1]=0;
        temp[2]=0;
        temp[3]=0;
        abc=0;
    }
    if(Days<10)//записываем количество дней
    {
        pervaya_stroka[53]=' ';
        pervaya_stroka[54]=' ';
        days_for_func=(int)Days;
        sprintf(temp, "%d", days_for_func);
        pervaya_stroka[55]=temp[0];

        //////////////////////////////////////
        temp[0]=0;//обнулиться
        temp[1]=0;
        abc=0;
    }
    else
    {
        if(Days<100)
        {
            pervaya_stroka[53]=' ';
            days_for_func=(int)Days;
            sprintf(temp, "%d", days_for_func);
            pervaya_stroka[54]=temp[0];
            pervaya_stroka[55]=temp[1];

            temp[0]=0;//обнулиться
            temp[1]=0;
            temp[2]=0;
            temp[3]=0;
            days_for_func=0;
        }
        else
        {
            days_for_func=(int)Days;
            sprintf(temp, "%d", days_for_func);
            pervaya_stroka[53]=temp[0];
            pervaya_stroka[54]=temp[1];
            pervaya_stroka[55]=temp[2];

            temp[0]=0;//обнулиться
            temp[1]=0;
            temp[2]=0;
            temp[3]=0;
            days_for_func=0;
        }
    }
    if(Hours<10)//записываем количество часов
    {
        pervaya_stroka[63]=' ';
        abc=(int)Hours;
        sprintf(temp, "%d", abc);
        pervaya_stroka[64]=temp[0];

        //////////////////////////////////////
        temp[0]=0;//обнулиться
        temp[1]=0;
        abc=0;
    }
    else
    {
        abc=(int)Hours;
        sprintf(temp, "%d", abc);
        pervaya_stroka[63]=temp[0];
        pervaya_stroka[64]=temp[1];

        //////////////////////////////////////
        temp[0]=0;//обнулиться
        temp[1]=0;
        temp[2]=0;
        temp[3]=0;
        abc=0;
    }
    if(Minutes<10)//записываем количество минут
    {
        pervaya_stroka[73]=' ';
        abc=(int)Minutes;
        sprintf(temp, "%d", abc);
        pervaya_stroka[74]=temp[0];

        //////////////////////////////////////
        temp[0]=0;//обнулиться
        temp[1]=0;
        abc=0;
    }
    else
    {
        abc=(int)Minutes;
        sprintf(temp, "%d", abc);
        pervaya_stroka[73]=temp[0];
        pervaya_stroka[74]=temp[1];

        //////////////////////////////////////
        temp[0]=0;//обнулиться
        temp[1]=0;
        temp[2]=0;
        temp[3]=0;
        abc=0;
    }

    if(flag_konfiguracii_BPV==0)//записываем какой это БПВ
    {
        pervaya_stroka[93]='M';
        pervaya_stroka[94]='R';
        pervaya_stroka[95]='L';
    }
    else
    {
        pervaya_stroka[93]='B';
        pervaya_stroka[94]='I';
        pervaya_stroka[95]='S';
    }

    if(flag_vklucheniya_BPV==0)//записываем подано ли питание на ЦОС
    {
        pervaya_stroka[102]='O';
        pervaya_stroka[103]='F';
        pervaya_stroka[104]='F';
    }
    else
    {
        pervaya_stroka[102]='_';
        pervaya_stroka[103]='O';
        pervaya_stroka[104]='N';
    }

    if(flag_sostoyaniya_ventilyatora==0)//записываем включен ли вентилятор
    {
        pervaya_stroka[111]='O';
        pervaya_stroka[112]='F';
        pervaya_stroka[113]='F';
    }
    else
    {
        pervaya_stroka[111]='_';
        pervaya_stroka[112]='O';
        pervaya_stroka[113]='N';
    }

    if(moschnost_raboti_ventilyatora<10)//записываем мощность работы вентилятора
    {
        pervaya_stroka[126]=' ';
        pervaya_stroka[127]=' ';
        abc=(int)moschnost_raboti_ventilyatora;
        sprintf(temp, "%d", abc);
        pervaya_stroka[128]=temp[0];

        //////////////////////////////////////
        temp[0]=0;//обнулиться
        temp[1]=0;
        abc=0;
    }
    else
    {
        if(moschnost_raboti_ventilyatora<100)
        {
            pervaya_stroka[126]=' ';
            abc=(int)moschnost_raboti_ventilyatora;
            sprintf(temp, "%d", abc);
            pervaya_stroka[127]=temp[0];
            pervaya_stroka[128]=temp[1];

            temp[0]=0;//обнулиться
            temp[1]=0;
            temp[2]=0;
            temp[3]=0;
            abc=0;
        }
        else
        {
            abc=(int)moschnost_raboti_ventilyatora;
            sprintf(temp, "%d", abc);
            pervaya_stroka[126]=temp[0];
            pervaya_stroka[127]=temp[1];
            pervaya_stroka[128]=temp[2];

            temp[0]=0;//обнулиться
            temp[1]=0;
            temp[2]=0;
            temp[3]=0;
            abc=0;
        }
    }

		zapisat_temperaturu_v_stroku(tochka_razresheniya_raboti_ventilyatora, pervaya_stroka, 164);
		zapisat_temperaturu_v_stroku(tochka_minimalnogo_peregreva, pervaya_stroka, 189);
		zapisat_temperaturu_v_stroku(tochka_razresheniya_vklucheniya, pervaya_stroka, 204);
		zapisat_temperaturu_v_stroku(tochka_termostabilizacii_niz, pervaya_stroka, 232);
		zapisat_temperaturu_v_stroku(tochka_termostabilizacii_verh, pervaya_stroka, 261);

      //вычислим контрольную сумму
    kontrolnaya_summa_pervaya_stroka=pervaya_stroka[1];
    for(uint32_t i=2;i<264;i++)
    {
            abc=pervaya_stroka[i];
            kontrolnaya_summa_pervaya_stroka=kontrolnaya_summa_pervaya_stroka^pervaya_stroka[i];
        }
    //вычисление контрольной суммы закончено

    if((uint8_t)kontrolnaya_summa_pervaya_stroka>15)
    {
        sprintf(temp, "%x", (uint8_t)kontrolnaya_summa_pervaya_stroka);
        pervaya_stroka[265]=temp[0];
        pervaya_stroka[266]=temp[1];
    }
    else
    {
        sprintf(temp, "%x", kontrolnaya_summa_pervaya_stroka);
        pervaya_stroka[265]='0';
        pervaya_stroka[266]=temp[0];
    }

    temp[0]=0;//обнулиться
    temp[1]=0;
    temp[2]=0;
    temp[3]=0;
    abc=0;

    pervaya_stroka[267]=0x0D;

    //pervaya_stroka[sizeof(pervaya_stroka)-1]=0x0A;
/////////////////////////////////////////////////////////////////////
/////////////////////Первая строка заполнена/////////////////////////
/////////////////////////////////////////////////////////////////////

    if(flag_konfiguracii_BPV==0)//если это МРЛ
    {
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_MRL[0],vtoraya_stroka, 11);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_MRL[1],vtoraya_stroka, 15);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_MRL[2],vtoraya_stroka, 19);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_MRL[3],vtoraya_stroka, 23);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_MRL[4],vtoraya_stroka, 27);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_MRL[5],vtoraya_stroka, 31);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_MRL[6],vtoraya_stroka, 35);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_MRL[7],vtoraya_stroka, 39);

    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[0],vtoraya_stroka, 48);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[1],vtoraya_stroka, 52);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[2],vtoraya_stroka, 61);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[3],vtoraya_stroka, 65);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[4],vtoraya_stroka, 74);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[5],vtoraya_stroka, 78);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[6],vtoraya_stroka, 87);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[7],vtoraya_stroka, 91);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[8],vtoraya_stroka, 100);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[9],vtoraya_stroka, 104);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[10],vtoraya_stroka, 113);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[11],vtoraya_stroka, 117);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[12],vtoraya_stroka, 126);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[13],vtoraya_stroka, 130);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[14],vtoraya_stroka, 139);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[15],vtoraya_stroka, 143);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[16],vtoraya_stroka, 152);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[17],vtoraya_stroka, 156);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[18],vtoraya_stroka, 165);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[19],vtoraya_stroka, 169);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[20],vtoraya_stroka, 178);//КМВ
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[21],vtoraya_stroka, 187);//ГЕТ
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[22],vtoraya_stroka, 196);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[23],vtoraya_stroka, 200);
    zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_MRL[24],vtoraya_stroka, 204);

    //вычислим контрольную сумму
    kontrolnaya_summa_vtoraya_stroka=vtoraya_stroka[1];
    for(uint8_t i=2;i<207;i++)
    {
            abc=vtoraya_stroka[i];
            kontrolnaya_summa_vtoraya_stroka=kontrolnaya_summa_vtoraya_stroka^vtoraya_stroka[i];
        }
    //вычисление контрольной суммы закончено

        if((uint8_t)kontrolnaya_summa_vtoraya_stroka>15)
        {
            sprintf(temp, "%x", (uint8_t)kontrolnaya_summa_vtoraya_stroka);
            vtoraya_stroka[208]=temp[0];
            vtoraya_stroka[209]=temp[1];
        }
        else
        {
            sprintf(temp, "%x", kontrolnaya_summa_vtoraya_stroka);
            vtoraya_stroka[208]='0';
            vtoraya_stroka[209]=temp[0];
        }
        temp[0]=0;//обнулиться
        temp[1]=0;
        temp[2]=0;
        temp[3]=0;
        abc=0;

        vtoraya_stroka[210]=0x0D;

        //vtoraya_stroka[sizeof(vtoraya_stroka)-1]=0x0A;
/////////////////////////////////////////////////////////////////////
/////////////////////Вторая строка заполнена/////////////////////////
/////////////////////////////////////////////////////////////////////
    }
    else    //если это БИС
    {
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_BIS[0],vtoraya_stroka, 11);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_BIS[1],vtoraya_stroka, 15);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_BIS[2],vtoraya_stroka, 19);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_BIS[3],vtoraya_stroka, 23);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_AFU_BIS[4],vtoraya_stroka, 27);
        vtoraya_stroka[31]=',';vtoraya_stroka[32]=',';vtoraya_stroka[33]=',';
        vtoraya_stroka[35]=',';vtoraya_stroka[36]=',';vtoraya_stroka[37]=',';
        vtoraya_stroka[39]=',';vtoraya_stroka[40]=',';vtoraya_stroka[41]=',';

        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[0],vtoraya_stroka, 48);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[1],vtoraya_stroka, 52);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[2],vtoraya_stroka, 61);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[3],vtoraya_stroka, 65);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[4],vtoraya_stroka, 74);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[5],vtoraya_stroka, 78);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[6],vtoraya_stroka, 87);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[7],vtoraya_stroka, 91);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[8],vtoraya_stroka, 100);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[9],vtoraya_stroka, 104);
        vtoraya_stroka[113]=',';vtoraya_stroka[114]=',';vtoraya_stroka[115]=',';
        vtoraya_stroka[117]=',';vtoraya_stroka[118]=',';vtoraya_stroka[119]=',';
        vtoraya_stroka[126]=',';vtoraya_stroka[127]=',';vtoraya_stroka[128]=',';
        vtoraya_stroka[130]=',';vtoraya_stroka[131]=',';vtoraya_stroka[132]=',';
        vtoraya_stroka[139]=',';vtoraya_stroka[140]=',';vtoraya_stroka[141]=',';
        vtoraya_stroka[143]=',';vtoraya_stroka[144]=',';vtoraya_stroka[145]=',';
        vtoraya_stroka[152]=',';vtoraya_stroka[153]=',';vtoraya_stroka[154]=',';
        vtoraya_stroka[156]=',';vtoraya_stroka[157]=',';vtoraya_stroka[158]=',';
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[10],vtoraya_stroka, 165);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[11],vtoraya_stroka, 169);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[12],vtoraya_stroka, 178);//КМВ
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[13],vtoraya_stroka, 187);//ГЕТ
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[14],vtoraya_stroka, 196);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[15],vtoraya_stroka, 200);
        zapisat_temperaturu_v_stroku(massiv_vseh_termodannih_pp_BIS[16],vtoraya_stroka, 204);

    //вычислим контрольную сумму
    kontrolnaya_summa_vtoraya_stroka=vtoraya_stroka[1];
    for(uint8_t i=2;i<207;i++)
    {
            abc=vtoraya_stroka[i];
            kontrolnaya_summa_vtoraya_stroka=kontrolnaya_summa_vtoraya_stroka^vtoraya_stroka[i];
        }
    //вычисление контрольной суммы закончено

        if((uint8_t)kontrolnaya_summa_vtoraya_stroka>15)
        {
            sprintf(temp, "%x", (uint8_t)kontrolnaya_summa_vtoraya_stroka);
            vtoraya_stroka[208]=temp[0];
            vtoraya_stroka[209]=temp[1];
        }
        else
        {
            sprintf(temp, "%x", kontrolnaya_summa_vtoraya_stroka);
            vtoraya_stroka[208]='0';
            vtoraya_stroka[209]=temp[0];
        }
        temp[0]=0;//обнулиться
        temp[1]=0;
        temp[2]=0;
        temp[3]=0;
        abc=0;

        vtoraya_stroka[210]=0x0D;

        //vtoraya_stroka[sizeof(vtoraya_stroka)-1]=0x0A;
/////////////////////////////////////////////////////////////////////
/////////////////////Вторая строка заполнена/////////////////////////
/////////////////////////////////////////////////////////////////////
    }
															//WatchDog_change_flag();
}

void zapisat_temperaturu_v_stroku(uint8_t Tuint8, int8_t *stroka, uint32_t poziciya)//функция преобразования uint8_t значения температуры в несколько int8_t'ов для отправки по NMEA
{
	int8_t b=0;
	int8_t buffer_int8_t[4]={0,0,0,0};
	b=(int)Tuint8;
	sprintf(buffer_int8_t, "%d", b);
	b=(int8_t)Tuint8;
	if(b>=0)//если температура положительная или 0
	{
		if(Tuint8==0)//если температура = 0
		{
			stroka[poziciya++]='+';
			stroka[poziciya++]='0';
			stroka[poziciya]='0';
		}
		else//если температура положительная
		{
			if(b>9)//если температура состоит из 2-х символов (к примеру, 27)
			{
				stroka[poziciya++]='+';
				for(int i=0; i<2; i++)
				{
					stroka[poziciya++]=buffer_int8_t[i];
				}
				poziciya--;
			}
			else//если температура состоит из 1 смволов (к примеру, 8)
			{
				stroka[poziciya++]='+';
				stroka[poziciya++]=buffer_int8_t[0];
				stroka[poziciya]=',';
			}
		}
	}
	else//если температура отрицательная
	{
		if(b<-9)//если температура состоит из 3-х символов (к примеру, -27)
		{
			for(int i=0; i<3; i++)
			{
				stroka[poziciya++]=buffer_int8_t[i];
			}
				poziciya--;
		}
		else//если температура состоит из 2-х символов (к примеру, -2)
		{
			for(int i=0; i<2; i++)
			{
				stroka[poziciya++]=buffer_int8_t[i];
			}
			stroka[poziciya]=',';
		}
	}
															
}




